/* 
** PROGRAM
**	baum_welch1.c
**
** USAGE
**	cat data_file.asc | baum_welch1  parameter_filename >> optfile
**
** DESCRIPTION
**	This program is first of the two programs that uses Baum-Welch
** 	iterative procedure to optimize the parameters a[i,j] and pi[i].
** 	This program generates numerator and denominator values for the
** 	parameters a[i,j] and pi[i].  The second program uses these values
** 	to find locally optimum solution for a[i,j] and pi[i].
**
** REVISION
**	Revision 2.0	paul lee 6/90
*/

#include <stdio.h>
#include <math.h>
#include "markov.h"

#define	DELIMITER	999

#define	JPL		0
#define	LORD		0
#define B5		0
#define HMMLORD		1

int read_ipt ();
char *chkmalloc ();

double *xforce;
double **b, **num_a, *denom_a, *num_pi, *num_mu, *num_sigma, *denom_mu_sigma;
double **alpha_hat, **beta_hat, *c;
double p_hat, log_p;

main(argc, argv)
   int 	argc;
   char *argv[];
{
   struct Hmm_Par	*hmm_par;

   int 		i, j;
   int 		delimiter = DELIMITER;
   char		par_fname[40];

   int      	ichk, endt, t; 	 /*  t=no. of data pts  1<= t < no_datas  */
   float    	time, x1, x2, x3, x4, x5, x6, x7, x8, x9;
   double	*bt;
   double   	*forward_sum, backward_sum, sum, sum1, sum2, inv_csum,log_csum;
   double	num, denom, alphabeta;

   if (argc == 1)	{
      printf ("Usage: cat data_file.asc | baum_welch1 parameter_filename\n\n");
      exit(0);
   }
   else	{
      strcpy (par_fname, argv[1]);
   }

   hmm_par = (struct Hmm_Par *) chkmalloc (sizeof(struct Hmm_Par), "hmm_par");

   if (read_ipt (par_fname, hmm_par) == -1)	{
      printf ("Parameter file %s does not exist.\n\n", par_fname); 
      exit(0);
   }
   /** Allocate mem space for global variables **/
   xforce = (double *) chkmalloc (hmm_par->max_size*sizeof(double), "xforce");
   b = (double **) chkmalloc (hmm_par->no_states*sizeof(double *), "b");
   num_a = (double **) chkmalloc(hmm_par->no_states*sizeof(double *), "num_a");
   for (i=0; i<hmm_par->no_states; i++)
	num_a[i] = (double *) chkmalloc (
			hmm_par->no_states*sizeof(double), "num_a[i]");
   denom_a = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "denom_a");
   num_pi = (double *) chkmalloc (hmm_par->no_states*sizeof(double), "num_pi");
   num_mu = (double *) chkmalloc (hmm_par->no_states*sizeof(double), "num_mu");
   num_sigma = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "num_sigma");
   denom_mu_sigma = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "denom_mu_sigma");
   alpha_hat = (double **) chkmalloc(
		hmm_par->no_states*sizeof(double *), "alpha_hat");
   beta_hat = (double **) chkmalloc (
		hmm_par->no_states*sizeof(double *), "beta_hat");

   /** Allocate mem space for local variables **/
   bt = (double *) chkmalloc (hmm_par->no_states*sizeof(double), "bt");
   forward_sum = (double *) chkmalloc (hmm_par->no_states*sizeof(double),
		"forward_sum");

   t = 0;

   /** Read force ascii data from stdin **/
   while (scanf("%f %lf %f %f", &time, &xforce[t], &x1, &x2) > 0)   {
/**
   while (scanf("%f %f %f %f %f %lf %f %f %f %f %f", &time, &x1, &x2, &x3, 
		&x4, &xforce[t], &x5, &x6, &x7, &x8, &x9) > 0)   {
   while (scanf("%f %lf %f %f %f %f %f", &time, &xforce[t], &x1, &x2,
		 &x3, &x4, &x5) > 0)   {
   while (scanf("%f %lf %f %f %f %f %f %f %f %f", &time, &xforce[t], &x1, &x2,
		 &x3, &x4, &x5, &x6, &x7, &x8) > 0)   {
**/

      if (++t > hmm_par->max_size)  {
	 printf ("Length of output too large.\nMust allocate ");
	 printf ("more space for the variables in \'*.par\'.\n\n");
	 exit(0);
      }	 
   }

   endt = t - 1;

   /** Allocate mem space of 'endt' for b, alpha_hat, and beta_hat **/
   for (i=0; i<hmm_par->no_states; i++)	{
      b[i] = (double *) chkmalloc (t*sizeof(double), "b[i]");
      alpha_hat[i] = (double *) chkmalloc (t*sizeof(double), "alpha_hat[i]");
      beta_hat[i] = (double *) chkmalloc (t*sizeof(double), "beta_hat[i]");
      c = (double *) chkmalloc (t*sizeof(double), "scale factor");
   }

   findb (bt, xforce[0], hmm_par);
   /** Define initial starting point of forward calculations **/
   inv_csum = 0;
   for (i=0; i<hmm_par->no_states; i++)  {
      inv_csum += hmm_par->pi[i]*bt[i];
   }
   c[0] = 1/inv_csum;
   for (i=0; i<hmm_par->no_states; i++)  {
      alpha_hat[i][0] = c[0]*hmm_par->pi[i]*bt[i];
   }
   /** Do forward calculations **/
   for (t=0; t<=endt-1; t++)  {
      findb (bt, xforce[t+1], hmm_par);
      inv_csum = 0;
      for (j=0; j<hmm_par->no_states; j++)  {
	 b[j][t+1] = bt[j];
	 forward_sum[j] = 0;
	 for (i=0; i<hmm_par->no_states; i++)  {
	    forward_sum[j] += alpha_hat[i][t]*hmm_par->a[i][j];
         }
	 forward_sum[j] *=b[j][t+1];
	 inv_csum += forward_sum[j];
      }
      c[t+1] = 1/inv_csum;
      for (j=0; j<hmm_par->no_states; j++)	{
	 alpha_hat[j][t+1] = c[t+1]*forward_sum[j];
         /** 
	 printf ("%7.3e %7.3e %7.3f %7.3f\n", alpha_hat[j][t+1], c[t+1], 
				(float) t/16.67,	xforce[t]);
	 **/
      }
   }      

   /** Define initial starting point of backward calculations **/
   for (i=0; i<hmm_par->no_states; i++)  {
      beta_hat[i][endt] = c[endt];
   }
   /** Do backward calculations **/
   for (t=endt-1; t>=0; t--)  {
      for (i=0; i<hmm_par->no_states; i++)  {
	 backward_sum = 0;
	 for (j=0; j<hmm_par->no_states; j++)  {
	    backward_sum += hmm_par->a[i][j]*b[j][t+1]*beta_hat[j][t+1];
         }
         beta_hat[i][t] = c[t]*backward_sum;
      }
   }

   /** Find P value **/
   sum = 0;
   for (i=0; i<hmm_par->no_states; i++)  {
      sum += alpha_hat[i][endt];
   }
   p_hat = sum;

   /** Find numerator and denominator of A matrix **/
   for (i=0; i<hmm_par->no_states; i++)  {
      ichk = i;
      denom = 0;
      for (j=0; j<hmm_par->no_states; j++)  {
	 num = 0;
	 for (t=0; t<=endt-1; t++)   {
	    num += alpha_hat[i][t]*hmm_par->a[i][j]*b[j][t+1]*beta_hat[j][t+1];
	    if (i == ichk)  
               denom += alpha_hat[i][t]*beta_hat[i][t]/c[t];
         }
	 num_a[i][j] = num/p_hat;
	 ichk++;
      }
      denom_a[i] = denom/p_hat;
   }

   /** Find numerator of pi; numerator and denominator of mu and sigma **/
   for (i=0; i<hmm_par->no_states; i++) {
      num_pi[i] = alpha_hat[i][0]*beta_hat[i][0]/(c[0]*p_hat);
      sum1 = sum2 = 0;
      for (t=0; t<=endt; t++)  {
	alphabeta = alpha_hat[i][t]*beta_hat[i][t]/c[t];
	sum1 += alphabeta*xforce[t];
	sum2 += alphabeta*(xforce[t]-hmm_par->mu[i])*(xforce[t]-hmm_par->mu[i]);
      }
      num_mu[i] = sum1/p_hat;
      num_sigma[i] = sum2/p_hat;
      denom_mu_sigma[i] = denom_a[i] + 
			  alpha_hat[i][endt]*beta_hat[i][endt]/(c[endt]*p_hat);
   }

   /** Find log of p **/
   log_csum = 0;
   for (t=0; t<=endt; t++)	
      log_csum += log10(c[t]);
   log_p = log10(p_hat) - log_csum; 

   /*PRINT NUMERATORS AND DENOMINATORS OF A, PI, MU, AND SIGMA VALUES  */
   printf ("%7.3e\n",log_p);
   for (i=0; i<hmm_par->no_states; i++)
      printf ("%7.3e\n", num_pi[i]);
   for (i=0; i<hmm_par->no_states; i++)
      for (j=0; j<hmm_par->no_states; j++)
	 printf ("%7.3e\t%7.3e\n", num_a[i][j], denom_a[i]);
   for (i=0; i<hmm_par->no_states; i++)
      printf ("%7.3e\t%7.3e\t%7.3e\n", num_mu[i], num_sigma[i], denom_mu_sigma[i]);
   printf("%d\n", delimiter);

}

/* 
 * FIND B(probability of an output given a certain state) USING 
 * GAUSSIAN DISTRIBUTION (mu and sigma)
 */

findb (bt, opt, hmm_par)

double	bt[], opt;
struct Hmm_Par *hmm_par;
{
   double b1;
   int    i;

   for (i=0; i<hmm_par->no_states; i++)  {
      /**
      for (k=1; k<=nst_tp; k++)  {
	 if (stno[h][0] == code[k][0])  {
	    muval[h] = mu[k];
	    sigmaval[h] = sigma[k];
	    break;
         }
         if ((k == nst_tp) && (stno[h][0] != code[nst_tp][0]))   {
	    printf ("No matching state types:\n");
            printf ("check state_no and code in init.dat\n\n");
	    exit(0);
         } 
      }
      **/
      /* EXPRESSION FOR GAUSSIAN DISTRIBUTION */
      b1 = exp(-1*(opt-hmm_par->mu[i])*(opt-hmm_par->mu[i])/
			(2*hmm_par->sigma[i]*hmm_par->sigma[i]));
      bt[i] = b1/(hmm_par->sigma[i]*sqrt(2*3.14)); 
   }
   return;
}

/*
 * SUBROUTINE
 *	char *chkmalloc() -- checks each malloc() for NULL pointer
 */
char *chkmalloc(size, name)
   unsigned int 	size;
   char			*name;
{
   char			*mp;

   if ((mp = (char *)malloc(size)) == NULL)	{
      printf ("\n\nMemory allocation failed for %s.\n", name);
      printf ("Exiting current program...\n");
      exit(0);
   }
   return (mp);
}
