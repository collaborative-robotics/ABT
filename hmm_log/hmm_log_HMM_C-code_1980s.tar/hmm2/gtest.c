/* gtest.c
*  This program tests the gaussian prob. of range of outputs
*/

#include <stdio.h>
#include <math.h>

main(argc,argv)

char  *argv[];
int   argc;
{
   int x1, x2, i;
   double mu, sigma; 
   double p, prob;

   if (argc < 5) {
      printf ("usage: gtest mu sigma start_opt end_opt\n");
      exit(0);
   }
   sscanf(argv[1],"%lf",&mu);
   sscanf(argv[2],"%lf",&sigma);
   sscanf(argv[3],"%d",&x1);
   sscanf(argv[4],"%d",&x2);
     for (i=x1; i<=x2; i++)  {
      p = exp(-1*((double)i-mu)*((double)i-mu)/(2*sigma*sigma));
      prob = p/(sigma*sqrt(2*3.14));
      printf ("%d %f\n", i, prob);
   }
}
