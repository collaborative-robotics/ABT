/* 
** PROGRAM
**	viterbi.c
**
** USAGE
**	cat data_file.asc | viterbi parameter_filename > optfile
**
** DESCRIPTION
**	This program takes in output values of the experiment and by using
** 	viterbi algorithm, it determines the state sequence of the
** 	experiment. The output probability in a given state, b[][], is 
** 	determined from the output range, br[][], by using gaussian 
** 	distribution within that range.
** 	Reference: An intro. to hidden Markov models by L.R. Rabiner. 
**            IEEE ASSP Jan. 1986.
**
** REVISION
**	Revision 2.0	paul lee 6/90
*/

#include <stdio.h>
#include <math.h>
#include "markov.h"

#define	JPL		0
#define	LORD		0
#define B5		0
#define HMMLORD		1

int read_ipt ();
char *chkmalloc ();
double getlog10();

int    *state, **psi;
double **del;
double **opt;
float  *time;

main(argc, argv)
   int 		argc;
   char 	*argv[];
{
   struct Hmm_Par	*hmm_par;

   int 		i,j, axis, index, chk;
   char		par_fname[40];

   int      	maxpsi, endt, t; /* t=no. of data pts  2<= t <= no_datas  */
   float    	x1, x2, x3, x4, x5, x6, x7, x8, x9;
   double   	d, maxdel, maxp;
   double   	**bt, *tmpdel;

   if (argc == 1)	{
      printf ("Usage: cat data_file.asc | viterbi parameter_filename\n\n");
      exit(0);
   }
   else	{
      strcpy (par_fname, argv[1]);
   }

   hmm_par = (struct Hmm_Par *) chkmalloc (sizeof(struct Hmm_Par), "hmm_par");

   if (read_ipt (par_fname, hmm_par) == -1)	{
      printf ("Parameter file %s does not exist.\n\n", par_fname); 
      exit(0);
   }

   /** Test mechanism **/
   if (argc > 2)	{
      if (strcmp(argv[2], "-test") == 0)	{
         /** Print values of a[][] and b[] **/
         printf ("no_states = %d\n", hmm_par->no_states);
         for (i=0; i<hmm_par->no_states; i++)	
            printf ("a[%d][%d] = %e\n", i, i, hmm_par->a[i][i]);
         for (axis=0; axis<hmm_par->no_axis; axis++)	{
	    printf ("axis = %s", hmm_par->axis_type[0][axis]);
            for (i=0; i<hmm_par->no_states; i++)	
               printf ("mu = %e\t sigma = %e\t state = %s\n", 
		hmm_par->mu[i][axis], hmm_par->sigma[i][axis], hmm_par->state_type[i]);
	    printf("\n");
         }
      }
   }

   /** Allocate mem space for global variables **/
   opt = (double **) chkmalloc (hmm_par->no_axis*sizeof(double *), "opt");
   for (i=0; i<hmm_par->no_axis; i++)
      opt[i] = (double *) chkmalloc (hmm_par->max_size*sizeof(double),"opt[i]");
   time = (float *) chkmalloc (hmm_par->max_size*sizeof(float), "time");
   psi = (int **) chkmalloc (hmm_par->no_states*sizeof(int *), "psi");
   del = (double **) chkmalloc (hmm_par->no_states*sizeof(double *), "del");

   /** Allocate mem space for local variables **/
   tmpdel = (double *) chkmalloc (hmm_par->no_states*sizeof(double), "tmpdel");
   bt = (double **) chkmalloc (hmm_par->no_states*sizeof(double *), "bt");
   for (i=0; i<hmm_par->no_states; i++)
      bt[i] = (double *)chkmalloc(hmm_par->no_axis*sizeof(double), "bt[state]");

   t = 0;

   /** Read force ascii data from stdin **/
/***
if JPL
   while (scanf("%f %f %f %f %f %lf %f %f %f %f %f", &time[t], &x1, &x2, 
		&x3, &x4, &xforce[t], &x5, &x6, &x7, &x8, &x9) > 0)   {
endif
if LORD
   while (scanf("%f %lf %f %f %f %f %f", &time[t], &xforce[t], &x1, &x2,
		 &x3, &x4, &x5) > 0)   {
endif
if B5
   while (scanf("%f %lf %f %f %f %f %f %f %f %f", &time[t], &xforce[t], 
		&x1, &x2, &x3, &x4, &x5, &x6, &x7, &x8) > 0)   {
endif
if HMMLORD
   while (scanf("%f %lf %f %f", &time[t], &xforce[t], &x1, &x2) > 0)   {
endif
***/
   do {
      if (hmm_par->no_axis == 1)	{
         /** Assume that it is X Axis Data **/
         chk = scanf("%f %lf %f %f %f %f %f %f %f %f", &time[t], &opt[0][t], 
		&x1, &x2, &x3, &x4, &x5, &x6, &x7, &x8);   
      }
      else if (hmm_par->no_axis == 2)	{
         /** Assume 1st is X, 2nd is Roll or Z Position **/
         if (strcmp(&(hmm_par->axis_type[0][1][0]), "rol") == 0)
            chk = scanf("%f %lf %f %f %lf %f %f %f %f %f", &time[t], 
		&opt[0][t], &x1, &x2, &opt[1][t], &x4, &x5, &x6, &x7, &x8);  
         else
            chk = scanf("%f %lf %f %f %f %f %f %lf %f %f", &time[t], &opt[0][t],
		 &x1, &x2, &x3, &x4, &x5, &x6, &x7, &opt[1][t]);  
      }
      else if (hmm_par->no_axis == 3)	{ 
         chk = scanf("%f %lf %f %f %lf %f %f %lf %f %f", &time[t], &opt[0][t], 
		&x1, &x2, &opt[1][t], &x4, &x5, &x6, &x7, &opt[2][t]);   
      }
      else {
         printf ("We don't have capability to read more than 3 axis yet.\n");
	 printf ("Program aborted.  Check your *.par file.\n");
	 exit (0);
      }
      t++;	/** Increment Time **/
   } while (chk > 0);	/** End of data **/

   if ((--t) > hmm_par->max_size)  {
      printf ("Length of output too large.\nMust allocate ");
      printf ("more space for the variables in \'*.par\'.\n\n");
      exit(0);
   }
   endt = t - 1;

   /** Allocate mem space for state, psi, and del **/
   state = (int *) chkmalloc (t*sizeof(int), "state");
   for (i=0; i<hmm_par->no_states; i++)	{
      psi[i] = (int *) chkmalloc (t*sizeof(int), "psi[i]");
      del[i] = (double *) chkmalloc (t*sizeof(double), "del[i]");
   }

   for (t=0; t<=endt; t++)	{
      findb (bt, hmm_par, t);
      if (t==0)  
         for (i=0; i<hmm_par->no_states; i++)   {
            tmpdel[i] = getlog10(hmm_par->pi[i]);
            for (axis=0; axis<hmm_par->no_axis; axis++)	{
               tmpdel[i] += getlog10(bt[i][axis]);
	    }
	    del[i][0] = tmpdel[i];
            /** del[i][0] = getlog10(hmm_par->pi[i]*bt[i]); **/
	    psi[i][0] = 1;
         }
      else       {
         for (j=0; j<hmm_par->no_states; j++)  {
	    maxdel = del[0][t-1] + getlog10(hmm_par->a[0][j]);
	    maxpsi = 1;
	    for (i=1; i<hmm_par->no_states; i++)  {
	       d = del[i][t-1] + getlog10(hmm_par->a[i][j]);
	       if (d > maxdel)  {
		  maxpsi = i+1;
		  maxdel = d;
               }
            }
	    tmpdel[j] = maxdel;
            for (axis=0; axis<hmm_par->no_axis; axis++)	{
               tmpdel[j] += getlog10(bt[j][axis]);
	    }
	    del[j][t] = tmpdel[j];
            /** del[j][t] = maxdel + getlog10(bt[j]);  **/
	    psi[j][t] = maxpsi;
         }
      }
   }
   maxp = del[0][endt];
   state[endt] = 1;
   for (i=1; i<hmm_par->no_states; i++)  {
      d = del[i][endt];
      if (d > maxp)  {
         maxp = d;
         state[endt] = i+1;
      }
   }
   for (t=endt-1; t>=0; t--)	{
      index = state[t+1] - 1;
      state[t] = psi[index][t+1];
   }

   /* PRINT OUTPUTS AND STATES  */
   for (t=0; t<=endt; t++)  
      printf ("%6.2f %7.3f %7.3f  %d  %s\n", time[t], opt[0][t],
              del[state[t]-1][t], state[t], hmm_par->state_type[state[t]-1]);
}

/* FIND B(probability of an output given a certain state) USING 
*  GAUSSIAN DISTRIBUTION (mu and sigma), AND STNO[I]
*  (phase of the task, such as tap, insert, move, extract).
*
*  GLOBALS ACCESSED
*	opt[axis][t];
*/

findb (bt, hmm_par, t)

double	**bt;
struct Hmm_Par *hmm_par;
int	t;
{
   double b1;
   int    i, axis;

   for (i=0; i<hmm_par->no_states; i++)  {
      /**
      for (k=1; k<=nst_tp; k++)  {
	 if (stno[i][0] == code[k][0])  {
	    muval = mu[k];
	    sigmaval = sigma[k];
	    break;
         }
         if ((k == nst_tp) && (stno[i][0] != code[nst_tp][0]))   {
	    printf ("No matching state types:\n");
            printf ("check state_no and code in init.dat\n\n");
	    exit(0);
         } 
      }
      **/
      /* EXPRESSION FOR GAUSSIAN DISTRIBUTION */
      for (axis=0; axis<hmm_par->no_axis; axis++)	{
         b1 = exp(-1*(opt[axis][t]-hmm_par->mu[i][axis])*(opt[axis][t]-hmm_par->mu[i][axis])/ (2*hmm_par->sigma[i][axis]*hmm_par->sigma[i][axis]));
         bt[i][axis] = b1/(hmm_par->sigma[i][axis]*sqrt(2*3.14)); 
      }
   }
   return;
}

double getlog10(x)
double x;
{
   double logval;

   if (x < 1.0E-150)
      logval = -1.0E250;   /* THIS VALUE SHOULD BE NEG INFINITY  */
   else
      logval = log10(x);
   return(logval);
}

/*
 * SUBROUTINE
 *	char *chkmalloc() -- checks each malloc() for NULL pointer
 */
char *chkmalloc(size, name)
   unsigned int 	size;
   char			*name;
{
   char			*mp;

   if ((mp = (char *)malloc(size)) == NULL)	{
      printf ("\n\nMemory allocation failed for %s.\n", name);
      printf ("Exiting current program...\n");
      exit(0);
   }
   return (mp);
}
