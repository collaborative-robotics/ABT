/* 
** PROGRAM
**	baum_welch2.c
**
** USAGE
**	cat baum_welch1.opt | baum_welch2 old_par_filename > new_par_fname
**
** DESCRIPTION
**  	This is the second program for Baum-Welch iterative procedure.  
**  	This program reads the values sent by the first program and 
**  	finds local optimum solution for a[i,j] and pi[i].
**
** REVISION
**  	Revision 2.0	paul lee  6/90
*/

#include <stdio.h>
#include <math.h>
#include "markov.h"

#define	DELIMITER	999

struct Ipt	{
	double 	log_p[NO_SAMPLES];
	double	*num_pi;
	double	**num_a;
	double	**denom_a;
	double	*num_mu;
	double	*num_sigma;
	double	*denom_mu_sigma;
};

struct Ipt_Sum	{
	double	*num_pi_sum;
	double	**num_a_sum;
	double	**denom_a_sum;
	double	*num_mu_sum;
	double	*num_sigma_sum;
	double	*denom_mu_sigma_sum;
};

int read_ipt();
char *chkmalloc();

main(argc, argv)
   int 	argc;
   char	*argv[];
{
   struct Hmm_Par	*hmm_par;
   struct Hmm_Par	*new_par;
   struct Ipt		*ipt;
   struct Ipt_Sum	*ipt_sum;

   char		par_fname[40];
   int 		i, j;     
   int      	delimiter, no_pval=0, pi_cnt=0;
   double   	pall = 0;

   if (argc == 1)	{
      printf ("Usage: cat baum_welch1.opt | baum_welch2 ");
      printf ("old_parameter_filename > new_par_fname\n\n");
      exit(0);
   }
   else	{

      strcpy (par_fname, argv[1]);
   }

   hmm_par = (struct Hmm_Par *) malloc (sizeof(struct Hmm_Par));

   if (read_ipt (par_fname, hmm_par) == -1)	{
      printf ("Parameter file %s does not exist.\n\n"); 
      exit(0);
   }

   /** Allocate mem space for new_par **/
   new_par = (struct Hmm_Par *) malloc (sizeof(struct Hmm_Par));
   new_par->no_states = hmm_par->no_states;
   new_par->state_type = (char **) malloc (new_par->no_states*sizeof(char *));
   new_par->pi = (double *) chkmalloc (
		new_par->no_states*sizeof(double), "new_par->pi");
   new_par->a = (double **) malloc (new_par->no_states*sizeof(double *));
   new_par->mu = (double *) chkmalloc (
		new_par->no_states*sizeof(double), "new_par->mu");
   new_par->sigma = (double *) chkmalloc (
		new_par->no_states*sizeof(double), "new_par->sigma");
   new_par->max_size = hmm_par->max_size;
   for (i=0; i<new_par->no_states; i++)	{
      new_par->state_type[i] = (char *) chkmalloc (
			STMAXCHAR, "new_par->state_type[i]");
      strcpy (new_par->state_type[i], hmm_par->state_type[i]);
      new_par->a[i] = (double *) chkmalloc (
      			new_par->no_states*sizeof(double), "new_par->a[i]");
   }

   /** Allocate mem space for input variables **/
   ipt = (struct Ipt *) malloc (sizeof(struct Ipt));
   ipt_sum = (struct Ipt_Sum *) malloc (sizeof(struct Ipt_Sum));

   ipt->num_a = (double **) malloc (hmm_par->no_states*sizeof(double *));
   ipt_sum->num_a_sum = (double **) malloc (
		hmm_par->no_states*sizeof(double *));
   ipt->denom_a = (double **) malloc (hmm_par->no_states*sizeof(double *));
   ipt_sum->denom_a_sum = (double **) malloc (
		hmm_par->no_states*sizeof(double *));
   for (i=0; i<hmm_par->no_states; i++)		{
      ipt->num_a[i] = (double *) chkmalloc (
			hmm_par->no_states*sizeof(double), "num_a[i]");
      ipt_sum->num_a_sum[i] = (double *) chkmalloc (
			hmm_par->no_states*sizeof(double), "num_a_sum[i]");
      ipt->denom_a[i] = (double *) chkmalloc (
			hmm_par->no_states*sizeof(double), "denom_a[i]");
      ipt_sum->denom_a_sum[i] = (double *) chkmalloc (
			hmm_par->no_states*sizeof(double), "denom_a_sum[i]");
   }
   ipt->num_pi = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "num_pi");
   ipt_sum->num_pi_sum = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "num_pi_sum");
   ipt->num_mu = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "num_mu");
   ipt_sum->num_mu_sum = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "num_mu_sum");
   ipt->num_sigma = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "num_sigma");
   ipt_sum->num_sigma_sum = (double *) chkmalloc (
		hmm_par->no_states*sizeof(double), "num_sigma_sum");
   ipt->denom_mu_sigma = (double *) chkmalloc(
		hmm_par->no_states*sizeof(double), "denom_mu_sigma");
   ipt_sum->denom_mu_sigma_sum = (double *) chkmalloc(
		hmm_par->no_states*sizeof(double), "denom_mu_sigma_sum");


   /** Initialize global variables to zero **/
   for (i=0; i<hmm_par->no_states; i++)  {
      ipt_sum->num_pi_sum[i] = ipt_sum->num_mu_sum[i] 
			 = ipt_sum->num_sigma_sum[i] 
			 = ipt_sum->denom_mu_sigma_sum[i] 
			 = 0;
      for (j=0; j<hmm_par->no_states; j++) 
         ipt_sum->num_a_sum[i][j] = ipt_sum->denom_a_sum[i][j] = 0;
   }

   while (scanf("%le", &(ipt->log_p[no_pval])) > 0)   {
      
      if (abs(ipt->log_p[no_pval]) > 0.0)	{
	 pall += ipt->log_p[no_pval];
      }
      for (i=0; i<hmm_par->no_states; i++)  {
	 scanf("%le", &(ipt->num_pi[i]));
	 if (ipt->num_pi[i] >= 0.0)  {
            if (i == 0) pi_cnt++;
	    ipt_sum->num_pi_sum[i] += ipt->num_pi[i];
         }
      }
      for (i=0; i<hmm_par->no_states; i++)  {
	 for (j=0; j<hmm_par->no_states; j++)  {
	    scanf("%le%le", &(ipt->num_a[i][j]), &(ipt->denom_a[i][j]));
	    if ((ipt->num_a[i][j] >= 0.0) && (ipt->denom_a[i][j] > 0.0))  {
	       ipt_sum->num_a_sum[i][j] += ipt->num_a[i][j];
	       ipt_sum->denom_a_sum[i][j] += ipt->denom_a[i][j];
            }
         }
      }
      for (i=0; i<hmm_par->no_states; i++)  {
	 scanf("%le%le%le", &(ipt->num_mu[i]), 
			    &(ipt->num_sigma[i]), 
			    &(ipt->denom_mu_sigma[i]));
	 if ((ipt->num_sigma[i] >= 0) && (ipt->denom_mu_sigma[i] > 0.0))  {
	    ipt_sum->num_mu_sum[i] += ipt->num_mu[i];
	    ipt_sum->num_sigma_sum[i] += ipt->num_sigma[i];
	    ipt_sum->denom_mu_sigma_sum[i] += ipt->denom_mu_sigma[i];
         }
      }
      scanf("%d", &delimiter);
      if (delimiter != DELIMITER)  {
	 printf ("Number of parameters does not match with ");
	 printf ("our specification at %dth sample\n\n", no_pval);
	 exit(0);
      }
      no_pval++;
      if (no_pval >= NO_SAMPLES)	{
	 printf ("#Number of samples exceeded max number allotted in ");
	 printf ("\'markov.h\'.\n#Rest of the samples ignored.\n");
	 break;
      }
   }

   for (i=0; i<new_par->no_states; i++)  {
      new_par->pi[i] = ipt_sum->num_pi_sum[i]/pi_cnt;
      new_par->mu[i] = ipt_sum->num_mu_sum[i]/ipt_sum->denom_mu_sigma_sum[i];
      new_par->sigma[i] = 
		sqrt(ipt_sum->num_sigma_sum[i]/ipt_sum->denom_mu_sigma_sum[i]);
      for (j=0; j<new_par->no_states; j++)  {
	 new_par->a[i][j] = 
			ipt_sum->num_a_sum[i][j]/ipt_sum->denom_a_sum[i][j];
      }
   }
   /**
   findmusig (newmuval, newsigvalsq, newmu, newsigma);
   **/

   /*  PRINT NEW PI AND A VALUES  */
   /**
   printf ("#\n#   P values are: ");
   for (i=0; i<no_pval; i++)  printf("%4.1e  ", ipt->log_p[i]);
   **/
   printf ("\n#   Combined P value is(in log 10): %4.1e\n", pall);
   printf ("#\n#\nno_states:\t %d\n#\n#\n", new_par->no_states);
   printf ("state_type:\t");
   for (i=0; i<new_par->no_states; i++)
      printf ("%s       ", new_par->state_type[i]);
   printf ("\n#\n#\ninit_dis:\t");
   for (i=0; i<new_par->no_states; i++)	{
      if (new_par->pi[i] < 9.9e-01)
         printf ("%4.1e  ", new_par->pi[i]);
      else
	 printf ("9.9e-01  ");
   }
   printf ("\n#\n#\n#\n");
   for (i=0; i<new_par->no_states; i++)  {
      printf ("a[%d,j]\t ", i);
      for (j=0; j<new_par->no_states; j++)	{
	 if (new_par->a[i][j] < 9.9e-01)
	    printf ("%4.1e   ", new_par->a[i][j]);
	 else
	    printf ("9.9e-01   ");
      }
      printf ("\n");
   }
   printf ("#\n#\n#\n");
   for (i=0; i<new_par->no_states; i++)	{
      printf ("%s:\t %5.1e \t %5.1e\n", new_par->state_type[i],
					new_par->mu[i],
					new_par->sigma[i]);
   }
   printf ("#\n#\n#\nmax_data_size:\t %d\n#\n", new_par->max_size);
}

/* NEW MU AND SIGMA CALCULATED ABOVE ARE DEFINED IN TERMS OF STATES.
*  THAT MEANS m1 AND m2 HAVE DIFFERENT MU AND SIGMA VALUES, FOR EXAMPLE.
*  FOLLOWING SUBROUTINE FINDS MU AND SIGMA BY FOLLOWING CATAGORIES:
*  MOVE, TAP, INSERT, AND EXTRACT.
*/

/**
findmusig (newmuval, newsigvalsq, newmu, newsigma)

double	newmuval[], newsigvalsq[], newmu[], newsigma[];
{
   int    k, h, no[N_TYPES];
   double nms, nss;

   for (k=1; k<=nst_tp; k++)  {
      no[k] = 0;
   }

   for (k=1; k<=nst_tp; k++)  {
      nms = nss = 0;
      for (h=1; h<=no_states; h++)  {
	 if (stno[h][0] == code[k][0])  {
	    nms += newmuval[h];
	    nss += newsigvalsq[h];
	    no[k]++;
         }
      }
      newmu[k] = nms/no[k];
      newsigma[k] = sqrt(nss/no[k]);
   }
   return;
}
**/

/*
 * SUBROUTINE
 *	char *chkmalloc() -- checks each malloc() for NULL pointer
 */
char *chkmalloc(size, name)
   unsigned 	size;
   char		*name;
{
   char		*mp;

   if ((mp = (char *)malloc(size)) == NULL)	{
      printf ("\n\nMemory allocation failed for %s.\n", name);
      printf ("Exiting current program...\n");
      exit(0);
   }
   return (mp);
}
