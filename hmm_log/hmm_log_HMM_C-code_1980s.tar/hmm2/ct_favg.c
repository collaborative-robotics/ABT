/*
** PROGRAM
**	ct_favg.c
**
** USAGE
**	cat header | ct_favg >> results
**
** DESCRIPTION
**	This program outputs results of completion time and force/torque avg.
**	Header file format is :
**		operator initials, task mode, date dir, ascii file name, 
**		jpl data or lord data
**		(e.g ms D/F 322 1.lasc.nc lord)
**	Using ascii file name(*.asc or *.lasc.nc) ascii file and state seg
**	file(*.asc.v.sg or *.lasc.nc.v.sg) are opened.  Completion time and
**	Avg force/torque are calculated from these files.
**	Completion time(ct) is found for both whole task and contact phase.
**	ct for whole task is measured from t1 to t3 in *.sg files.
**	ct for contact phases is time measured in d and c phases in *.sg files.
**	Avg force/torque are found found for d and c phases only.  They are
**	defined as:
**		Favg = 	(Sum of force during contact phases)/
**			(number of data pts in contact phases).
**	and similarly for Tavg.  The units are lbs and ft*lbs respectively.
**	Impulse force/torque sum is defined as:
**		IFsum = (Sum of force during contact phases)/(data rate)
**		      =	(Sum of force during contact phases)*
**			(Time duration of contact phases)/
**			(Number of data points during contact phases).
**	and similarly for ITsum.
**	The output file format is :
**		operator initials, task mode, date dir, ascii file name, 
**		jpl data or lord data, completion time, completion time during
**		contact phases, avg force, avg torque, impulse force sum,
**		impulse torque sum.
**		(e.g. ms N/P 3-22-90 1.asc jpl 200.02 122.40 10.4 3.2 2000 300)
**
** REVISION
**	1.0	paul lee 7/90
*/

#include <stdio.h>
#include <math.h>

#define	NO_STATES	20
#define MAXCHAR		10
#define FOREVER		1

struct State	{
	int	no_states;
	int	number[NO_STATES];
	char	type[NO_STATES][MAXCHAR];
	float	time[NO_STATES];
};

int read_sg ();
int find_state ();

char	BEG_TASK[MAXCHAR];
char	END_TASK[MAXCHAR];
char	CONTACT1[MAXCHAR]; 
char	CONTACT2[MAXCHAR];

main()
{
   FILE	*ascp, *sgp, *fopen();
   struct State	*state;

   int i;
   char ascname[100], sgname[100], current_state[MAXCHAR];
   char	name[10], task[10], datedir[10], file[25], topdir[10];

   int   no_data_pt;
   float beg_time, end_time, comp_time, contact_time, force, torque;
   double force_avg, torque_avg, impulse_force, impulse_torque;
   double force_sum, torque_sum;
   float time, gp, gr, gf1, gf2, xf, yf, zf, xt, yt, zt;

   strcpy (BEG_TASK, "t1");
   strcpy (END_TASK, "t3");
   strcpy (CONTACT1, "d");
   strcpy (CONTACT2, "c");

   state = (struct State *) malloc (sizeof(struct State));

   while (scanf("%s %s %s %s %s", name,task,datedir,file,topdir) > 0) {
      sprintf (ascname, "%s/%s/%s", topdir, datedir, file);
      sprintf (sgname, "%s.v.sg", ascname);
      if ((ascp = fopen(ascname,"r")) == NULL)	{
	 printf("Can't open file: %s\n", ascname);
	 continue;
      }
      if ((sgp = fopen(sgname,"r")) == NULL)	{
	 printf("Can't open file: %s\n", sgname);
	 continue; 
      } 
      if (read_sg (sgp, state) == -1)	{ 
	 printf("Can't find states in %s\n", sgname); 
	 continue; 
      } 
      contact_time = 0; 
      for (i=0; i<state->no_states; i++)	{ 
	 if (strcmp(state->type[i],BEG_TASK) == 0) 
	    beg_time = state->time[i]; 
	 else if (strcmp(state->type[i],END_TASK) == 0) 
	    end_time = state->time[i]; 
	 else if ((strcmp(state->type[i], CONTACT1) == 0) || 
		  (strcmp(state->type[i], CONTACT2) == 0)) 
	    contact_time += (state->time[i+1] - state->time[i]); 
      }
      comp_time = end_time - beg_time;
      no_data_pt = 0;
      force_sum = torque_sum = 0;
      while (FOREVER)	{
	 if (strcmp(topdir,"jpl") == 0)	{
	    if (fscanf(ascp, "%f %f %f %f %f %f %f %f %f %f %f", &time, &gp,
		&gr, &gf1, &gf2, &xf, &yf, &zf, &xt, &yt, &zt) < 0)
		   break;
         }
	 else if (strcmp(topdir,"lord") == 0)	{
	    if (fscanf(ascp, "%f %f %f %f %f %f %f", &time, &xf, &yf, &zf, 
		&xt, &yt, &zt) < 0)	
		   break;
	 }
	 else	{
	    printf ("%s in header file determines asc file format.\n", topdir);
	    printf ("jpl and lord are only two format that are currently ");
	    printf ("recognized.\n");
	    exit (0);
         }
	 if (find_state(current_state, time, state) != -1)	{
	    if ((strcmp(current_state, CONTACT1) == 0) ||
	        (strcmp(current_state, CONTACT2) == 0))	{
	       	   no_data_pt++;
	           force = (float) sqrt((xf*xf)+(yf*yf)+(zf*zf));
	           torque = (float) sqrt((xt*xt)+(yt*yt)+(zt*zt));
	           force_sum += (double) force;
	           torque_sum += (double) torque;
	    }
	 }
      }
      force_avg = force_sum/no_data_pt;
      torque_avg = torque_sum/no_data_pt;
      impulse_force = contact_time*force_avg;
      impulse_torque = contact_time*torque_avg;

      printf ("%s %s %s %s %s %7.2f %7.2f %7.3f %7.3f %10.3f %10.3f\n",
		name, task, datedir, file, topdir, comp_time, contact_time,
		force_avg, torque_avg, impulse_force, impulse_torque);
      fclose(sgp);
      fclose(ascp);
   }
}


int read_sg (fp, st)
   FILE	*fp;
   struct State	*st;
{
   int i = 0;

   while (fscanf(fp, "%d %s %f",&st->number[i],st->type[i],&st->time[i]) > 0)
      i++;
   st->no_states = i - 1; 
   return(0);
}

int find_state (current_state, time, state)
   char	*current_state;
   float time;
   struct State *state;
{
   int i;

   for (i=0; i<state->no_states; i++)	{
      if (time > state->time[i] && time < state->time[i+1])	{
	 strcpy (current_state, state->type[i]);
	 break;
      }
   }
   if (i == state->no_states)
      return(-1);
   else
      return(0);
}
