/*
** FUNCTION
**	int read_ipt () 
**
** USAGE
**	read_ipt (file_name, hmm_par)
**		char *file_name - file that contains hmm_par
**		struct Hmm_Par *hmm_par - hmm_parameters; struct in 'markov.h'
**
** DESCRIPTION
**	This program takes datas from a file, namely initial 
**	distribution(pi[]), state transition probabilities(a[][]), 
**	and outcome probabilities(b[] arrived from mu[] and sigma[]). 
**
**	This version of read_ipt () calculates self state from the 
**	1 - combination_of_other_states.  The reason is the loss of accuracy
**	with only two digit precision.
**
** RETURN VALUE
**	hmm_par - all the parameters used in hmm
**	read_ipt = -1 if file_name cannot be opened
**
** REVISION
**	Revision 2.1 	paul lee  6/90
*/

#include <math.h>
#include <stdio.h>
#include "markov.h"

#define	NO_STATES	1
#define STATE_TYPES 	2
#define PI		3
#define A		4

int read_ipt(file_name, hmm_par)
   char 		*file_name;
   struct Hmm_Par	*hmm_par;

{
	FILE	*fp, *fopen();

   	char	cmt_chk[80], c;
	int	no_states, axis = 0;
	int	i, j, k, end_of_a, beg_of_mu, end_of_mu;
	double	a_sum;

   	if ((fp = fopen(file_name,"r")) == NULL)   {
      		printf("\n       can't open:  %s\n\n",file_name);
      		return(-1);
   	}

	/**   READ DATA FROM file_name    **/
   	k = 0;
   	while (fscanf(fp,"%s",cmt_chk) > 0)   {
      		if (cmt_chk[0] == '#')  {
	 		while ((c =getc(fp)) != '\n' && c!=EOF);
	 		continue;
      		}
      		else  {
	 		k++;

	 		if (k == NO_STATES)	{ 
	    			fscanf(fp,"%d", &no_states);
				hmm_par->no_states = no_states;
				hmm_par->state_type = (char **) malloc (
					no_states*sizeof(char *));
				hmm_par->pi = (double *) malloc (
					no_states*sizeof(double));
				hmm_par->a = (double **) malloc (
					no_states*sizeof(double *));
				hmm_par->mu = (double **) malloc (
					no_states*sizeof(double *));
				hmm_par->sigma = (double **) malloc (
					no_states*sizeof(double *));
				hmm_par->axis_type = (char ***) malloc (
					no_states*sizeof(char **));
				end_of_a = hmm_par->no_states + PI;
				beg_of_mu = end_of_a + 2;
				end_of_mu = beg_of_mu + hmm_par->no_states - 1;
			}
         
	 		else if (k == STATE_TYPES)   {
	    			for (j=0; j<no_states; j++)	{
					hmm_par->state_type[j] = (char *)
							malloc (STMAXCHAR);
	       				fscanf(fp,"%s",hmm_par->state_type[j]);
				}
         		}

         		/**  INITIAL DISTRIBUTION: pi[j]  **/
         		else if (k == PI)   {
	    			for (j=0; j<no_states; j++)   
					fscanf(fp,"%le",&(hmm_par->pi[j]));
			}

         		/* STATE TRANSITION PROBABILITIES a[k-A][j]  */
         		else if (k >= A && k <= end_of_a)  { 
				hmm_par->a[k-A] = (double *) malloc (
						no_states*sizeof(double));
				/** Initialize a_sum **/
				a_sum = 0;
	    			for (j=0; j<no_states; j++)  {
					fscanf(fp,"%le", &(hmm_par->a[k-A][j]));
					/** If a[][] is not a self state **/
					if (j != (k-A))	{
						/** Read a[][] from *.par **/
						a_sum += hmm_par->a[k-A][j];
					}
				}
				/** a[i][i] = 1 - all_other_states **/
				hmm_par->a[k-A][k-A] = 1 - a_sum;
			}

			/** NO. OF AXIS TO DETERMINE HOW MANY mu & and sigma **/
			else if (k == end_of_a + 1)	{
				fscanf (fp, "%d", &(hmm_par->no_axis));
				/** ALLOCATE MEM FOR NO. OF AXIS **/
				for (i=0; i<hmm_par->no_states; i++)	{
					hmm_par->mu[i] = (double *) malloc (
					       hmm_par->no_axis*sizeof(double));
					hmm_par->sigma[i] = (double *) malloc (
					       hmm_par->no_axis*sizeof(double));
					hmm_par->axis_type[i] = (char **) 
					malloc(hmm_par->no_axis*sizeof(char *));
				     	for (j=0; j<hmm_par->no_axis; j++) 
						hmm_par->axis_type[i][j] = 
						   (char *) malloc (STMAXCHAR);
				}
			}

	 		/* PROBABLE OUTCOME SEQUENCES  */
         		else if (k >= beg_of_mu && k <= end_of_mu)	{
	    			fscanf(fp,"%le%le%s",
					&(hmm_par->mu[k-beg_of_mu][axis]),
					&(hmm_par->sigma[k-beg_of_mu][axis]),
					hmm_par->axis_type[k-beg_of_mu][axis]);
				if (k == end_of_mu)	{
					axis++;
					if (axis < hmm_par->no_axis)	{
						beg_of_mu = beg_of_mu + hmm_par->no_states;
						end_of_mu = end_of_mu + hmm_par->no_states;
					}
				}
			}

			/* MAX NUMBER OF DATA SIZE */
			else if (k == end_of_mu+1)
				fscanf(fp,"%d", &(hmm_par->max_size));
   		}
  	}
   	close (fp);
   	return(0);
}
