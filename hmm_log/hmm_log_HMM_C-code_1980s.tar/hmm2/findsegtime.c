/*
** PROGRAM
**	findsegtime.c
**
** USAGE
**	cat viterbi_opt | findsegtime > opt_file_name
**
** DESCRIPTION
**	This program finds the time when viterbi state transition occurred.
**	The output is state_type and time.
**
** REVISION
**	Revision 1.0	paul lee 6/90
*/

#include <stdio.h>

#define MAXST	10000
#define MAXCHAR	10

char state_type[MAXST][MAXCHAR];
int  state[MAXST];
float time[MAXST];

main()
{

   char st_type[MAXCHAR];
   int  st;
   float t, xforce, del;

   int i, st_cnt;

   st_cnt = 0;
   scanf ("%f %f %f %d %s", &time[st_cnt], &xforce, &del, 
			&state[st_cnt], state_type[st_cnt]);
   while (scanf("%f %f %f %d %s", &t, &xforce, &del, &st, st_type) > 0)	{
      if (st != state[st_cnt])	{
	 st_cnt++;
	 time[st_cnt] = t;
	 state[st_cnt] = st;
	 strcpy (state_type[st_cnt], st_type);
      }
   }
   for (i=0; i<=st_cnt; i++)
      printf ("%d  %s\t%6.2f\n", state[i], state_type[i], time[i]);
   printf ("%d  end\t%6.2f\n", st, t);
}

