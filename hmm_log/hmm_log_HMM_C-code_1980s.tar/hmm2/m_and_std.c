/*
** PROGRAM
**	m_and_std.c
**
** USAGE
** 	cat *.results | m_and_std > optfile
**
** DESCRIPTION
**	Find the mean and standard deviation.  
**
**	The input file is:
**	operator initials, task mode, date directory, file name, top directory,
**	completion time, time duration of contact phase, Favg, Tavg,
**	impulse force sum, impulse torque sum.
**
**	The output file is:
**	mean comp time, standard deviation(std) of comp time, mean contact
**	phase time, std contact phase time, mean Favg, std Favg, mean Tavg, 
**	std Tavg, mean IFsum, std IFsum, mean ITsum, avg ITsum.
**
** REVISION
**	Revision 1.0	paul lee 7/90
*/

#include <stdio.h>
#include <math.h>

#define MAXIPT	5000
#define IPTVAR	6

double	ipt[IPTVAR][MAXIPT], sum[IPTVAR];
double	mu_ipt[IPTVAR], sigma_ipt[IPTVAR];

main()
{
   int i, j, n=0;
   char	name[10], task[10], datedir[10], file[25], topdir[10];

   for (i=0; i<IPTVAR; i++) sum[i] = 0;

   while (scanf ("%s %s %s %s %s %lf %lf %lf %lf %lf %lf",
	name, task, datedir, file, topdir, &ipt[0][n], &ipt[1][n],
	&ipt[2][n], &ipt[3][n], &ipt[4][n], &ipt[5][n]) > 0)  {

	for (i=0; i<IPTVAR; i++)	{
	   sum[i] += ipt[i][n];
     	}
	n++;
   }
   for (i=0; i<IPTVAR; i++)
      mu_ipt[i] = sum[i]/n;

   for (i=0; i<IPTVAR; i++)  sum[i] = 0;
   for (j=0; j<n; j++)	{
      for (i=0; i<IPTVAR; i++)	
         sum[i] += ((ipt[i][j] - mu_ipt[i])*(ipt[i][j] - mu_ipt[i]));
   }
   for (i=0; i<IPTVAR; i++)
      sigma_ipt[i] = sqrt(sum[i]/n);

   for (i=0; i<IPTVAR; i++)
      printf ("%10.2f %10.2f ", mu_ipt[i], sigma_ipt[i]);
   printf ("\n");
}




