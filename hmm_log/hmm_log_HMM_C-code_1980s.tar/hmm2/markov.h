/*  
 * markov.h
 *
 * Revision 2.0		paul lee 6/90
 */

#define NO_SAMPLES	500  /*	NO. OF SAMPLES USED TO 
				TRAIN BAUM-WELCH ALGORITHM */

#define	STMAXCHAR	5	/* Max char to describe state type */

struct Hmm_Par {
	double	*pi;
	double	**a;
	double	**mu;
	double	**sigma;
	char	***axis_type;
	int	no_states;
	int	no_axis;
	char	**state_type;
	int	max_size;
};
