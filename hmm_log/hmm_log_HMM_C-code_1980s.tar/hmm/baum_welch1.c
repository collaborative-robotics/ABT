/* baum_welch1.c
*
*  This program is first of the two programs that uses Baum-Welch
*  iterative procedure to optimize the parameters a[i,j] and pi[i].
*  This program generates numerator and denominator values for the
*  parameters a[i,j] and pi[i].  The second program uses these values
*  to find locally optimum solution for a[i,j] and pi[i].
*
*  pl  6/89
*/

#include <stdio.h>
#include <math.h>
#include "markov.h"

int i,j,t;           	    /*  i=one state        1<= i <= no_states
		                j=another state    1<= j <= no_states
		                t=no. of data pts  2<= t <= no_datas  */

static char   stno[MAXST][4], code[N_TYPES][2];
static int    no_states, nst_tp, no_data;
static long   seed;
static float  delt, time;
static double pi[MAXST], a[MAXST][MAXST], mu[N_TYPES], sigma[N_TYPES];
static double opt[TOT], b[MAXST][TOT], alpha[MAXST][TOT];
static double beta[MAXST][TOT], na[MAXST][MAXST], da[MAXST], npi[MAXST];
static double nmu[MAXST], nsigma[MAXST], d[MAXST]; 

main()
{
int      ichk, endt;
float    x1, x2, x3, x4, x5, x6, x7, x8;
double   fsum, bsum, num, denom, psum, p, nmusum, nsigmasum, alphabeta;
double   bval[MAXST], muval[MAXST], sigmaval[MAXST];

   read_ipt ("baum_welch.dat", pi, a, mu, sigma, &no_states, &nst_tp, stno,
	      code, &no_data, &delt, &seed);

   t = 1;
   while (scanf("%f%lf%f%f%f%f%f%f%f%f", &time, &opt[t], &x1, &x2,
		 &x3, &x4, &x5, &x6, &x7, &x8) > 0)   {
      if (++t > TOT)  {
	 printf ("Length of output too large.");
	 printf ("Must allocate more space for the variables.\n\n");
	 exit(0);
      }	 
   }
   endt = t - 1;
   findb (bval, opt[1], muval, sigmaval);
   for (i=1; i<=no_states; i++)  {
      alpha[i][1] = pi[i]*bval[i];
      beta[i][endt] = 1;
   }

   for (t=1; t<=endt-1; t++)  {
      findb (bval, opt[t+1], muval, sigmaval);
      for (j=1; j<=no_states; j++)  {
	 b[j][t+1] = bval[j];
	 fsum = 0;
	 for (i=1; i<=no_states; i++)  {
	    fsum += alpha[i][t]*a[i][j];
         }
	 alpha[j][t+1] = fsum*b[j][t+1];
      }
   }      

   for (t=endt-1; t>=1; t--)  {
      for (i=1; i<=no_states; i++)  {
	 bsum = 0;
	 for (j=1; j<=no_states; j++)  {
	    bsum += a[i][j]*b[j][t+1]*beta[j][t+1];
         }
         beta[i][t] = bsum;
      }
   }

   psum = 0;
   for (i=1; i<=no_states; i++)  {
      psum += alpha[i][endt];
   }
   p = psum;

   for (i=1; i<=no_states; i++)  {
      ichk = i;
      denom = 0;
      for (j=1; j<=no_states; j++)  {
	 num = 0;
	 for (t=1; t<=endt-1; t++)   {
	    num += alpha[i][t]*a[i][j]*b[j][t+1]*beta[j][t+1];
	    if (i == ichk)  
               denom += alpha[i][t]*beta[i][t];
         }
	 na[i][j] = num/p;
	 ichk++;
      }
      da[i] = denom/p;
   }

   for (i=1; i<=no_states; i++) {
      npi[i] = alpha[i][1]*beta[i][1];
      nmusum = nsigmasum = 0;
      for (t=1; t<=endt; t++)  {
	alphabeta = alpha[i][t]*beta[i][t];
	nmusum += alphabeta*opt[t];
	nsigmasum += alphabeta*(opt[t]-muval[i])*(opt[t]-muval[i]);
      }
      nmu[i] = nmusum/p;
      nsigma[i] = nsigmasum/p;
      d[i] = da[i] + alpha[i][endt]*beta[i][endt]/p;
   }

   /*PRINT NUMERATORS AND DENOMINATORS OF A, PI, MU, AND SIGMA VALUES  */
   printf ("%7.3e\n",p);
   for (i=1; i<=no_states; i++)
      printf ("%7.3e\n", npi[i]);
   for (i=1; i<=no_states; i++)
      for (j=1; j<=no_states; j++)
	 printf ("%7.3e\t%7.3e\n", na[i][j], da[i]);
   for (i=1; i<=no_states; i++)
      printf ("%7.3e\t%7.3e\t%7.3e\n", nmu[i], nsigma[i], d[i]);
   printf("999\n");

}

/* FIND B(probability of an output given a certain state) USING 
*  GAUSSIAN DISTRIBUTION (mu and sigma), AND STNO[I]
*  (phase of the task, such as tap, insert, move, extract).
*/

findb (bval, opt, muval, sigmaval)

double	bval[], opt, muval[], sigmaval[];
{
   double b1;
   int    k, h;

   for (h=1; h<=no_states; h++)  {
      for (k=1; k<=nst_tp; k++)  {
	 if (stno[h][0] == code[k][0])  {
	    muval[h] = mu[k];
	    sigmaval[h] = sigma[k];
	    break;
         }
         if ((k == nst_tp) && (stno[h][0] != code[nst_tp][0]))   {
	    printf ("No matching state types:\n");
            printf ("check state_no and code in init.dat\n\n");
	    exit(0);
         } 
      }
      /* EXPRESSION FOR GAUSSIAN DISTRIBUTION */
      b1 = exp(-1*(opt-muval[h])*(opt-muval[h])/(2*sigmaval[h]*sigmaval[h]));
      bval[h] = b1/(sigmaval[h]*sqrt(2*3.14)); 
   }
   return;
}

