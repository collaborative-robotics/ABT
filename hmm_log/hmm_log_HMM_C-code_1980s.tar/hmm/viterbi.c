/* viterbi.c
*
*  This program takes in output values of the experiment and by using
*  viterbi algorithm, it determines the state sequence of the
*  experiment. The output probability in a given state, b[][], is 
*  determined from the output range, br[][], by using gaussian 
*  distribution within that range.
*  Reference: An intro. to hidden Markov models by L.R. Rabiner. 
*             IEEE ASSP Jan. 1986.
*
*  pl  12/88
*/

#include <stdio.h>
#include <math.h>
#include "markov.h"

int i,j,t;            	    /*  i=one state        1<= i <= no_states
		                j=another state    1<= j <= no_states
		                t=no. of data pts  2<= t <= no_datas  */
double getlog10();

static char   stno[MAXST][4], code[N_TYPES][2];
static int    state[TOT], psi[MAXST][TOT], no_states, nst_tp, no_data;
static long   seed;
static float  delt, time[TOT];
static double pi[MAXST], a[MAXST][MAXST], mu[N_TYPES], sigma[N_TYPES];
static double del[MAXST][TOT], opt[TOT];

main()
{
   int      maxpsi, endt;
   double   b[MAXST], d, maxdel, maxp;
   float    x1, x2, x3, x4, x5, x6, x7, x8;

   read_ipt ("init.dat", pi, a, mu, sigma, &no_states, &nst_tp, stno,
	      code, &no_data, &delt, &seed);
   t = 1;
   while (scanf("%f%lf%f%f%f%f%f%f%f%f", &time[t], &opt[t], &x1, &x2,
		 &x3, &x4, &x5, &x6, &x7, &x8) > 0)   {
      findb (b, opt[t]);
      if (t==1)  
         for (i=1; i<=no_states; i++)   {
            del[i][1] = getlog10(pi[i]*b[i]);
	    psi[i][1] = 0;
         }
      else       {
         for (j=1; j<=no_states; j++)  {
	    maxdel = del[1][t-1] + getlog10(a[1][j]);
	    maxpsi = 1;
	    for (i=2; i<=no_states; i++)  {
	       d = del[i][t-1] + getlog10(a[i][j]);
	       if (d > maxdel)  {
		  maxpsi = i;
		  maxdel = d;
               }
            }
            del[j][t] = maxdel + getlog10(b[j]);
	    psi[j][t] = maxpsi;
         }
      }
      if (++t > TOT)  {
	 printf ("Length of output too large.");
	 printf ("Must allocate more space for the variables.\n\n");
	 exit(0);
      }	 
   }
   endt = t-1;
   maxp = del[1][endt];
   state[endt] = 1;
   for (i=2; i<=no_states; i++)  {
      d = del[i][endt];
      if (d > maxp)  {
         maxp = d;
         state[endt] = i;
      }
   }
   for (t=endt-1; t>=1; t--)
      state[t] = psi[state[t+1]][t+1];

   /* PRINT OUTPUTS AND STATES  */
   for (t=1; t<=endt; t++)  
      printf ("%6.2f %7.3f %7.3f  %d\n", time[t], opt[t],
              del[state[t]][t], state[t]);
}

/* FIND B(probability of an output given a certain state) USING 
*  GAUSSIAN DISTRIBUTION (mu and sigma), AND STNO[I]
*  (phase of the task, such as tap, insert, move, extract).
*/

findb (b, opt)

double	b[], opt;
{
   double b1, muval, sigmaval;
   int    k;

   for (i=1; i<=no_states; i++)  {
      for (k=1; k<=nst_tp; k++)  {
	 if (stno[i][0] == code[k][0])  {
	    muval = mu[k];
	    sigmaval = sigma[k];
	    break;
         }
         if ((k == nst_tp) && (stno[i][0] != code[nst_tp][0]))   {
	    printf ("No matching state types:\n");
            printf ("check state_no and code in init.dat\n\n");
	    exit(0);
         } 
      }
      /* EXPRESSION FOR GAUSSIAN DISTRIBUTION */
      b1 = exp(-1*(opt-muval)*(opt-muval)/(2*sigmaval*sigmaval));
      b[i] = b1/(sigmaval*sqrt(2*3.14)); 
   }
   return;
}

double getlog10(x)
double x;
{
   double logval;

   if (x < 1.0E-150)
      logval = -1.0E250;   /* THIS VALUE SHOULD BE NEG INFINITY  */
   else
      logval = log10(x);
   return(logval);
}
