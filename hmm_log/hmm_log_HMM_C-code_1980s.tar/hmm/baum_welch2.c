/* baum_welch2.c
*
*  This is the second program for Baum-Welch iterative procedure.  
*  This program reads the values sent by the first program and 
*  finds local optimum solution for a[i,j] and pi[i].
*
*  pl  6/89
*/

#include <stdio.h>
#include <math.h>
#include "markov.h"

int i,j;           	    /*  i=one state        1<= i <= no_states
		                j=another state    1<= j <= no_states  */

static char   stno[MAXST][4], code[N_TYPES][2];
static int    no_states, nst_tp, no_data;
static long   seed;
static float  delt;
static double pi[MAXST], a[MAXST][MAXST], mu[N_TYPES], sigma[N_TYPES];
static double na[MAXST][MAXST], da[MAXST][MAXST], npi[MAXST], p[NO_SAMPLES];
static double nmu[MAXST], nsigma[MAXST], d[MAXST];
static double newa[MAXST][MAXST], newpi[MAXST], newmu[N_TYPES];
static double newsigma[N_TYPES], nasum[MAXST][MAXST];
static double dasum[MAXST][MAXST], pisum[MAXST];
static double nmusum[MAXST], nsigmasum[MAXST], dsum[MAXST];

main()
{
   int      end_chk, no_pval=0;
   double   newmuval[MAXST], newsigvalsq[MAXST];
   double   pall = 0;

   read_ipt ("init.dat", pi, a, mu, sigma, &no_states, &nst_tp, stno,
	      code, &no_data, &delt, &seed);

   for (i=1; i<=no_states; i++)  {
      pisum[i] = nmusum[i] = nsigmasum[i] = dsum[i] = 0;
      for (j=1; j<=no_states; j++) nasum[i][j] = dasum[i][j] = 0;
   }

   while (scanf("%le", &p[no_pval]) > 0)   {
      for (i=1; i<=no_states; i++)  {
	 scanf("%le", &npi[i]);
	 if (npi[i] >= 0.0)  {
	    pisum[i] += npi[i]/p[no_pval];
         }
      }
      for (i=1; i<=no_states; i++)  {
	 for (j=1; j<=no_states; j++)  {
	    scanf("%le%le", &na[i][j], &da[i][j]);
	    if ((na[i][j] >= 0.0) && (da[i][j] > 0.0))  {
	       nasum[i][j] += na[i][j];
	       dasum[i][j] += da[i][j];
            }
         }
      }
      for (i=1; i<=no_states; i++)  {
	 scanf("%le%le%le", &nmu[i], &nsigma[i], &d[i]);
	 if ((nsigma[i] >= 0) && (d[i] > 0.0))  {
	    nmusum[i] += nmu[i];
	    nsigmasum[i] += nsigma[i];
	    dsum[i] += d[i];
         }
      }
      scanf("%d", &end_chk);
      if (end_chk != 999)  {
	 printf ("Number of parameters does not match with ");
	 printf ("our specification\n\n");
	 exit(0);
      }
      no_pval++;
   }

   for (i=0; i<no_pval; i++)  
      pall += log10(p[i]);

   for (i=1; i<=no_states; i++)  {
      newpi[i] = pisum[i]/no_pval;
      newmuval[i] = nmusum[i]/dsum[i];
      newsigvalsq[i] = nsigmasum[i]/dsum[i];
      for (j=1; j<=no_states; j++)  {
	 newa[i][j] = nasum[i][j]/dasum[i][j];
      }
   }
   findmusig (newmuval, newsigvalsq, newmu, newsigma);

   /*  PRINT NEW PI AND A VALUES  */
   printf ("#\n#   P values are: ");
   for (i=0; i<no_pval; i++)  printf("%4.1e  ", p[i]);
   printf ("\n#   Combined P value is(in log 10): %5.2f\n", pall);
   printf ("#\n#\nno_states:\t %d\n#\n#\n", no_states);
   printf ("state_no:\t");
   for (i=1; i<=no_states; i++)
      printf ("%s       ", stno[i]);
   printf ("\n#\n#\ninit_dis:\t");
   for (i=1; i<=no_states; i++)
      printf ("%4.1e  ", newpi[i]);
   printf ("\n#\n#\n#\n");
   for (i=1; i<=no_states; i++)  {
      printf ("a[%d,j]\t ", i);
      for (j=1; j<=no_states; j++)
	 printf ("%4.1e   ", newa[i][j]);
      printf ("\n");
   }
   printf ("#\n#\n#\nno_state_types:\t %d\n#\n#\n", nst_tp);
   printf ("move:\t %s \t %5.1e \t %5.1e\n", code[1],newmu[1],newsigma[1]);
   printf ("tap:\t %s \t %5.1e \t %5.1e\n", code[2],newmu[2],newsigma[2]);
   printf ("insert:\t %s \t %5.1e \t %5.1e\n", code[3],newmu[3],newsigma[3]);
   printf ("extract: %s \t %5.1e \t %5.1e\n", code[4],newmu[4],newsigma[4]);
   printf ("#\n#\n#\nno_data:\t %d\n#\n", no_data);
   printf ("delt(data/sec):\t %6.1f\n#\n", delt);
   printf ("seed:\t %d\n", seed);
}

/* NEW MU AND SIGMA CALCULATED ABOVE ARE DEFINED IN TERMS OF STATES.
*  THAT MEANS m1 AND m2 HAVE DIFFERENT MU AND SIGMA VALUES, FOR EXAMPLE.
*  FOLLOWING SUBROUTINE FINDS MU AND SIGMA BY FOLLOWING CATAGORIES:
*  MOVE, TAP, INSERT, AND EXTRACT.
*/

findmusig (newmuval, newsigvalsq, newmu, newsigma)

double	newmuval[], newsigvalsq[], newmu[], newsigma[];
{
   int    k, h, no[N_TYPES];
   double nms, nss;

   for (k=1; k<=nst_tp; k++)  {
      no[k] = 0;
   }

   for (k=1; k<=nst_tp; k++)  {
      nms = nss = 0;
      for (h=1; h<=no_states; h++)  {
	 if (stno[h][0] == code[k][0])  {
	    nms += newmuval[h];
	    nss += newsigvalsq[h];
	    no[k]++;
         }
      }
      newmu[k] = nms/no[k];
      newsigma[k] = sqrt(nss/no[k]);
   }
   return;
}
