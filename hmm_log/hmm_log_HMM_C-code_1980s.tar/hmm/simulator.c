/*simulator.c
*
* This program gets probability distributions from read_ipt.c, and then
* using a random number generator, it generates a state sequence.  
* It then uses the state sequence and gaussisan distribution to generate 
* an outcome.
*
* pl 11/88
*/

#include <stdio.h>
#include <math.h>
#include "markov.h"

#define N_RAND		50

char   stno[MAXST][4], code[N_TYPES][2];
int    i, k, no_states, nst_tp, no_data;
long   random(), seed;
float  rand_gen(), gauss(), ran_norm, delt;
double pi[MAXST], a[MAXST][MAXST], mu[N_TYPES], sigma[N_TYPES];

main(argc, argv)
   int    argc;
   char   *argv[];
{
   int    state, stp;
   float  no, time;
   double muval, sigmaval, result;

   read_ipt("init.dat", pi, a, mu, sigma, &no_states, &nst_tp, stno,
	     code, &no_data, &delt, &seed);
   srandom(seed);
   ran_norm = (float)(1.0/pow(2.0,31.0)); /* make random no.'s 0-1.0 */
   no = rand_gen();
   stp = find_st(no, pi);
   for (i=1; i<no_data; i++)  {
      no = rand_gen();
      state = find_st(no, a[stp]);

   /* GENERATE THE OUTPUTS   */
      for (k=1; k<=nst_tp; k++)  {
	 if (stno[state][0] == code[k][0])  {
	    muval = mu[k];
	    sigmaval = sigma[k];
	    break;
         }
         if ((k == nst_tp) && (stno[i][0] != code[nst_tp][0]))   {
	    printf ("No matching state types:\n");
	    printf ("Check state_no and code in init.dat\n\n");
	    exit(0);
         }
      }
      result = gauss(muval, sigmaval);

   /*  PRINT THE GENERATED OUTPUT AND THE STATE SEQUENCE  */
   time = (float) i/delt;
   printf("%6.2f  %7.3f\t%d\n",time ,result, state); 

   stp = state;
   }
}

/* Find the next state using a random no. and previous state prob  */ 
find_st(no, st)

float no;
double st[MAXST];
{
   float r=0;
   int  n=1;

   while (r<1)  {
      r += st[n];
      if (no < r)  break; 
      n++;
   }
   return(n);
}

/* Make random no. from 0 - 1  */
float rand_gen()
{
   float index;

   index = (float) random()*ran_norm;
   return(index);
}

/* Generate random no. using gaussian distribution.  */
/* mu = mean(center pt) of the distribution;
   sigma = standard deviation; small sigma => sharp curve  */

float gauss(mu,sigma)

float mu, sigma;
{
   float drand = 0.0;
   int i;

   for (i=0;i<N_RAND;i++) 
      drand += (float)random();
   drand *= ran_norm/N_RAND;
   drand = mu + (drand - 0.478)*sigma*N_RAND*0.785;
   return(drand);
}

