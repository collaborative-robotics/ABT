/*  markov.h
*/
#define MAXST		20     /* NO. OF DIFFERENT TYPES OF STATES    */
#define TOT		1000  /* TOTAL NO. OF OUTPUTS                */
#define N_TYPES		9    /* NO. OF STATE TYPES   + 1            */
#define NO_SAMPLES	100 /* NO. OF SAMPLES USED TO TRAIN BAUM-WELCH ALGORITHM */
