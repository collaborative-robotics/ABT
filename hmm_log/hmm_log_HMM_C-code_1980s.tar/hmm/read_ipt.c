/*read_ipt.c 
*
* This program takes datas from a file, namely initial distribution,
* state transition probabilities, and outcome probabilities. 
*
* pl 10/88
*/

#include <math.h>
#include <stdio.h>

#define MAXST	20

int	i,j,k;
FILE	*fp, *fopen();

read_ipt(fname, pi, a, mu, sigma, no_states, nst_tp, stno, code, no_data,
	 delt, seed)
   char *fname, stno[][4], code[][2];
   double pi[], a[][MAXST], mu[], sigma[];
   float  *delt;
   int *no_states, *nst_tp, *no_data;
   long *seed;

{
   int	no_var;
   char	cmt_chk[20],c;

   if ((fp = fopen(fname,"r")) == NULL)   {
      printf("\n       can't open:  %s\n\n",fname);
      exit(0);
   }

/* READ DATA FROM init.dat */
   k = 0;
   while (fscanf(fp,"%s",cmt_chk) > 0)   {
      if (cmt_chk[0] == '#')  {
	 while ((c =getc(fp)) != '\n' && c!=EOF);
	 continue;
      }
      else  {
	 k++;

	 if (k == 1) 
	    fscanf(fp,"%d",no_states);
         
	 if (k == 2)   {
	    for (i=1; i<=*no_states; i++)
	       fscanf(fp,"%s",&stno[i][0]);
         }

         /* INITIAL DISTRIBUTION: pi[j]  */
         if (k == 3)   
	    for (j=1; j<=*no_states; j++)   fscanf(fp,"%le",&pi[j]);

         i = *no_states+3;

         /* STATE TRANSITION PROBABILITIES a[k-2][j]  */
         if (k > 3 && k <= i)   
	    for (j=1; j<=*no_states; j++)  fscanf(fp,"%le",&a[k-3][j]);

         i++;

	 if (k == i)
	    fscanf(fp,"%d",nst_tp);

	 /* PROBABLE OUTCOME SEQUENCES  */
         if (k > i && k <= i+(*nst_tp))
	    fscanf(fp,"%s%le%le",&code[k-i][0],&mu[k-i],&sigma[k-i]);

	 i += *nst_tp+1;

	 if (k == i)
	    fscanf(fp,"%d",no_data);

         if (k == (++i))
	    fscanf(fp,"%f",delt);

         if (k == (++i))
	    fscanf(fp,"%ld",seed);

         fscanf (fp,"\n");
      }
   }
   close (fp);
}
