/* this program tests the improvement of P(O | Lambda) from BW Estimation */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "HMMtype.h"
#include "OHMMlib.h"

#define MAX_LEN  2000

int find_p(char *hmm_file, char *result_file)
{
  HMM *hmm = NULL;
  OSet O;
  int i, j;
  FILE *in_file, *out_file;
  char str_temp[255];
  int *Q;

  if (OHMM_read_lambda(&hmm, hmm_file) != HMM_OK)
    abort();


/* Open result file */
  if((out_file = fopen(result_file, "w")) == NULL)
    abort();

/* create the observation array */

  O.size = 1;
  O.count = 230;
  O.o = (double **) safe_malloc(sizeof(double *));
  O.o[0] = (double *) safe_calloc(O.count, sizeof(double));


  Q = (int *) safe_calloc(O.count, sizeof(int));

/* Generate observation sequence */

  OHMM_gen_obs(hmm, &O, &Q);
  
/* Write result file */
  for (j=0; j < O.count; j++) {
    fprintf(out_file, "%i %12.6f %i\n", j, O.o[0][j], Q[j]);}

  free(O.o);
  free(Q);
  OHMM_free(hmm);
}


void main(int argc, char **argv)
{

  if (argc != 3) {
    fprintf(stderr, "wrong number of arguments, ");
    fprintf(stderr, "try evalOHMM hmm out_file\n");
    exit(1);
  }

  find_p(argv[1], argv[2]);
/*
  fprintf(stdout, "%le %8.6f\n", pr, er);
*/
  exit(0);
}
