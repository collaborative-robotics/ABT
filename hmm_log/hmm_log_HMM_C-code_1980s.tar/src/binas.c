/*binas.c 
 *
 * process data from binary logging format files
 *     to a straight ascii file
 *
 *  file functions found in 'binlog.c', structs in 'log.h' 
 *
 * bh 4/88
 */

#include <math.h>
#include <stdio.h>
#include "log.h"

#define JAWPOS	6
#define NCHAN 20

double  cfact[NCHAN] =
 { .0787, 0.0787, 0.0787, 0.315, 0.315, 0.315, 1.0, 1.0, 1.0 };

main(argc, argv)
    int             argc;
    char           *argv[];

{
    HFILE           ifd;
    int             i, j, k, nchan,decimation;
    struct log      dataheader;
    char            data[NCHAN];
    double 	    outdata[NCHAN];
    double 	    delt,t;

decimation = 1;

    if (argc > 3) {
      printf(" \n\n??\n\n");
      exit(0);
      }
    else {
      if (open_file(&ifd, argv[1], 'r') == -1) {
         printf("\ncan't open '%s'\n", argv[1]);
         exit(0);
         }
      if(argc > 2) sscanf(argv[2],"%d",&decimation);
      }

    read_header(&ifd, &dataheader);

    nchan = dataheader.number_vars;
    delt = 1.0 / dataheader.sample_rate;

    t = 0.0;
 while (read_channels(&ifd,9,data) > 0) {
   k++;
   t += delt;

      /* process your data here  *************************************/

   if(decimation > 1)
    {
    for(j=0;j<nchan;j++) 
                {
		outdata[j] += (double) data[j];
                /* correct for unsigned jaw opening */
                if((j==JAWPOS) && (data[j] < 0)) outdata[j] += 256.0; 
                }
    if((k%decimation) == 0) {
      printf("%6.2f ",t);
      for(j=0;j<nchan;j++) {
		outdata[j] /= decimation;
		outdata[j] *= cfact[j];
		printf("%5.1f ", outdata[j]);  
		outdata[j] = 0.0;
 		}
	printf("\n");
      }
    }
   else {
     printf("%6.2f ",t);
     for(j=0;j<nchan;j++) {
	  outdata[j] = (double) data[j] * cfact[j];
          if(j==JAWPOS && outdata[j] < 0.0) outdata[j] += 256.0;
          printf("%5.1f ",outdata[j]);
          }
     printf("\n");
    } 
  }

/*
    printf("Data File: %s \t%d vectors read", dataheader.filename, k);
*/
}
