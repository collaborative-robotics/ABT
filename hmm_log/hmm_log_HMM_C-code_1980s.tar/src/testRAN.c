#include <stdio.h>
#include <math.h>
#include <sys/time.h>
#include "statlib.h"

main()
{
  int i, j;
  int bar[10];
  struct timeval tv;
  struct timezone tz;

  gettimeofday(&tv, &tz);
  srand(tv.tv_sec % 32767);

  for (j = 0; j < 10; j++) {
    seed_rand(rand());
    for (i = 0; i < 10; i++) bar[i] = 0;

    for (i = 0; i < 10000; i++)
      bar[(int) floor(uniform_rand(0,1) * 10)]++;

    for (i = 0; i < 10; i++)
      printf("%4i ", bar[i]);

    printf("\n");
  }
}
