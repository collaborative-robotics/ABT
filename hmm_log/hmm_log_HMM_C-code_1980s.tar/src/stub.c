#include <stdio.h>
#include "HMMtype.h"
#include "memlib.h"
#include "statlib.h"

int main()
{
  HMM my_hmm;
  OSet o1;
  printf("How is an HMM? %i words long!\n", sizeof(my_hmm));
  printf("How big is a observation set? %i!\n", sizeof(o1));
  return(0);
}
