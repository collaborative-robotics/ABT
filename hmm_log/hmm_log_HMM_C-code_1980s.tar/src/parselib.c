/*  parselib.c
**
**  parsing input file library
**
**  V 0.1
**  01/14/94
**
**  Darwei Kung
**
**  This code provides the necessary functions to parse the following
**  array of strings:
**
**  [section name 1]
**  param1=value1
**  param2=value2
**  param3=value3
**
**  [section name 2]
**  param1=value4
**  param2=value5
**
**  into the following structure:
**
**  section.name = "section name 1"
**  section.params -> parameter list
**    paramlist.name="param1"
**    paramlist.value="value1"
**    paramlist.next-> next parameter
**    ...
**    paramlist.name="param3"
**    paramlist.value="value3"
**    paramlist.next->null
**  section.next->next section
**  ...
**
**  and so on.  The only recognized tokes are "[","]","=", and "\n".
**  the results are stored in a dynamic array, and the errors are stored in
**  an array of error messages.
**
**  Any lines with length of zero or doesn't contain a token is ignored.
**  If a structure containing section and parameter names are used, then
**  only the token names which appear within the input structure will be
**  parsed.  All the other lines are considered blank lines.
**
*/

#include <string.h>
#include "parselib.h"          /* provide function prototypes */
#include "memlib.h"            /* safe_malloc() */

/*
**
**  Internal Routines
**
*/

static char PARAM_wildcard[] = "*";

PARAM_section *new_param_section()
{
  PARAM_section *result;

  result = (PARAM_section *)safe_malloc(sizeof(PARAM_section));
  result->name = NULL;
  result->next = NULL;
  result->data = NULL;
  return(result);
}

PARAM_list *new_param_list()
{
  PARAM_list *result;

  result = (PARAM_list *) safe_malloc(sizeof(PARAM_list));
  result->name = NULL;
  result->value = NULL;
  result->next = NULL;
  return(result);
}

extern void *traverse_list(PARAM_list *paramlist,
			   void (*op_list)(char *, char *))
{
  if (paramlist != NULL) {
    op_list(paramlist->name, paramlist->value);
    traverse_list(paramlist->next, op_list);
  }
  return(0);
}

extern void *traverse_section(PARAM_section *paramtree,
			      void (*op_sec)(char *),
			      void (*op_list)(char *, char *))
{
  if (paramtree != NULL) {
    op_sec(paramtree->name);
    traverse_list(paramtree->data, op_list);
    traverse_section(paramtree->next, op_sec, op_list);
  }
  return(0);
}

char *compact_line(char *input_line)
{
  char *temp_line, *output_line;
  int i, j, k;

  i = strlen(input_line);
  temp_line = (char *) safe_calloc(i, sizeof(char));
  for (j = 0, k = 0; j < i; j++) {
    switch (input_line[j]) {
    case ' '  : break;
    case 9    : break;
    case 13   : break;
    case 10   : break;
    default:
      temp_line[k++] = input_line[j]; break;
    }
  }

  temp_line[k] = 0;
  output_line = (char *) strdup(temp_line);
  free(temp_line);
  return (output_line);
}


extern PARAM_section *parse_param(int c, char *text[])
{
  PARAM_section *result, *newsection, *cur_sec;
  int i;
  char *newline, *par1, *par2;
  PARAM_list *cur_list;

  for (i = 0, cur_sec = NULL, cur_list = NULL ; i < c; i++) {
    newline = compact_line(text[i]);
    if (newline[0] == '[') {
      if (newline[strlen(newline)-1] == ']') {
	newsection = new_param_section();
	result = (result == NULL) ? newsection : result;
	if (cur_sec == NULL)
	  cur_sec = newsection;
	else {
	  cur_sec->next = newsection;
	  cur_sec = cur_sec-> next;
	}
	newline[strlen(newline)-1] = 0;
	newsection->name = (char *) strdup(newline+1);
	cur_list = NULL;
      }
    }                           /* skip the line if no closure */
    else {                      /* parse parameter list */
      par1 = strtok(newline, "=");
      par2 = strtok(NULL, "=");
      if ((par1 != NULL) && (par2 != NULL)) {
	if (cur_sec != NULL) {
	  if (cur_list == NULL) {
	    cur_list = new_param_list();
	    cur_sec->data = cur_list;
	  }
	  else {
	    cur_list->next = new_param_list();
	    cur_list = cur_list-> next;
	  }
	  cur_list->name = (char *) strdup(par1);
	  cur_list->value = (char *) strdup(par2);
	}
      }
    }
    free(newline);
  }
  return (result);
}
