/*  memlib.h
**
**  Memory Management Functions
**
**  V 0.1
**  12/01/93
**
**  Darwei Kung
**
**
**  This code includes the memory management functions
**  safe_malloc(size) safe malloc call
**  safe_calloc(num, size) safe calloc call
**
*/

#include <stdlib.h>
extern void *safe_malloc(size_t s);
extern void *safe_calloc(size_t n, size_t s);
extern void **safe_alloc2d(size_t nrows, size_t  ncols, size_t elsize);
extern void ***safe_alloc3d(size_t ndepth, size_t nrows,
			    size_t ncols, size_t elsize);

extern void free2d(void *);
extern void free3d(void *);
