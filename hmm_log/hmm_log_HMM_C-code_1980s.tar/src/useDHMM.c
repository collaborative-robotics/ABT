/*
**  useDHMM.c
**
**  interface routines for using the functions in DHMM library.
**
**  V 0.1
**  09/07/94
**
**  Darwei Kung
**
**  This code is used to interface with the DHMM library calls.  The
**  interface program provides the facility to:
**
**  o train the HMM with a new data set
**  o decode a sequence with the existing HMM file
**
**  The command line format for this program is:
**
**  useDHMM -t<rain> old_hmm training_data <new_hmm>
**  useDHMM -d<ecode> hmm test_data <decode_data>
**
**  if <new_hmm> or <decode_data> is not specificed, then the output will
**  be directed towards stdout port.
**
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>

#ifdef __linux__
#include <fpu_control.h>
#endif

#include "HMMtype.h"
#include "DHMMlib.h"

#define MAX_LEN 3000

char *err_1 = "Not enough parameters";
char *err_2 = "Must specify option -t or -d";
char *err_3 = "Too many parameters";
char *err_4 = "Invalid Option";

int bw_est(char *orig_hmm_file, char *obs_file, char *new_hmm_file)
{
  HMM *hmm, *old_hmm;
  OSet O;
  int i,j,k;
  FILE *in_file;
  char str_temp[255];
  double t1, t2;
  double *w = NULL;
  int t3;
  int t4[MAX_LEN];
  double **alpha = NULL;
  double **beta  = NULL;
  double p_before = 0.0;
  double p_after = 0.0;

  DHMM_read_lambda(&hmm, orig_hmm_file);
  DHMM_read_lambda(&old_hmm, orig_hmm_file);

  if ((in_file = fopen(obs_file, "r")) == NULL)
    abort();

  for(i = 0; fscanf(in_file, "%lf %i %lf", &t1, &t3, &t2) != EOF; i++)
    t4[i] = t3;
  fclose(in_file);

/* create the observation array */

  O.size = 1;
  O.count = i - 1;
  O.o = (double **) safe_calloc(O.count, sizeof(int));

  for(i = 0; i < O.count; i++)
    O.o[i] = (double *) t4[i];
  
  DHMM_scaled_find_alpha(hmm, &alpha, &O, &w);
  DHMM_forward_term(hmm, alpha, &O, &p_before, w);

  DHMM_bw_estimate(hmm, alpha, beta, &O);

  DHMM_scaled_find_alpha(hmm, &alpha, &O, &w);
  DHMM_forward_term(hmm, alpha, &O, &p_after, w);
  free(w);
  free2d(alpha);

  if ((p_after < 0) && (p_before < p_after))
    DHMM_write_lambda(hmm, new_hmm_file);
  else
    DHMM_write_lambda(old_hmm, new_hmm_file);

  fprintf(stderr, "%le %le\n", p_before, p_after);
}

int viterbi(char *hmm_file, char *obs_file, char *result_file)
{
  HMM *hmm;
  OSet O;
  int i, j, status;
  FILE *in_file, *out_file;
  char str_temp[255];
  double t1[MAX_LEN];
  int t2[MAX_LEN];
  int t3[MAX_LEN];
  int *Q;
  double p;
  double **alpha = NULL;

  hmm = NULL;
  DHMM_read_lambda(&hmm, hmm_file);

/* read in the observation file */

  if ((in_file = fopen(obs_file, "r")) == NULL)
    abort();

  if (result_file == NULL)
    out_file = stdout;
  else
    if ((out_file = fopen(result_file, "w")) == NULL)
      abort();

  status = 0;
  for(i = 0; status < 1; i++)
    status = fscanf(in_file, "%lf %i %i", &(t1[i]), &(t3[i]), &(t2[i]))
      != EOF ? 0 : 1;
  fclose(in_file);

/* create the observation array */

  O.size = 1;
  O.count = i - 1;
  O.o = (double **) safe_calloc(O.count, sizeof(int));

  for(i = 0; i < O.count; i++)
    O.o[i] = (double *) t3[i];

/* decode the sequence */

for (i = 0; i < O.count; i++)
fprintf(stderr, "O.o= %i  ", O.o[i]);

  DHMM_viterbi(hmm, &O, &Q);

/* print the results */

  for (j = 0, status = 0; j < O.count; j++) {
    fprintf(out_file, "%6.2f %2i %2i %2i\n", t1[j], O.o[j], t2[j], Q[j]);
  }
}

/*
**  prints the error message
*/

void print_err_msg(char *error_str)
{
  fprintf(stderr, "\nError - %s\n\n", error_str);
  fprintf(stderr, "The command line format for this program is:");
  fprintf(stderr, "\n");
  fprintf(stderr, "useDHMM -t<rain> old_hmm training_data <new_hmm>\n");
  fprintf(stderr, "useDHMM -d<ecode> hmm test_data <decode_data>\n");
  fprintf(stderr, "\n");
  fprintf(stderr, "if <new_hmm> or <decode_data> is not specificed, \n");
  fprintf(stderr, "then the output will be directed towards stdout port.\n");
}

void main(int argc, char **argv)
{

#ifdef __linux__
  __setfpucw(_FPU_IEEE);
#endif

  if (argc < 3) {
    print_err_msg(err_1);
    exit(-1);
  }
  else {
    if (argv[1][0] != '-') {
      print_err_msg(err_2);
      exit(-2);
    }
    else {
      switch (argv[1][1]) {
      case 'd' :
	if (argc == 3)
	  viterbi(argv[2], argv[3], NULL);
	else {
	  if (argc > 4) {
	    print_err_msg(err_3);
	    exit(-3);
	  }
	  else
	    viterbi(argv[2], argv[3], argv[4]);
	}
	break;

      case 't' :
	if (argc == 3)
	  bw_est(argv[2], argv[3], NULL);
	else {
	  if (argc > 4) {
	    print_err_msg(err_3);
	    exit(-3);
	  }
	  else
	    bw_est(argv[2], argv[3], argv[4]);
	}
	break;

      default:
	print_err_msg(err_4);
	exit(-4);
      }
    }
  }
  exit(0);
}
