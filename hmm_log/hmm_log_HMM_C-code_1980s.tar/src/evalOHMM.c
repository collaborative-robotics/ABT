/* this program tests the improvement of P(O | Lambda) from BW Estimation */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "HMMtype.h"
#include "OHMMlib.h"

#define MAX_LEN  2000

int find_p(char *orig_hmm_file, char *hmm_file, char *obs_file,
	   double *p, double *e)
{
  HMM *hmm = NULL;
  HMM *orig_hmm = NULL;
  OSet O;
  int i, j, status;
  FILE *in_file;
  char str_temp[255];
  double t1[MAX_LEN];
  int t2[MAX_LEN];
  double t3[MAX_LEN];
  int *Q;
  double **alpha = NULL;
  double *w = NULL;
  double pr1, pr2; 

  if (OHMM_read_lambda(&hmm, hmm_file) != HMM_OK)
    abort();

  if (OHMM_read_lambda(&orig_hmm, orig_hmm_file) != HMM_OK)
    abort();

/* read in the observation file */

  if ((in_file = fopen(obs_file, "r")) == NULL)
    abort();

  status = 0;
  for(i = 0; status < 1; i++)
    status = fscanf(in_file, "%lf %lf %i", &(t1[i]), &(t3[i]), &(t2[i]))
      != EOF ? 0 : 1;
  fclose(in_file);

/* create the observation array */

  O.size = 1;
  O.count = i - 1;
  O.o = (double **) safe_malloc(sizeof(double *));
  O.o[0] = (double *) safe_calloc(O.count, sizeof(double));

  for(i = 0; i < O.count; i++)
    O.o[0][i] = t3[i];

  Q = (int *) safe_calloc(O.count, sizeof(int));

/* decode the sequence */

  OHMM_scaled_find_alpha(hmm, &alpha, &O, &w);
  OHMM_forward_term(hmm, alpha, &O, &pr2, w);
  free2d(alpha);
  free(w);
  OHMM_scaled_find_alpha(orig_hmm, &alpha, &O, &w);
  OHMM_forward_term(orig_hmm, alpha, &O, &pr1, w);
  OHMM_viterbi(hmm, &O, &Q);

/*  Add for confermation of P velue June 17, 1995 */
fprintf(stderr, "  pr2(%s)= %lf   ", hmm_file, pr2/O.count);
/* for (i=0;i<O.count;i++){
fprintf(stderr, " %i=%i",i,*(Q+i));
} */


/* calculate the convergence rate and the error rates */

  *p = (pr2 - pr1) / ((double) O.count);
  for (j = 0, i = 0; i < O.count; i++) {
    if (Q[i] == t2[i]) j++;
  }
  *e = ((double) j) / ((double) O.count);

  free(w);
  free2d(alpha);
  free(O.o);
  free(Q);
  OHMM_free(hmm);
  OHMM_free(orig_hmm);
}

void main(int argc, char **argv)
{
  double pr, er;

  if (argc != 4) {
    fprintf(stderr, "wrong number of arguments, ");
    fprintf(stderr, "try evalOHMM init_hmm new_hmm obs_file\n");
    exit(1);
  }

  find_p(argv[1], argv[2], argv[3], &pr, &er);
  fprintf(stdout, "%le %8.6f\n", pr, er);
  exit(0);
}
