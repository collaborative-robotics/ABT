/* testing parsing program */
#include <string.h>
#include "parselib.h"

static char *test[] = {
"test1=a",
"test2=b",
"[section1]",
"test3=c",
"test4=d",
"test10",
"test20=",
"=g",
"[section2]",
"[section3]",
"test5=e",
"test6=f"};

void *print_section(char *title)
{
  printf("[%s]\n", title);
  return(0);
}

void *print_list(char *name, char *value)
{
  printf("%s=%s\n", name, value);
  return(0);
}

void main()
{
  PARAM_section *outcome = NULL;

  outcome = parse_param(sizeof(test)/sizeof(char *), test);
  traverse_section(outcome,
		   (void (*) (char *)) print_section,
		   (void (*) (char *, char *)) print_list);
}
