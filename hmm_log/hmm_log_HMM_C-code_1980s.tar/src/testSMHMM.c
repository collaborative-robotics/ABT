/* This program test SMHMM library */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "HMMtype.h"
#include "SMHMMlib.h"
#include "statlib.h"

int find_symbol(SMHMM_p *l, int state)
{
  int i;
  double lower, upper;
  double rv;

  rv = uniform_rand(0, 1);
  lower = 0.0;
  upper = 0.0;
  for(i = 0; i < l->o_count; i++) {
    upper += l->b[state][i];
    if ((lower < rv) && (rv <= upper))
      return(i);
    else {
      lower += l->b[state][i];
    }
  }
  printf("B for state %i is:", state);
  for(i = 0; i < l->o_count; i++)
    printf(" %7.4f", l->b[state][i]);
  printf("\n");
  abort();
}

int find_next_state(SMHMM_p *l, int state)
{
  int i;
  double lower, upper;
  double rv;

  rv = uniform_rand(0,1);
  lower = 0.0;
  upper = 0.0;
  for(i = 0; i < l->s_count; i++) {
    upper += l->a[state][i];
    if ((lower < rv) && (rv <= upper))
      return(i);
    else {
      lower += l->a[state][i];
    }
  }
}


int find_duration(SMHMM_p *l, int state)
{
  double val;

  switch (l->d[state].type) {
  case GAMMA:
    val = gauss_rand(l->d[state].p[0], l->d[state].p[1]);
    break;

  case GAUSS:
    val = gauss_rand(l->d[state].p[0], l->d[state].p[1]);
    break;

  case UNIFORM:
    val = uniform_rand(l->d[state].p[0], l->d[state].p[1]);
    break;

  default:
    val = uniform_rand(1, 10);
  }

  return(ceil(val));
}

int find_init_state(SMHMM_p *l, int *state)
{
  int i;
  double lower, upper;
  double rv;

  rv = uniform_rand(0, 1);
  lower = 0.0;
  upper = 0.0;
  for(i = 0; i < l->o_count; i++) {
    upper += l->pi[i];
    if ((lower < rv) && (rv <= upper)) {
      *state = i;
      return(1);
    }
    else {
      lower += l->pi[i];
    }
  }

  printf("initial states are: ");
  for(i = 0; i < l->s_count; i++)
    printf(" %7.4f", l->pi[i]);
  printf("\n");
  abort();
}

int create_Oset(char *file_name, int seed)
{
  HMM *hmm;
  int cur_state, cur_symbol;
  int i, j, finish, duration;
  double f_rand;

  seed_rand(seed);
  SMHMM_read_lambda(&hmm, file_name);

  find_init_state(&(hmm->par.sm), &cur_state);

  for (i = 0, finish = 0; (i < 500)
       && (cur_state != hmm->par.sm.s_count - 1);) {

/* generate a set of symbols based on duration */

    duration = find_duration(&(hmm->par.sm), cur_state);

    duration = (duration > 0) ? duration : 1;

    for(j = 0; j < duration; j++, i++) {
      cur_symbol = find_symbol(&(hmm->par.sm), cur_state);
      printf("%4i %2i %i\n", i+1, cur_state, cur_symbol);
    }

/* find the next state */

    cur_state = find_next_state(&(hmm->par.sm), cur_state);
  }

/* the last state */

  duration = find_duration(&(hmm->par.sm), cur_state);
  
  for(j = 0; j < duration; j++, i++) {
    cur_symbol = find_symbol(&(hmm->par.sm), cur_state);
    printf("%4i %2i %i\n", i+1, cur_state, cur_symbol);
  }

}

int bw_est(char *orig_hmm_file, char *obs_file, char *new_hmm_file)
{
  HMM *hmm;
  OSet O;
  int i,j,k;
  FILE *in_file;
  char str_temp[255];
  int t1, t2, t3;
  int t4[500];
  double **alpha_1, **alpha_2, **beta_1, **beta_2, **alpha;
  double p_before, p_after;

  SMHMM_read_lambda(&hmm, orig_hmm_file);
  SMHMM_write_lambda(hmm, new_hmm_file);

  if ((in_file = fopen(obs_file, "r")) == NULL)
    abort();

  for(i = 0; fscanf(in_file, "%i %i %i", &t1, &t2, &t3) != EOF; i++)
    t4[i] = t3;

  fclose(in_file);

  O.size = 1;
  O.count = i - 1;
  O.o = (double **) safe_calloc(O.count, sizeof(int));

  for(i = 0; i < O.count; i++)
    O.o[i] = (double *) t4[i];

  for(i = 0, p_before = 1, p_after = 1.2 ; 
    (i < 1) && ((p_after/p_before) > 1.1); i++) {
    SMHMM_find_alpha(hmm, &alpha, &O);
    SMHMM_forward_term(hmm, alpha, &O, &p_before);
    free2d(alpha);

    SMHMM_bw_estimate(hmm, &O);

    SMHMM_find_alpha(hmm, &alpha, &O);
    SMHMM_forward_term(hmm, alpha, &O, &p_after);
    free2d(alpha);

    printf("%le %le\n", p_before, p_after);
    if (p_before < p_after)
      SMHMM_write_lambda(hmm, new_hmm_file);
  }
}


int viterbi(char *hmm_file, char *obs_file)
{
  HMM *hmm;
  OSet O;
  int i, j, status;
  FILE *in_file;
  char str_temp[255];
  int t1[500], t2[500], t3[500];
  int *Q;
  double p;
  double **alpha = NULL;

  hmm = NULL;
  SMHMM_read_lambda(&hmm, hmm_file);

/* read in the observation file */

  if ((in_file = fopen(obs_file, "r")) == NULL)
    abort();

  status = 0;
  for(i = 0; status < 1; i++)
    status = fscanf(in_file, "%i %i %i", &(t1[i]), &(t2[i]), &(t3[i])) != EOF
      ? 0 : 1;
  fclose(in_file);

/* create the observation array */

  O.size = 1;
  O.count = i - 1;
  O.o = (double **) safe_calloc(O.count, sizeof(int));

  for(i = 0; i < O.count; i++)
    O.o[i] = (double *) t3[i];

/* decode the sequence */

  SMHMM_alt_viterbi(hmm, &O, &Q);

/* print the results */

  for (j = 0, status = 0; j < O.count; j++) {
    printf("%i %i %i %i\n", t1[j], t2[j], t3[j], Q[j]);
    status += (t2[j] != Q[j]);
  }

/* print error counts */
  fprintf(stderr, "%2i %2i %6.4f\n", status, i,
	  1.0 - ((double) status) / ((double) i));
}

void main(int argc, char **argv)
/* main() */

{
  int seed;
/*
  int argc = 4;
  char *argv[] =
    {"testSMHMM", "SM_init.dat", "testSM/test203.out","test2.out"};
*/
  switch(argc) {
  case 1:
    printf("  There are three ways to use the testSMHMM:\n");
    printf("  to create observations, try testSMHMM hmm_file,\n");
    printf("  to estimate new HMM, use testSMHMM hmm_file train_data\n");
    printf("  new_hmm_file, and to test the viterbi algorithm,\n");
    printf("  try testSMHMM hmm_file test_data.\n");
    break;

  case 2:
    seed = atoi(argv[1]);
    create_Oset("SM_init.dat",seed);
    break;

  case 3:
    viterbi(argv[1], argv[2]);
    break;

  case 4:
    bw_est(argv[1], argv[2], argv[3]);
    break;

  default:
    printf("That's too many parameters...  Perhaps this will help.\n");
    printf("  There are three ways to use the testSMHMM:\n");
    printf("  to create observations, try testSMHMM hmm_file,\n");
    printf("  to estimate new HMM, use testSMHMM hmm_file train_data\n");
    printf("  new_hmm_file, and to test the viterbi algorithm,\n");
    printf("  try testSMHMM hmm_file test_data.\n");
    break;
  }
  exit(1);
}
