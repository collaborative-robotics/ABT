/*
**  DHMMlib.c
**
**  HMM function library for Discrete HMM (DHMM)
**
**  V 0.2
**  02/01/94
**
**  Darwei Kung
**
**  This code provides all the subroutines for performing HMM calculations.
**  Most of the code is based on the code written by Paul Lee for JPL.
**
**  The types defined in HMMtype.h is used to provide templates for different
**  HMM's.  The functions provided in this file include the viterbi and the
**  Baum_Welch programs.  The data i/o parts of the original HMM c programs
**  are taken out, to make the code easier to read.
**
**  The discrete model assumes the following observation set:
** 
**  OSet O is a set of observations
**  O.o[i] should always be type cased into an integer
**  b is a 2-d array with dimentions T X M
**
*/

#include <math.h>              /* all the math functions */
#include <stdio.h>             /* definition for NULL */
#include <stdlib.h>            /* file open, close, rename */
#include <string.h>            /* strcat, strdup, strcpy */
#include <malloc.h>            /* free() */
#include "HMMtype.h"           /* type templates */
#include "HMMconst.h"          /* constant declartions */
#include "statlib.h"           /* gauss_dis(), gamma_dis() */
#include "memlib.h"            /* safe_malloc(), safe_calloc() */
#define copysign(x, y)  (y > 0.0 ? fabs(x) : -fabs(-x))

/*
**  Forward Calculations for Discrete HMM (DHMM)
**  
**  Forward calculations are broken into three parts:
**
**    Initialization:
**    alpha(1,i) = pi(i) * b(i, o(1))
**
**    Iteration (or Induction):
**    alpha(t+1, j) = sum(i = 1 to N, alpha(t, i) * a(i, j)) * b(j, o(t+1))
**
**    Termination:
**    P(O | Lambda) = sum(i = 1 to N, alpha(T, i))
**
**  These steps are taken directly from the original viterbi.c program file,
**  with modifications for dynamic data types.
**
*/

/* scaled find alpha - scale at each step to prevent underflow */

extern int DHMM_scaled_find_alpha(HMM *lambda, double ***alpha, OSet *O, double **w)
{
  int i, j, t;
  double temp;
  DHMM_p *hmm = NULL;

  if (lambda->type != DHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.d);

/* create the alpha matrix */

/*  printf("Alphas...\n"); */

  if (*alpha == NULL)
    *alpha = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));

  if (*w == NULL)
    *w = (double *) safe_calloc(O->count, sizeof(double));

/* initialize the array elements for time 0 */

  for (i = 0; i < hmm->s_count; i++)
    (*alpha)[0][i] = hmm->pi[i] * hmm->b[i][(int) O->o[0]];
  (*w)[0] = 1.0;

/* forward iteration to compute alpha[t][i] */

  for (t = 0; t < O->count - 1; t++) {
    for (j = 0, temp = 0.0; j < hmm->s_count; j++) {
      for (i = 0; i < hmm->s_count; i++)
	temp += (*alpha)[t][i]*hmm->a[i][j];
      (*alpha)[t+1][j] = temp * hmm->b[j][(int) O->o[t+1]];
    }

/* scale the the alpha's */

    for (i = 0, (*w)[t+1] = 0.0; i < hmm->s_count; i++)
      (*w)[t+1] += (*alpha)[t+1][i];
    
    if ((*w)[t+1] > 0.0) {
      for (i = 0; i < hmm->s_count; i++) {
	(*alpha)[t+1][i] /= (*w)[t+1];
/*	printf("%7.5e ", (*alpha)[t+1][i]); */
      }
/*      printf("%7.5e \n", (*w)[t+1]); */
    }
    else
      (*w)[t+1] = 1.0;
  }
  return(HMM_OK);
}

/* termination, to find P(O|Lamda) */

extern int DHMM_forward_term(HMM *lambda, double **alpha, OSet *O, double *P, double *w)
{
  int i;
  DHMM_p *hmm = NULL;

  if (lambda->type != DHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.d);

/* terminate by summing all of P(O|Lamba, q(T) = i) */

  for (i = 0, *P = 0.0; i < O->count; i++) {
    (*P) += log(w[i]);
  }

  return(HMM_OK);
}

/*
**  Backward Calculations for Discrete HMM (DHMM)
**  
**  Backward calculations are broken into three parts:
**
**    Initialization:
**    beta(T, i) = 1
**
**    Iteration (or Induction):
**    beta(t, i) = sum(i = j to N, a(i, j) * b(j, o(t+1)) * beta(t+1, j))
**
*/

extern int DHMM_find_beta(HMM *lambda, double ***beta, OSet *O)
{
  int i, j, t;
  DHMM_p *hmm = NULL;

  if (lambda->type != DHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.d);

/* create Beta array */

  if (*beta == NULL)
    *beta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));

/* initialize the array elements */

  for (i = 0; i < hmm->s_count; i++)
    (*beta)[O->count - 1][i] = 1.0;

/* iterate through the steps */

  for (t = O->count - 2; t >= 0; t--) {
    for (i = 0; i < hmm->s_count; i++) {
      (*beta)[t][i] = 0.0;
      for (j = 0; j < hmm->s_count; j++)
	(*beta)[t][i] += hmm->a[i][j] * hmm->b[j][(int) O->o[t+1]] *
	  (*beta)[t+1][j];
    }
  }
  return(HMM_OK);
}

/* scaled find beta - the betas are normalized at each step */

extern int DHMM_scaled_find_beta(HMM *lambda, double ***beta, OSet *O)
{
  int i, j, t;
  DHMM_p *hmm = NULL;
  double temp;

/*  printf("betas\n");*/
  if (lambda->type != DHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.d);

/* create Beta array */

  if (*beta == NULL)
    *beta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));

/* initialize the array elements */

  for (i = 0; i < hmm->s_count; i++)
    (*beta)[O->count - 1][i] = 1.0;

/* iterate through the steps */

  for (t = O->count - 2; t >= 0; t--) {
    for (i = 0; i < hmm->s_count; i++) {
      (*beta)[t][i] = 0;
      for (j = 0; j < hmm->s_count; j++)
	(*beta)[t][i] += hmm->a[i][j] * hmm->b[j][(int)O->o[t+1]] *
	  (*beta)[t+1][j];
    }

/* scale the betas */

    for (i = 0, temp = 0.0; i < hmm->s_count; i++)
      temp += (*beta)[t][i];

    if (temp > 0.0) {
      for (i = 0; i < hmm->s_count; i++) {
	(*beta)[t][i] /= temp;
/*	printf("%7.5e ", (*beta)[t][i]);*/
      }
/*      printf("\n");*/
    }
  }
  return(HMM_OK);
}

/*
**  Viterbi Calculations for Discrete HMM (DHMM)
**  
**  Viterbi calculations are broken into four parts:
**
**    Initialization:
**    delta(1, i) = pi(i) b(i, O(1)), phi(1,i) = NULL
**
**    Iteration (or Induction):
**    delta(t, j) = max(delta(t-1)*a(i,j))*b(j,o(t))
**    phi(t, j) = arg max(delta(t-1)*a(i,j))
**
**    Termination:
**    P = max(delta(T, i))
**    q(T) = argmax(delta(T,i))
**
**    Path Backtracking
**    q(t) = phi(t+1, q(t+1))
**
**  These steps are taken directly from the original viterbi.c program file,
**  with modifications for dynamic data types.
**
*/

extern int DHMM_viterbi(HMM *lambda, OSet *O, int **Q)
{
  int i, j, t;
  double **delta = NULL;
  double temp;
  int **phi = NULL;
  DHMM_p *hmm = NULL;
  double **a;
  double **b;
  double *pi;

  if (lambda->type != DHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.d);

/* create the sequence matrix Q */

  if (*Q == NULL)
    *Q = (int *) safe_calloc(O->count, sizeof(int));

/* initialization  */

  a = (double **) safe_alloc2d(hmm->s_count, hmm->s_count, sizeof(double));
  b = (double **) safe_alloc2d(hmm->s_count, hmm->o_count, sizeof(double));
  pi = (double *) safe_calloc(hmm->s_count, sizeof(double));
  delta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));
  phi = (int **) safe_alloc2d(O->count, hmm->s_count, sizeof(int));

/* create log numbers */

  for(i = 0; i < hmm->s_count; i++)
    for(j = 0; j < hmm->s_count; j++)
      a[i][j] = hmm->a[i][j] > 0 ?
	log(hmm->a[i][j]) : -MAX_NUMBER;

  for(i = 0; i < hmm->s_count; i++)
    for(j = 0; j < hmm->o_count; j++)
      b[i][j] = hmm->b[i][j] > 0 ?
	log(hmm->b[i][j]) : -MAX_NUMBER;

  for(i = 0; i < hmm->s_count; i++)
      pi[i] = hmm->pi[i] > 0 ?
	log(hmm->pi[i]) : -MAX_NUMBER;

/* inititializing phi */

  for(i = 0; i < hmm->s_count; i++) {
    delta[0][i] = pi[i];
    phi[0][i] = i;
  }

/* Recursion / Iteration */

  for(t = 1; t < O->count; t++) {
    for(j = 0; j < hmm->s_count; j++) {
      delta[t][j] = -MAX_NUMBER;
      phi[t][j] = -1;
      for(i = 0; i < hmm->s_count; i++) {
	if (a[i][j] > -MAX_NUMBER) {
	  temp = delta[t-1][i] + a[i][j];
	  if (temp > delta[t][j]) {
	    delta[t][j] = temp;
	    phi[t][j] = i;
	  }
	}
      }
      delta[t][j] += b[j][(int)O->o[t]];

#ifdef DEBUG
      if ((phi[t][j] > -1) && (delta[t][j] > -MAX_NUMBER))
	fprintf(stdout, "|%2i|%8.2f", phi[t][j], delta[t][j]);
      else
	fprintf(stdout, "|  |        ");
#endif
    }

#ifdef DEBUG
    fprintf(stdout, "|\n");
#endif

  }

/* Termination */
  
  for(i = 0, temp = -MAX_NUMBER,(*Q)[O->count-1] = -1 ; i < hmm->s_count; i++){
    if (delta[O->count-1][i] > temp) {
      temp = delta[O->count-1][i];
      (*Q)[O->count-1] = i;
    }
  }

/* Backtracking */

  for(t = O->count - 2; t >= 0; t--)
    (*Q)[t] = phi[t+1][(*Q)[t+1]];

/* free up the dynamic arrays */

  free2d(a);
  free2d(b);
  free(pi);
  free2d(phi);
  free2d(delta);

  return(HMM_OK);
}

/*
**  Baum Welch Calculations for Discrete HMM (DHMM)
**  
**  Baum Welch calculations are recursive in nature.  The parameters
**  are estimated with the following auxillary functions:
**
**  xi(t, i, j) =
**     alpha(t, i) * a(i,j) * b(j, t+1) * beta(t+1, j)
**    -------------------------------------------------
**                 sum all possible above
**
**  gamma(t, i) =
**    sum(xi(t, i, j), all j)
**
**  Each iteration steps are:
**
**  pi(i) = gamma(1, i)
**
**  a(i,j) = sum(xi(t,i,j), t=1..T-1) / sum(gamma(t,i), t=1..T-1)
**
**  b(j,k) = sum(gamma(t,j), t=1..T, o(t) = v(k)) /
**           sum(gamma(t,j), t=1..T-1)
**
**  This will be applied to the entire data set, then the tuned lambda is
**  used as the benchmark for evaluating the other sets.
**
*/

/*
**  Compute the set of auxilliary functions.  Assuming that alpha and beta
**  are precomputed already.  xi is a 3-d array of the form
**    xi(t, i, j) = P(q(t) = i, q(t+1) = j | O, lambda)
**    gamma(t, i) = sum(xi(t,i,j), j=1..N) 
**
*/

int DHMM_bw_xi_gamma(HMM *lambda, double **alpha,
			    double **beta, OSet *O,
			    double ****XI, double ***GAMMA)
{
  int i, j, t;
  DHMM_p *hmm = NULL;
  double temp;

  if (lambda->type != DHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.d);

/* allocate an array for XI[t][i][j], GAMMA[t][i] */

  if (*XI == NULL)
    *XI = (double ***)
      safe_alloc3d(O->count-1, hmm->s_count, hmm->s_count, sizeof(double));

  if (*GAMMA == NULL)
    *GAMMA = (double **)
      safe_alloc2d(O->count - 1, hmm->s_count, sizeof(double));

/* find all possible alpha*a*b*beta */

  for(t = 0; t < O->count-1; t++) {

/* find the products of forward & backward procedures */
    
    temp = 0.0;

    for(i = 0; i < hmm->s_count; i++) {
      for(j = 0; j < hmm->s_count; j++) {
	(*XI)[t][i][j] = 
	  alpha[t][i]*hmm->a[i][j]*hmm->b[j][(int)O->o[t+1]]*beta[t+1][j];
	temp += (*XI)[t][i][j];
      }
    }

/* adjust the size to evaluate XI */

    if (temp > 0.0) {
      for(i = 0; i < hmm->s_count; i++) {
	for(j = 0; j < hmm->s_count; j++) {
	  (*XI)[t][i][j] /= temp;
	}
      }
    }

/* Evaluate GAMMA */

    for(i = 0; i < hmm->s_count; i++) {
      (*GAMMA)[t][i] = 0.0;
      for (j = 0; j < hmm->s_count; j++) (*GAMMA)[t][i] += (*XI)[t][i][j];
    }
  }
  return(HMM_OK);
}

/*
**  Compute the tuned lambda based on the input set.  Each time the parameter
**  changes, the alpha and beta will need to be recalculated.
**
**  lambda, alpha, beta will be the final values.
**
*/

extern int DHMM_bw_estimate(HMM *lambda, double **alpha,
			    double **beta, OSet *O)
{
  int t, i, j, k;
  DHMM_p *hmm = NULL;
  double ***bw_xi = NULL;
  double **bw_gamma = NULL;
  double *w = NULL;
  double temp1, temp2, temp3, temp4;
  double residual, res_multiplier, subtotal;

  if (lambda->type != DHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.d);

  bw_xi = NULL;
  bw_gamma = NULL;

/* find alpha and beta */

  if (DHMM_scaled_find_alpha(lambda, &alpha, O, &w) != HMM_OK) {
    fprintf(stderr, "forward computation error in DHMM_bw_estimate.\n");
    abort();
  }

  if (DHMM_scaled_find_beta(lambda, &beta, O) != HMM_OK) {
    fprintf(stderr, "Backward computation error in DHMM_bw_estimate.\n");
    abort();
  }

/* find parameters xi and gamma */

  if (DHMM_bw_xi_gamma(lambda,alpha,beta,O,&bw_xi,&bw_gamma) != HMM_OK) {
    fprintf(stderr, "xi & gamma computation error in DHMM_bw_estimate.\n");
    abort();
  }

/* reestimate pi, pi(i) = gamma[0][i] */

  for(i = 0; i < hmm->s_count; i++) hmm->pi[i] = bw_gamma[0][i];

/* reestimate a, a[i][j] = sum(xi) / sum(gamma) */

  temp3 = 0.0;
  for(i = 0; i < hmm->s_count; i++) {
    for(t = 0, temp2 = 0.0; t < O->count-1; t++) temp2 += bw_gamma[t][i];
    temp3 += temp2;

/* only reestimate the state if Pr(state i) is significant */
/* rate limit the estimate change rate to prevent sudden swings in values */

    if (temp2 > MIN_BW_STATE) {
      for(j = 0; j < hmm->s_count; j++) {
	for(t = 0, temp1 = 0.0; t < O->count-1; t++) temp1 += bw_xi[t][i][j];
	temp4 = (temp1/temp2)/hmm->a[i][j] - 1.0;
	hmm->a[i][j] = (fabs(temp4) < MAX_BW_STEP) ? temp1/temp2 :
	  hmm->a[i][j] * (1 + copysign(MAX_BW_STEP, temp4));
      }

/* now, normalize the a[i][j] stuff */

      for (j = 0, temp4 = 0.0; j < hmm->s_count; j++) temp4 += hmm->a[i][j];
      for (j = 0; j < hmm->s_count; j++) hmm->a[i][j] /= temp4;
    }
  }
    
/* restimating b */

  for(j = 0; j < hmm->s_count; j++) {
    for(t = 0, temp2 = 0.0; t < O->count-1; t++) temp2 += bw_gamma[t][j];
    if (temp2 > MIN_BW_STATE) {
      for(k = 0; k < hmm->o_count; k++) {
	for(t = 0, temp1 = 0.0; t < O->count-1; t++)
	  temp1 = (((int) O->o[t]) == k) ? temp1 + bw_gamma[t][j] : temp1;
	temp4 = (temp1/temp2) / hmm->b[j][k] - 1.0;
	hmm->b[j][k] = (fabs(temp4) < MAX_BW_STEP) ?
	  temp1/temp2 : hmm->b[j][k] * (1 + copysign(MAX_BW_STEP, temp4));
      }

/* Normalize the b[j][k] */

      for (k=0, temp4 =0.0; k < hmm->o_count; k++) temp4 += hmm->b[j][k];
      for (k=0; k < hmm->o_count; k++) hmm->b[j][k] /= temp4;
    }
  }

/* clean up the memory allocation */

  free2d(bw_gamma);
  free3d(bw_xi);
  free(w);

  return(HMM_OK);
}

/*
**  DHMM_read_lambda
**
**
*/

extern int DHMM_read_lambda(HMM **lambda, char *filename)
{
  int i, j, k, l;
  DHMM_p *hmm = NULL;
  FILE *in_file;
  char in_string[256], c;
  double temp_double;

  if (*lambda == NULL)
    *lambda = (HMM *) safe_malloc(sizeof(HMM));
  (*lambda)->type = DHMM;
  hmm = &((*lambda)->par.d);

/* open data file */

  if ((in_file = fopen(filename, "r")) == NULL) {
    fprintf(stderr, "HMM_read_D can't read %s\n", filename);
    abort();
  }

/* read data from input file */
      
  k = 0;

  while (fscanf(in_file, "%s", in_string) > 0) {

/* take out all the comments beginning with # */
    
    if (in_string[0] == '#') {
      while ((c = fgetc(in_file)) != EOF && c != '\n');
      continue;
    }
    else {
      switch (k++) {
      case  0:                  /* number of states */
	fscanf(in_file,"%d",&(hmm->s_count));
	hmm->pi = (double *) safe_calloc(hmm->s_count, sizeof(double));
	hmm->a = (double **)
	  safe_alloc2d(hmm->s_count, hmm->s_count, sizeof(double));
	hmm->b = (double **) safe_calloc(hmm->s_count, sizeof(double *));
	hmm->s_name = (char **) safe_calloc(hmm->s_count, sizeof(char *));
	break;

      case  1:                  /* name of states */
	for(i = 0; i < hmm->s_count; i++) {
	  fscanf(in_file,"%s", (char *) &in_string);
	  hmm->s_name[i] = (char *) strdup(in_string);
	}
	break;

      case 2:                   /* initial distribution */
	for(i = 0; i < hmm->s_count; i++)
	  fscanf(in_file,"%le", &(hmm->pi[i]));
	break;

      case 3:                   /* read in the a matrix */
	for(i = 0; i < hmm->s_count; i++) {
	  for(j = 0; j < hmm->s_count; j++)
       	    fscanf(in_file, "%le", &(hmm->a[i][j]));
	  if (i < hmm->s_count - 1)
	    fscanf(in_file,"%s",in_string);
	}
	break;

      case 4:                   /* read in the symbol set size */
	fscanf(in_file, "%i", &(hmm->o_count));
	break;

      case 5:                   /* read in the b distribution */
	for (i = 0; i < hmm->s_count; i++) {
	  hmm->b[i] = (double *) safe_calloc(hmm->o_count, sizeof(double));
	  for (j = 0; j < hmm->o_count; j++)
	    fscanf(in_file, "%le", &(hmm->b[i][j]));
	  if (i < hmm->s_count - 1)
	    fscanf(in_file,"%s",in_string);
	}
	break;
	
      default:                  /* ignore everything after the B vec. */
	break;
      }
    }
  }

  fclose(in_file);
  return(HMM_OK);
}

/*
**
**  write DHMM into a file.
**
*/

extern int DHMM_write_lambda(HMM *lambda, char *filename)
{
  int i, j;
  DHMM_p *hmm = NULL;
  FILE *out_file;
  char out_string[256];
  double temp_double;
  char comments[] = "#\n#\n#\n";
  char new_line[] = "\n";

  if (lambda == NULL)
    return(HMM_ERROR);

  if (lambda->type != DHMM)
    return(HMM_MISMATCH);

  hmm = &(lambda->par.d);

  if (filename == NULL)
    out_file = stdout;
  else {
    if ((out_file = fopen(filename, "w")) == NULL) {
      fprintf(stderr, "HMM_write_D can't write to  %s.\n", filename);
      abort();
    }
  }

/* write data to the file in the same order as read */
      
  fprintf(out_file, comments);  /* number of states */
  fprintf(out_file, "no_states:  ");
  fprintf(out_file,"%d\n",hmm->s_count);

  fprintf(out_file, comments);   /* state names */
  fprintf(out_file, "state_no:  ");
  for(i = 0; i < hmm->s_count; i++)
    fprintf(out_file,"%s  ", hmm->s_name[i]);
  fprintf(out_file, new_line);
  fprintf(out_file, comments);  /* initial distribution */
  fprintf(out_file, "init_dis:  ");
  for(i = 0; i < hmm->s_count; i++) {
    temp_double = hmm->pi[i] < MIN_NUMBER ? 0.0 : hmm->pi[i];
    fprintf(out_file,"%6.4f  ", temp_double);
  }
  fprintf(out_file, new_line);

  fprintf(out_file, comments);  /* A matrix */
  for(i = 0; i < hmm->s_count; i++) {
    fprintf(out_file,"a[%i,j]:  ", i+1);
    for(j = 0; j < hmm->s_count; j++) {
      temp_double = hmm->a[i][j] < MIN_NUMBER ? 0.0 : hmm->a[i][j];      
      fprintf(out_file, "%12.10e  ", temp_double);
    }
    fprintf(out_file, new_line);
  }

  fprintf(out_file, comments); /* observation symbol size */
  fprintf(out_file, "obs_symbol_size:  ");
  fprintf(out_file, "%i", hmm->o_count);
  fprintf(out_file, new_line);

  fprintf(out_file, comments); /* b vectors */
  for (i = 0; i < hmm->s_count; i++) {
    fprintf(out_file, "b[%i,j]:  ", i+1);
    for (j = 0; j < hmm->o_count; j++) {
      temp_double = hmm->b[i][j] < MIN_NUMBER ? 0.0 : hmm->b[i][j];
      fprintf(out_file, "%12.10e  ", temp_double);
    }
    fprintf(out_file, new_line);
  }

  fprintf(out_file, comments);

  close(out_file);
  return(HMM_OK);
}

/* Free Up the space taken by the HMM */

extern int DHMM_free(HMM *lambda)
{
  int i, j;
  DHMM_p *hmm = NULL;

/* if it's already freed, skip the rest of the routines */

  if (lambda == NULL)
    return(HMM_OK);

  hmm = &(lambda->par.d);

  for (i = hmm->s_count - 1; i >= 0; i--) free(hmm->b[i]);
  for (i = hmm->s_count - 1; i >= 0; i--) free(hmm->s_name[i]);

  free(hmm->s_name);
  free(hmm->b);
  free2d(hmm->a);
  free(hmm->pi);
  free(hmm);
  free(lambda);

  return(HMM_OK);
}
