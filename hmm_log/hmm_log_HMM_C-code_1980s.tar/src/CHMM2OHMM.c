/*
**  CHMM2OHMM.c
**
**  utility program which converts a SLR CHMM into a SLR OHMM
**
**  V 1.0
**  11/04/94 DK
**
**  Darwei Kung
**
**  This code provides a translation between the CHMM format into
**  an OHMM format.  The derivation of the transition probability is
**  based on equal distribution means.
**
**
**  Usage:
**
**  CHMM2OHMM -i input file  <-o out file>
**
**    -i in file 
**    -o out file (default is stdout)
**   
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#ifdef __linux__
#include <fpu_control.h>
#endif

#include "HMMtype.h"
#include "CHMMlib.h"
#include "OHMMlib.h"

/* static variables for i/o files */

static FILE *infile;
static FILE *outfile;
static char *infile_name = NULL;
static char *outfile_name = NULL;

int print_error_msg(char *error_msg)
{
  if (error_msg != NULL)
    fprintf(stderr, "%s\n", error_msg);
  fprintf(stderr, "Please use the following format:\n");
  fprintf(stderr, "CHMM2OHMM -i in_file -o out_file");
  exit(1);
}

/* Print help for command line options */

int print_help_msg()
{
  fprintf(stderr, "Options\n");
  fprintf(stderr, "-i  input file name.  if none is given, stdin is used\n");
  fprintf(stderr, "-o  output file name.  if none is given, stdout is used\n");
}

/* Solution is based on equal mean */

double calc_a(double mu, double sigma)
{
  return((mu - 1.0) / mu);
}

int convert_HMM()
{
  int i, j;
  double a;

  HMM *hmm, newhmm;
  CHMM_p *chmm;
  OHMM_p *ohmm;

  CHMM_read_lambda(&hmm, infile_name);
  newhmm.type = OHMM;
  ohmm = &(newhmm.par.o);
  chmm = &(hmm->par.c);
  ohmm->s_count = chmm->s_count;
  ohmm->s_name  = chmm->s_name;
  ohmm->pi = chmm->pi;
  ohmm->b  = chmm->b;
  ohmm->a  = (double **) safe_alloc2d(ohmm->s_count, ohmm->s_count,
				      sizeof(double));
  for(i = 0; i < ohmm->s_count; i++)
    for(j = 0; j < ohmm->s_count; j++) {
      if (i == j) {
	a = calc_a(chmm->d[i].p[0], chmm->d[i].p[1]);
	ohmm->a[i][j] = a;
      }
      else if (j == (i+1))
	ohmm->a[i][j] = 1 - a;
      else
	ohmm->a[i][j] = 0.0;
    }

  ohmm->a[i-1][j-1] = 1.0;

  OHMM_write_lambda(&newhmm, outfile_name);
}

void main(int argc, char **argv)
{
  int i;
  double b;

#ifdef __linux__
  __setfpucw(_FPU_IEEE);
#endif

  outfile = stdout;
  for (i = 1; i < argc; i++) {
    if (argv[i][0] != '-')
      print_error_msg("Please check your command line format!");

    switch (argv[i][1]) {
    case 'i' :
      if (infile != NULL)
	print_error_msg("duplicate input file names.");
      if (++i == argc) print_error_msg("No input file specified");
      if ((infile = fopen(argv[i], "r")) == NULL)
	print_error_msg("Can't open input file.");
      infile_name = (char *) strdup(argv[i]);
      break;

    case 'o' :
      if (outfile != stdout)
	print_error_msg("duplicate output file names.");
      if (++i == argc) print_error_msg("No output file specified");
      if ((outfile = fopen(argv[i], "w")) == NULL)
	print_error_msg("Can't open output file.");
      outfile_name = (char *) strdup(argv[i]);
      break;

    default:
      print_error_msg("option not valid");
      break;
    }
  }
  if (infile == NULL)
    print_error_msg("Need to specify the input file name!");

  fclose(infile);
  if (outfile != stdout)
    fclose(outfile);
  convert_HMM();

  exit(0);
}
