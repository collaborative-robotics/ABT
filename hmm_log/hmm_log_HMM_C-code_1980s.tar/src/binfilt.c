/*binfilt.c
 *
 *    unscramble zoltan's parallel file format and
 *    scramble into the binlog format !!!!!
 *
 *		BH 3/88
 *
 *    Correct synch errors due to spurious clock transitions
 *		BH 5/88
 */
#include "log.h"
#include <stdio.h>

#define FLAG	0xAA
#define PCT	20
#define MAXPRINT 300

char           fname[100];
union {
	short		data[1000];
	char		cdat[2000];
	} d ;
char		ivect[PCT],lastvect[PCT];
short		flag;
double		dvect[PCT],delt;
int		endpt,ofst,cnt,cnt2,code,fdes,i,xj,xj1;
int		valcnt,error_count;

HFILE		ofdes;
struct log	hd;

double		dt,t,tj,tj1,delt,beta;

main(argc,argv)
int argc;
char *argv[];
{
int first,j,jj;

delt = 0.0002;
flag = FLAG;
valcnt = 10;	/* number of data values + 1 for flag  */
first = 1;

fdes = open(argv[1], O_RDONLY, 0644);
strcpy(fname,argv[1]);
for(j=0;fname[j]!='\0';j++);
fname[j++] = '.';
fname[j++] = 'x';
fname[j++] = '\0';

printf("opening %s for binary output\n",fname);

open_file(&ofdes,fname,'w');

/* printf("binary output file opened\n");

 set up local copy of output file header */

strcpy(hd.experimentor,"bh");
strcpy(hd.filename,fname);
strcpy(hd.progname,"binfilt");

hd.sample_rate = 100;
hd.number_vars = 9;
hd.block_size = 0; /* take default */
hd.type = CHAR;

/* printf("fixed header fields setup\n"); */

setchan(&hd,0,"x force",0,0);
setchan(&hd,1,"y force",0,0);
setchan(&hd,2,"z force",0,0);
setchan(&hd,3,"roll torque",0,0);
setchan(&hd,4,"yaw torque",0,0);
setchan(&hd,5,"pitch torque",0,0);
setchan(&hd,6,"jaw position",0,0);
setchan(&hd,7,"clamping force 1",0,0);
setchan(&hd,8,"clamping force 2",0,0);

/* printf("channel descriptors setup\n"); */

gen_header(&ofdes,&hd);

/* printf("nvars: %d  \n",hd.number_vars); */
/* printf("nvars: %d  \n",hd.number_vars); */
/* printf("header written: state_bytes: %d\n",ofdes.state_bytes); */

/*
if (argc > 2) sscanf(argv[2],"%d",&valcnt);
if (argc > 3) { sscanf(argv[3],"%x",&i);
		flag = (short) i; }		*/

error_count = 0;
delt = 1.0 / hd.sample_rate;

/* printf("searching for flag: %x (%d)\n",flag,i); */

while(read(fdes,d.data,2000) != 0)
  {
   if(first == 1) {  /* find flag and get ofset value  */
           first = 0;
	   for(j=0;j<20;j++) {
	      if((0xFF & (d.data[j]>>8)) == flag) {ofst = j; break;}
		/* if didn't find flag */
	      if(j == valcnt -1) {
		      printf("sync failure:\n"); 
		      for(j=0;j<valcnt;j++)
			 ivect[j] =(char) 0377 & (d.data[j]>>8); 
		      for(j=0;j<valcnt;j++) printf("%2x ",ivect[j]);
		      printf("\n");
		      exit(valcnt - 1);}
		      }
    	       }

   else {  /* subsequent buffers  */
	   for(ofst=0;j<valcnt;)
	     ivect[j++] = (char) (0377 & (d.data[ofst++]>>8));
           for(j=0;j<valcnt;j++) 
  		{ivect[j] = ~ivect[j];
		 lastvect[j] = ivect[j];
		}
           write_channels(&ofdes,valcnt-1,ivect+1);
        }

/*
 * process all complete state vectors in the buffer 
 */

   for(jj=ofst;jj<1000-valcnt;jj += valcnt)
      {
      for(j=0;j<valcnt;j++) 
             ivect[j] = (char) ~(0377 & (d.data[jj+j]>>8)); 
      if((0xFF & (d.data[jj+valcnt]>>8)) != flag) {
		if(error_count < MAXPRINT)
		      printf("binfilt: downstream sync failure: %5.2f (%d)\n",
				t,jj+j);
		jj = resynch(jj+valcnt);
		error_count++;
		write_channels(&ofdes,valcnt-1,lastvect+1);
		}
      else {
           write_channels(&ofdes,valcnt-1,ivect+1);
           for(j=0;j<valcnt;j++) 
  		 lastvect[j] = ivect[j];
	   }
      t += delt;
      }
   endpt = jj;
/*
 *  catch last bytes in the buffer
 */
   j = 0;
   for(jj=endpt;jj<1000;jj++)
     {
     ivect[j++] = (char)(0377 & (d.data[jj]>>8));
     }
     
  }
close(ofdes.fdes);
printf("\nfinished %s, %d errors detected/corrected\n",fname,error_count);
}

resynch(ofst)
int ofst;
{
int j;
for(j=ofst-3;j<(ofst+valcnt+3);j++) {
 if((0xFF & (d.data[j]>>8)) == flag) {return(j-valcnt); break;}
 }
}

