/*  statlib.c
**
**  Statistics Function Calculations
**
**  V 0.1
**  12/01/93
**
**  Darwei Kung
**
**
**  This code includes the parametric statistic functions
**
*/

#include <math.h>               /* pow, exp, gamma, sqrt */
#include <values.h>             /* find the definition of M_PI */
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#define Pi M_PI
#define Pi_2_Sqrt 2.50662827463100
#define Log_2     M_LN2
#define Log_Pi    1.14472988584940
#define Log_2Pi   1.83787706640935

/* add support for systems without gamma functions */

#ifdef __linux__
#define NEED_GAMMA
#endif

#ifdef NEED_GAMMA
#define gamma(x) my_gamma(x)
double my_gamma(double);
double my_lgamma(double);
#endif

static int statlib_seed = -1234;
double ran3(int *);

int seed_rand(int seed)
{
  statlib_seed = -seed;
  ran3(&statlib_seed);
}

/*
**
**  sqr: square function
**  sqr(x) = x * x
**
*/

double sqr(double x)
{
  return(x * x);
}

/*
**
** gauss_dis: gaussian distributon function
**
** gauss_dis(x, mu, sigma) mu = mean, sigma = standard deviation
**
*/

double gauss_dis(double x, double mu, double sigma)
{
  double a, b;

  a = exp(-sqr(x - mu) / (2.0 * sqr(sigma)));
  b = sigma * Pi_2_Sqrt;
  return(a / b);
}

/*
**
** log_gauss_dis: log normal distribution function
**
** gauss_dis(x, mu, sigma) mu = mean, sigma = standard deviation
**
*/

double log_gauss_dis(double x, double mu, double sigma)
{
  double a, b;

  a = Log_2Pi + 2.0 * log(sigma);
  b = sqr(x - mu) / sqr(sigma);
  return(-0.5 * (a + b));
}

/*
**
**  gamma: gamma distribution function
**
**  gamma(x, alpha, beta)
**
*/

double gamma_dis(double x, double alpha, double beta)
{
  double a, b, c;

  if (x < 0)
    return(0);
  else {
    c = gamma(alpha);
    a = pow(x, alpha - 1) * exp(-x/beta);
    b = pow(beta, alpha) * c;
    return(a / b);
  }
}

/*
**
**  Uniform Distribution
**
**  uniform_dis(x, a, b) = 1/(b-a) * u(x - a) * u(b - x)
**
*/

double uniform_dis(double x, double a, double b)
{
  double result;

  result = ((x >= a) && (x <= b)) ? 1 / (b-a) : 0;

  return(result);
}
/*
**
**  Poisson Distribution
**
**  poisson_dis(x, a) = exp(-a) * a^x / x!
**
*/

double poisson_dis(double x, double a)
{
  double result;

  result = exp(-a) * pow(a, x) / gamma(x);

  return(result);
}

/*
**
** random number generators, copied from numerical recipes book
**
*/

/* uniform random variables */

double uniform_rand(double upper, double lower)
{
  double rv;

  rv = ran3(&statlib_seed);

/* scale to within upper and lower bound */

  return (rv * (upper - lower) + lower);
}

/* gaussian random variables */

double gauss_rand(double mu, double sigma)
{
  double fac,r,v1,v2, rv;
  static int use_old;
  static double old_val;

  if (use_old != 1234) {
    do {
      v1 = uniform_rand(-1, 1);
      v2 = uniform_rand(-1, 1);
      r = v1*v1+v2*v2;
    } while (r >= 1.0);
    fac = sqrt(-2.0 * log(r) / r);
    old_val = v2 * fac;
    rv =mu + v1 * fac * sigma;
  }
  else {
    rv = mu + old_val * sigma;
  }
  return(rv);
}

/* poisson random number generator */

double poisson_rand(double lambda)
{
  static double sq,alxm,g,oldm=(-1.0);
  double em,t,y;

  if (lambda < 12.0) {
    if (lambda != oldm) {
      oldm=lambda;
      g=exp(-lambda);
    }
    em = -1;
    t=1.0;
    do {
      em += 1.0;
      t *= uniform_rand(0,1);
    } while (t > g);
  } else {
    if (lambda != oldm) {
      oldm=lambda;
      sq=sqrt(2.0*lambda);
      alxm=log(lambda);
      g=lambda*alxm-log(gamma(lambda+1.0));
    }
    do {
      do {
	y=tan(Pi * uniform_rand(0,1));
	em=sq*y+lambda;
      } while (em < 0.0);
      em=floor(em);
      t=0.9*(1.0+y*y)*exp(em*alxm-log(gamma(em+1.0))-g);
    } while (uniform_rand(0, 1) > t);
  }
  return em;
}

/* copied from c-recipes book */

#define MBIG 1000000000
#define MSEED 161803398
#define MZ 0
#define FAC (1.0/MBIG)

double ran3(int *idum)
{
  static int inext,inextp;
  static long ma[56];
  static int iff=0;
  long mj,mk;
  int i,ii,k;

  if (*idum < 0 || iff == 0) {
    iff=1;
    mj=MSEED-(*idum < 0 ? -*idum : *idum);
    mj %= MBIG;
    ma[55]=mj;
    mk=1;
    for (i=1;i<=54;i++) {
      ii=(21*i) % 55;
      ma[ii]=mk;
      mk=mj-mk;
      if (mk < MZ) mk += MBIG;
      mj=ma[ii];
    }
    for (k=1;k<=4;k++)
      for (i=1;i<=55;i++) {
	ma[i] -= ma[1+(i+30) % 55];
	if (ma[i] < MZ) ma[i] += MBIG;
      }
    inext=0;
    inextp=31;
    *idum=1;
  }
  if (++inext == 56) inext=1;
  if (++inextp == 56) inextp=1;
  mj=ma[inext]-ma[inextp];
  if (mj < MZ) mj += MBIG;
  ma[inext]=mj;
  return mj*FAC;
}

#undef MBIG
#undef MSEED
#undef MZ
#undef FAC

#ifdef NEED_GAMMA

/* a local gamma function */

double my_lgamma(double xx)
{
  double x,tmp,ser;
  static double cof[6]={76.18009173,-86.50532033,24.01409822,
			  -1.231739516,0.120858003e-2,-0.536382e-5};
  int j;

  x=xx-1.0;
  tmp=x+5.5;
  tmp -= (x+0.5)*log(tmp);
  ser=1.0;
  for (j=0;j<=5;j++) {
    x += 1.0;
    ser += cof[j]/x;
  }
  return -tmp+log(2.50662827465*ser);
}

double my_gamma(double x)
{
  return(exp(lgamma(x)));
}

#endif
