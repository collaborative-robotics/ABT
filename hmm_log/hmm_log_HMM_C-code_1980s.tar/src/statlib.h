/*  statlib.h
**
**  Statistics Function Calculations
**
**  V 0.1
**  12/01/93
**
**  Darwei Kung
**
**
**  This code includes the headers to the parametric statistic functions
**
**  sqr(x) = x * x
**  gauss_dis(x, a, b) = exp(-(x-a)^2/(2*b^2))/(sqrt(2*Pi)*b)
**  gamma_dis(x, a, b) = x^(a-1)*exp(-x/b)/(b^a*gamma(a))
**  normal_dis(x, a, b) = 1/(b-a) * u(x-a) * u(b-x)
**  poisson_dis(x, a) = exp(-a) * pow(a, x) / gamma(x);
**
*/

extern double sqr(double x);
extern double gauss_dis(double x, double a, double b);
extern double log_gauss_dis(double x, double a, double b);
extern double gamma_dis(double x, double a, double b);
extern double uniform_dis(double x, double a, double b);
extern double poisson_dis(double x, double a);

extern int seed_rand(int seed);
extern double uniform_rand(double upper, double lower);
extern double gauss_rand(double mu, double sigma);
extern double poisson_rand(double lambda);
