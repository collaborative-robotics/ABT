/*
**  HMMlib.h
**
**  HMM function library Header
**
**  V 0.2
**  02/01/94
**
**  Darwei Kung
**
**  This code provides all the subroutines for performing HMM calculations.
**  Most of the code is based on the code written by Paul Lee for JPL.
**
**  The types defined in HMMtype.h is used to provide templates for different
**  HMM's.  The functions provided in this file include the viterbi and the
**  Baum_Welch programs.  The data i/o parts of the original HMM c programs
**  are taken out, to make the code easier to read.
**
*/

/* forward algorithm */

extern int SMHMM_forward_term(HMM *lambda, double **alpha, OSet *O, double *P);
extern int SMHMM_find_alpha(HMM *lambda, double ***alpha, OSet *O);

/* backward algorithm */

extern int SMHMM_find_beta(HMM *lambda, double ***alpha, OSet *O);

/* viterbi algorithm */
/* the alternate form uses sum of log rather than straight multiply */

extern int SMHMM_viterbi(HMM *lambda, OSet *O, int **Q);
extern int SMHMM_alt_viterbi(HMM *lambda, OSet *O, int **Q);

/* baum-welch algorithm */

extern int SMHMM_find_alpha_beta(HMM *lambda, double ***alpha_1,
				 double ***alpha_2, double ***beta_1,
				 double ***beta_2, OSet *O);

extern int SMHMM_bw_estimate(HMM *lambda, OSet *O);

/* File IO routines */

extern int SMHMM_read_lambda(HMM **lambda, char *filename);
extern int SMHMM_write_lambda(HMM *lambda, char *filename);

/* Clean Up Routine */

extern int SMHMM_free(HMM *lambda);


