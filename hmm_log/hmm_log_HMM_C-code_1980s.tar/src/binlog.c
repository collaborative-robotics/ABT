/*binlog.c (formerly format.c)  */
/** 
miscellaneous data record formatting routines including:
	open_file      - performs low level 'open'  (BH) 
	gen_header     - generates a header 
	read_header    - reads a header
	print_header   - prints header structure to stdout 
	read_channels  - reads data from file to array 
	write_channels - writes data from array to file 
	write_state    - write a state vector to buffered i/o 
	read_state     - read  "   "     " 
	print_data     - prints a state vector array to stdout 
        set_chan       - set header information for a channel
  
Marcos Salganicoff 8-13-86 
Addntl mods 10-10-86 MS 
"       "   12-15-86   MS 
  
BH  2/87: Added HFILE structure(to log.h) containing all
file dependent information. This allows multiple files to
be open with different characteristics
  
*/
#include <stdio.h>
#include "log.h"

/* customize the buffer increment values for individual machines */
#ifdef IRIS
static short    buf_inc[6] =
{
 1, 2, 4, 4, 4, 4};

#else
#ifdef VAX
static short    buf_inc[6] =
{
 1, 2, 4, 4, 4, 8};

#else DEFAULT
static short    buf_inc[6] =
{
 1, 2, 4, 4, 4, 4};

#endif VAX
#endif IRIS
/* open_file(fd,fname,c) 
  
   open a file for binary data format i/o 
  
   fd is a file information pointer, type HFILE (log.h) fname is a
        filename string c  is either 'r' or 'w' 
  
*/

open_file(fd, fname, c)
HFILE          *fd;
char           *fname;
char            c;
{
    if (c != 'r' && c != 'w') {
        return (-2); }
    fd->rw = c;
    if (c == 'w') {
        fd->fdes = open(fname, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        }
    else  fd->fdes = open(fname, O_RDONLY, 0644);
    return (fd->fdes);
}

/* hdr_defaults(header)

 sets up some default values for the header if 
 not interested in detailed information  (bh 3/87)

 */
hdr_defaults(header)
struct log *header;
{
header->number_vars = 1;
header->block_size = 0;	/* simple buffering  */
strcpy(header->experimentor,"jpl default");
strcpy(header->progname,"generic.c");
strcpy(header->filename,"unknown");
}

/* gen_header(fd,header) 
  
this routine takes a header structure  and writes it out to
the beginning of the data log file. It uses system write
calls to write bytes out to the file. Gen_header assumes
the output file has been previously opened and terminates
if this is not the case. gen_header also allocates storage
for the incoming sample values in blocksize amounts derived
from the header
  
fd - header information structure: type HFILE header -
header structure which will provide information to generate
header information on disk.

*/

gen_header(fd, header)
HFILE          *fd;
struct log     *header;
{
    int             i;
    int             t;

    /* catch case where called before header is properly set up  */
    if (header->number_vars == 0)
        return (-1);

    /* set up default values if none  */

    for (i = 0; i < header->number_vars; i++) {
       if (header->channel_array[i] == NULL)
           header->channel_array[i] =
           (struct channel_info *) malloc(sizeof(struct channel_info));
       if(header->channel_array[i]->name == '\0')
              sprintf(header->channel_array[i]->name, "Channel %d", i);
       }

    if (header->type == 0)
        header->type = FLOAT;

    if (header->block_size == 0) {
        fd->block_bytes = 0;
        fd->array = fd->beg_array = NULL;
        }
    fd->total_bytes = 0;        /* zero buffering pointer  */

    /* bhms is id tag so that the system can tell if the file is
       correct format */
    /* format and ignore it if it isn't the case */
    sprintf(header->idline, "bhms");    /* identification line
                                           for log */

    /* write the header out to the file as a byte image */
    /* printf("sizeof %d struct log\n", sizeof(struct log)); */
    /* printf("sizeof %d struct chan in\n", sizeof(struct channel_info)); */
    t = write(fd->fdes, (char *) header, (unsigned) sizeof(struct log));

    /* write the individual channel format out as necessary for
       each channel */
    for (i = 0; i < header->number_vars; i++) {
 
        t += write(fd->fdes, (char *) (header->channel_array[i]),
                   (unsigned) sizeof(struct channel_info));
    }

    /* next line must be changed to a loop for variable types
       within one file  */
    fd->state_bytes = header->number_vars * buf_inc[header->type];
    /* bytes per state_vec */

    /*  printf("state_bytes %d block_bytes %d \n", 
           fd->state_bytes, fd->block_bytes); 	      */
    if (fd->block_bytes != 0) { /* if block buffering  */
        /* allocate the array for the incoming samples */
        fd->array = (char *) malloc(fd->block_bytes);
        fd->beg_array = fd->array;
    }
    fd->header = *header;
    if (t > 0)
        return (t);
    else
        return (-1);            /* return error or # of bytes
                                   written */
}

/* setchan(&header,chno,name,i1,i2)
 *      initialize header information for a given channel
 *
 */
setchan(header,chno,name,i1,i2)
struct log *header;
char *name;
int chno,i1,i2;
{
if (chno >= header->number_vars) return( -1);
if (header->channel_array[chno] == NULL)
    header->channel_array[chno] =
    (struct channel_info *) malloc(sizeof(struct channel_info));

strcpy(header->channel_array[chno]->name,name);

header->channel_array[chno]->spare1 = i1;
header->channel_array[chno]->spare2 = i2;
return(1);
}





/* read_header(fd,header) this is essentially the inverse of
   gen_header. Assumes file has been previously opened by an
   "open" call 
  
fd - data file information of type HFILE 
  
*/
read_header(fd, header)
HFILE          *fd;
struct log     *header;
{
    int             i;
    int             t;

    /* read the header */
    t = read(fd->fdes, header, sizeof(struct log));
    /* read the channel description information */
    for (i = 0; i < header->number_vars; i++) {
        header->channel_array[i] = 
            (struct channel_info *) malloc(sizeof(struct channel_info));
        t += read(fd->fdes, header->channel_array[i], 
                   sizeof(struct channel_info));
        }
                      /* bytes per state_vec */
    fd->state_bytes = header->number_vars * buf_inc[header->type]; 
                      /* bytes per block */     
    fd->block_bytes = fd->state_bytes * header->block_size;     
    fd->header = *header;
    if (t > 0)
        return (t);
    else
        return (-1);
}

/* print_header(header) 
  
this handy routine takes a ptr  to a header structure and prints
   it to the standard outoutput
  
header - a pointer to the filled header structure 
  
*/
print_header(header)
struct log     *header;
{
    int             i;

    /* this is pretty obvious I hope */
    printf("%s", header->date_time);
    printf("%s\n", header->filename);
    printf("%s\n", header->experimentor);
    printf("%s\n", header->subject);
    printf("%s\n", header->progname);
    printf("%s\n", header->progversion);
    printf("%s\n", header->comments);
    printf("%d\n", header->sample_rate);
    printf("%d\n", header->number_vars);
    printf("%d\n", header->block_size);
    printf("%d\n", header->numberofsamples);
    printf("%d\n", header->type);
    printf("%d\n", header->checksum);

    /* use previously read number_vars value to go through each
       channel */
    for (i = 0; i < header->number_vars; i++)
        printf("%s\n %d %d \n", header->channel_array[i]->name,
               header->channel_array[i]->spare1, 
               header->channel_array[i]->spare2);
}

/* write_channels(fd,nbytes,buf) 
  
this routine writes out a the data array in byte form
independent of what data format (floating, integer etc. )
is used. It uses the system "write" to do its work. You had
better have issued an a gen_header call before this or
things will screw up badly
  
fd - data file information structure (HFILE) nbytes - the
number of bytes to write ( use a sizeof(array) to to derive
this value before calling write_channels buf - ptr to the
beginning of the array, must be cast to *char
  
*/
write_channels(fd, nbytes, buf)
HFILE          *fd;
int             nbytes;
char           *buf;
{
    return (write(fd->fdes, buf, nbytes));
}


/* write out a state vector record */

write_state(fd, buf)
HFILE          *fd;
char           *buf;
{
    int  i, t;

    if (fd->block_bytes > 0) {  /* if block buffering  */
        for (i = 0; i < fd->state_bytes; i++) {
            *(fd->array++) = *(buf++);
            fd->total_bytes += 1;       /* total bytes buffered
                                           so far */

                 /* is the buffer full? */
            if (fd->total_bytes >= fd->block_bytes) {   
                 /*  printf("wrote buffer %d\n", t = write(fd->fdes,
                              fd->beg_array, fd->block_bytes));  */

                fd->total_bytes = 0;    /* reset the buffer
                                           count */
            }
        }
    }
    else {   /* non-buffered i/o   (default)  */
        t = write(fd->fdes, buf, fd->state_bytes);
    }
    return (t);
}

/* flush the buffer */
flush_buf(fd)
HFILE          *fd;
{
    if (fd->block_bytes > 0) {
        /* printf("flushed buffer byte count= %d\n", write(fd->fdes,
                              fd->beg_array, fd->total_bytes)); */
        /* printf("totalbytes = %d\n", fd->total_bytes); */

        fd->total_bytes = 0;
    }
}

/* read_channels(fd,nbytes,buf) reads in an array from the
input file which has been previously opened. You must have
done a read_header before this call or strange and
unpleasant results will ensue
  
fd - data file descriptor nbytes - the number of bytes to
read buf - the destination array
  
*/
read_channels(fd, nbytes, buf)
HFILE          *fd;
int             nbytes;
char           *buf;
{
    return (read(fd->fdes, buf, nbytes));
}


/* read in a state vector record */

read_state(fd, buf)
HFILE          *fd;
char           *buf;
{
    int             t;
    int             i;

      /* if block buffering  */
    if (fd->block_bytes > 0) {  
        for (i = 0; i < fd->state_bytes; i++) {
            *(buf++) = *(fd->array++);
            fd->total_bytes -= 1;       /* total bytes buffered
                                           so far */
                /* is the buffer empty? */
            if (fd->total_bytes == 0) { 
                /* printf("read buffer %d\n", t = read(fd->fdes,
                              fd->beg_array, fd->block_bytes)); */
                 /* reset the buffer count */
                fd->total_bytes = fd->block_bytes;      
                }
        }
    }
    else {   /* non-buffered i/o   (default)  */
        t = read(fd->fdes, buf, fd->state_bytes);
    }
    return (t);
}


/* print out a block of state vectors */
print_data(buf, header)
struct log     *header;
char           *buf;
{
    int             i, j;

    for (i = 0; i < header->numberofsamples; i++) {
        for (j = 0; j < header->number_vars; j++) {
            switch (header->type) {
            case (CHAR):
                printf("%c\t", *(char *) buf);
                buf += buf_inc[CHAR];
                break;
            case (SHORT):
                printf("%d\t", *(short *) buf);
                buf += buf_inc[SHORT];
                break;
            case (INT):
                printf("%d\t", *(int *) buf);
                buf += buf_inc[INT];
                break;
            case (LONG):
                printf("%d\t", *(long *) buf);
                buf += buf_inc[LONG];
                break;
            case (FLOAT):
                printf("%7.3f\t", *(float *) buf);
                buf += buf_inc[FLOAT];
                break;
            case (DOUBLE):
                printf("%7.3g\t", *(float *) buf);
                buf += buf_inc[DOUBLE];
                break;
            }                   /* end switch */
        }                       /* end for j */
        printf("\n");           /* give me a new line */
    }                           /* end for i */
}                               /* end print_data */
