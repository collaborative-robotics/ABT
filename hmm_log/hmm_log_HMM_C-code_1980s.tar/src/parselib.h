/*  parselib.h
**
**  parsing input file library header
**
**  V 0.1
**  01/14/94
**
**  Darwei Kung
**
**  Provides the data structure and calling format for the parsing routines
*/

/*  structures  */

typedef struct param_list {
  char *name;
  char *value;
  struct param_list *next;
} PARAM_list;

typedef struct param_section {
  char *name;
  struct param_list *data;
  struct param_section *next;
} PARAM_section;

typedef SEC_FUNC (void (*)(char *, char *));  /* operator for section */
typedef LIST_FUNC (void (*)(char *));         /* operator for param list */

/*  functions  */

/*  parses an array of text into sections and lists  */
extern PARAM_section *parse_param(int c, char *text[]);

/*  create a new parameter section  */
extern PARAM_section *new_param_section();

/*  create a new parameter list  */
extern PARAM_list *new_param_list();

/*  the traversal functions are used to apply a function onto each member
**  of the parameter list.  The operator formats are:
**
**    void *op(char *title) -> section
**    void *op(char *param, char *value) -> list
**
**  the return value is a pointer, and can be type casted into any
**  desired format.
*/

/*  travere sections  */
extern void *traverse_section(PARAM_section *paramtree,
			      void (*op_sec)(char *),
			      void (*op_list)(char *, char *));

/*  traverse lists  */
extern void *traverse_list(PARAM_list *paramlist,
			   void (*op_list)(char *, char *));

