/* this program tests the improvement of P(O | Lambda) from BW Estimation */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "HMMtype.h"
#include "CHMMlib.h"

#define MAX_LEN  2000

int find_p(char *orig_hmm_file, char *hmm_file, char *obs_file,
	   double *p, double *e)
{
  HMM *hmm = NULL;
  HMM *orig_hmm = NULL;
  OSet O;
  int i, j, status;
  FILE *in_file;
  char str_temp[255];
  double t1[MAX_LEN],t3[MAX_LEN];
  int t2[MAX_LEN];
  int *Q;
  double **alpha = NULL;
  double *w = NULL;
  double pr1, pr2;

  if (CHMM_read_lambda(&hmm, hmm_file) != HMM_OK)
    abort();

  if (CHMM_read_lambda(&orig_hmm, orig_hmm_file) != HMM_OK)
    abort();

/* read in the observation file */

  if ((in_file = fopen(obs_file, "r")) == NULL)
    abort();

  status = 0;
  for(i = 0; status < 1; i++)
    status = fscanf(in_file, "%lf %lf %i", &(t1[i]), &(t3[i]), &(t2[i]))
      != EOF ? 0 : 1;
  fclose(in_file);

/* create the observation array */

  O.size = 1;
  O.count = i - 1;
  O.o = (double **) safe_malloc(sizeof(double *));
  O.o[0] = (double *) safe_calloc(O.count, sizeof(double));

  for(i = 0; i < O.count; i++)
    O.o[0][i] = t3[i];

  Q = (int *) safe_calloc(O.count, sizeof(int));

/* decode the sequence */

  CHMM_find_alpha(hmm, &alpha, &w, &O);
  CHMM_forward_term(hmm, alpha, w, &O, &pr2);
  free2d(alpha);

  CHMM_find_alpha(orig_hmm, &alpha, &w, &O);
  CHMM_forward_term(orig_hmm, alpha, w, &O, &pr1);
  free2d(alpha);
  CHMM_alt_viterbi(hmm, &O, &Q);

/*  Add for confermation of P velue June 17, 1995 */
fprintf(stderr, "   P velue = %lf   ", pr2/O.count);
/* for (i=0;i<O.count;i++){
fprintf(stderr, " %i=%i",i,*(Q+i));
} */


/* calculate the convergence rate and the error rates */

  *p = (pr2 - pr1) / O.count;
  for (j = 0, i = 0; i < O.count; i++) j += (Q[i] == t2[i]);
  *e = ((double) j) / ((double) O.count);

  free(O.o);
  free(Q);
  CHMM_free(hmm);
  CHMM_free(orig_hmm);
}


void main(int argc, char **argv)
{
  double pr, er;

  if (argc != 4) {
    fprintf(stderr, "wrong number of arguments, ");
    fprintf(stderr, "try evalCHMM init_hmm new_hmm obs_file\n");
    exit(1);
  }

  find_p(argv[1], argv[2], argv[3], &pr, &er);
  fprintf(stdout, "%le %8.6f\n", pr, er);
  exit(0);
}
