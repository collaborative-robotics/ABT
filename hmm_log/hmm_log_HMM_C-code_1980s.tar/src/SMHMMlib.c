/*
**  SMHMMlib.c
**
**  HMM function library for Semi-Markov HMM (SMHMM)
**
**  V 0.2
**  02/01/94
**
**  Darwei Kung
**
**  This code provides all the subroutines for performing HMM calculations.
**  Most of the code is based on the code written by Paul Lee for JPL.
**
**  The types defined in HMMtype.h is used to provide templates for different
**  HMM's.  The functions provided in this file include the viterbi and the
**  Baum_Welch programs.  The data i/o parts of the original HMM c programs
**  are taken out, to make the code easier to read.
**
**  The discrete model assumes the following observation set:
**  
**  OSet O is a set of observations
**  O.o[i] should always be type cased into an integer
**  b is a 2-d array with dimentions T X M
**
**  The duration is explicitly declaired.
**
*/

#include <math.h>              /* all the math functions */
#include <stdio.h>             /* definition for NULL */
#include <stdlib.h>            /* file open, close, rename */
#include <string.h>            /* strcat, strdup, strcpy */
#include <malloc.h>            /* free() */
#include "HMMtype.h"           /* type templates */
#include "HMMconst.h"          /* constant value declarations */
#include "statlib.h"           /* gauss_dis(), gamma_dis() */
#include "memlib.h"            /* safe_malloc(), safe_calloc() */

/* unique structure to SMHMM */

typedef struct {
  int state;
  int duration;
} phi_struct;

/*
**  Forward Calculations for Discrete Semi-Markov HMM (SMHMM)
**  
**  Forward calculations are broken into three parts:
**
**    Initialization:
**
**    alpha(1, i) = pi(i) * p(i, 1) * b(i, O(1))
**    alpha(2, i) = pi(i) * p(i, 2) * Prod(s = 1..2, b(i, O(s))) +
**                  Sum(j = 1.. N, j <> i, alpha(1, j) * a(j, i) *p(i, 1) *
**                  b(i, O(2)))
**    alpha(3, i) = pi(i) * p(i, 3) * Prod(s = 1..3, b(i, O(s))) + Sum(
**                  d = 1..2, Sum(j = 1.. N, j <> i, alpha(3-d, j) *
**                  a(j, i) * p(i, j) * Prod(s = 4-d..3,b(i, O(s)))))
**    ...
**
**    alpha(D, i) = pi(i) * p(i, D) * Prod(s = 1..D, b(i, O(s))) + Sum(
**                  d = 1..D-1, Sum(j = 1.. N, j <> i, alpha(D-d, j) *
**                  a(j, i) * p(i, j) * Prod(s = D+1-d..D,b(i, O(s)))))
**
**    Iteration (or Induction):
**    
**    alpha(t, j) = Sum(j = 1..N, Sum(d = 1 .. D), alpha(t-d, i) * a(i, j)
**                  * p(j, d) * Prod(s = t-d+1..t, b(i, O(s))))
**
**    Termination:
**    
**    P(O|lambda) = Sum(i = 1..N, alpha(T, i))
**
**
*/

extern int SMHMM_find_alpha(HMM *lambda, double ***alpha, OSet *O)
{
  int i, j, s, d, t;
  double temp_1, temp_2, temp_3;
  double b_prod;
  int max_D;
  int *d_high;
  int d_high_bound;
  SMHMM_p *hmm;

  if (lambda->type != SMHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.sm);

/* create the alpha matrix */

  *alpha = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));

/* create the high and low boundary arrays */

  d_high = (int *) safe_calloc(hmm->s_count, sizeof(int));

/*
** define the maximum number for D as max(mean(i) + 3 * sigma(i))
** the max is hard coded based on gaussian dist.  in the future,
** a set of functions that provide this value will be stored in a
** table and initialized at run time.
*/

  for(i = 0, max_D = 0; i < hmm->s_count; i++) {
    d_high[i] = hmm->d[i].p[0] + 5 * hmm->d[i].p[1];
    max_D = max_D > d_high[i] ? max_D : d_high[i];
  }

/* initialization */

  for(i = 0; i < hmm->s_count; i++) {
    if (hmm->pi[i] > 0)
      (*alpha)[0][i] =
	hmm->pi[i] * gauss_dis(1, hmm->d[i].p[0], hmm->d[i].p[1]) *
	  hmm->b[i][(int) O->o[0]];
    else
      (*alpha)[0][i] = 0.0;
  }

  for (t = 1; t < O->count; t++) {

/*    printf("%3i ", t); */

    for (i = 0; i < hmm->s_count; i++) {
      temp_1 = 0.0;
      d_high_bound = d_high[i];

/* consider initial stage if close to start */
/* include contribution from initial start  */

      if (t < max_D) {
	if (hmm->pi[i] > 0.0) {
	  temp_1 = hmm->pi[i] * gauss_dis(t+1, hmm->d[i].p[0], hmm->d[i].p[1]);
	  for(s = 0; s <= t; s++) temp_1 *= hmm->b[i][(int) O->o[s]];
	}
      }

      d_high_bound = t > d_high[i] ? d_high[i] : t;

      temp_2 = 0.0;
      b_prod = 1.0;
      for(d = 1; d <= d_high_bound; d++) {
	b_prod *= hmm->b[i][(int)O->o[t+1-d]];
	temp_3 = 0.0;
	for(j = 0; j < hmm->s_count; j++) {
	  if ((*alpha)[t - d][j] > 0.0) {
	    temp_3 += (*alpha)[t - d][j] * hmm->a[j][i];
	  }
	}
	if (temp_3 > 0.0) {
	  temp_2 += temp_3 *
	    gauss_dis(d, hmm->d[i].p[0], hmm->d[i].p[1]) * b_prod;
	}
      }
      (*alpha)[t][i] = temp_1 + temp_2;

/*      printf("%7.3e ", (*alpha)[t][i]); */

    }

/*    printf("\n"); */

  }

  free(d_high);
  return(HMM_OK);
}


/* termination, to find P(O|Lamda) */

extern int SMHMM_forward_term(HMM *lambda, double **alpha, OSet *O, double *P)
{
  int i;
  SMHMM_p *hmm;

  if (lambda->type != SMHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.sm);

  if (alpha == NULL)
    return(HMM_ERROR);

/* terminate by summing all of P(O|Lamba, q(T) = i) */

  for (i = 0, *P = 0.0; i < hmm->s_count; i++)
    (*P) += alpha[O->count-1][i];
  return(HMM_OK);
}

/*
**  SMHMM_read_lambda
**
**
*/

extern int SMHMM_read_lambda(HMM **lambda, char *filename)
{
  int i, j, k, l;
  SMHMM_p *hmm;
  FILE *in_file;
  char in_string[256], c;
  double temp_double;
  int d_type, p_count;

  *lambda = (HMM *) safe_malloc(sizeof(HMM));
  (*lambda)->type = SMHMM;

  hmm = &((*lambda)->par.sm);

/* open data file */

  if ((in_file = fopen(filename, "r")) == NULL) {
    fprintf(stderr, "SMHMM_read_lambda can't read %s\n", filename);
    abort();
  }

/* read data from input file */
      
  k = 0;

  while (fscanf(in_file, "%s", in_string) > 0) {

/* take out all the comments beginning with # */
    
    if (in_string[0] == '#') {
      while ((c = fgetc(in_file)) != EOF && c != '\n');
      continue;
    }
    else {
      switch (k++) {
      case  0:                  /* number of states */
	fscanf(in_file,"%d",&(hmm->s_count));
	hmm->pi = (double *) safe_calloc(hmm->s_count, sizeof(double));
	hmm->a = (double **) safe_alloc2d(hmm->s_count, hmm->s_count,
					  sizeof(double));
	hmm->b = (double **) safe_calloc(hmm->s_count, sizeof(double *));
	hmm->s_name = (char **) safe_calloc(hmm->s_count, sizeof(char *));
	break;

      case  1:                  /* name of states */
	for(i = 0; i < hmm->s_count; i++) {
	  fscanf(in_file,"%s", (char *) &in_string);
	  hmm->s_name[i] = (char *) strdup(in_string);
	}
	break;

      case 2:                   /* initial distribution */
	for(i = 0; i < hmm->s_count; i++)
	  fscanf(in_file,"%le", &(hmm->pi[i]));
	break;

      case 3:                   /* read in the a matrix */
	for(i = 0; i < hmm->s_count; i++) {
	  for(j = 0; j < hmm->s_count; j++)
       	    fscanf(in_file, "%le", &(hmm->a[i][j]));
	  if (i < hmm->s_count - 1)
	    fscanf(in_file,"%s",in_string);
	}
	break;

      case 4:                   /* read in the symbol set size */
	fscanf(in_file, "%i", &(hmm->o_count));
	break;

      case 5:                   /* read in the b distribution */
	for (i = 0; i < hmm->s_count; i++) {
	  hmm->b[i] = (double *) safe_calloc(hmm->o_count, sizeof(double));
	  for (j = 0; j < hmm->o_count; j++)
	    fscanf(in_file, "%le", &(hmm->b[i][j]));
	  if (i < hmm->s_count - 1)
	    fscanf(in_file,"%s",in_string);
	}
	break;

      case 6:                   /* read in the duration type */
	fscanf(in_file, "%s", in_string);
	for (i = 0, d_type = UNDEFINED, p_count = 5; i < 4; i++) {
	  if (strcasecmp(in_string, dist_name[i]) == 0) {
	    d_type = dist_number[i];
	    p_count = dist_p_count[i];
	  }
	}
	break;

      case 7:                   /* read in the parameters for d */
	hmm->d = (struct DIST_param *)
	  safe_calloc(hmm->s_count, sizeof(struct DIST_param));
	for (i = 0; i < hmm->s_count; i++) {
	  hmm->d[i].type = d_type;
	  hmm->d[i].p_count = p_count;
	  hmm->d[i].p = (double *) safe_calloc(p_count, sizeof(double));
	  for (j = 0; j < p_count; j++) {
	    fscanf(in_file, "%le", &(hmm->d[i].p[j]));
	  }
	  if (i < hmm->s_count - 1)
	    fscanf(in_file,"%s",in_string);
	}
	break;

      default:                  /* ignore everything after the B vec. */
	break;
      }
    }
  }

  fclose(in_file);
  return(HMM_OK);
}

/*
**
**  write SMHMM into a file.
**
*/

extern int SMHMM_write_lambda(HMM *lambda, char *filename)
{
  int i, j;
  SMHMM_p *hmm;
  FILE *out_file;
  char out_string[256];
  double temp_double;
  char comments[] = "#\n#\n#\n";
  char new_line[] = "\n";

  if (lambda == NULL)
    return(HMM_ERROR);

  if (lambda->type != SMHMM)
    return(HMM_MISMATCH);

  hmm = &(lambda->par.sm);

  if ((out_file = fopen(filename, "w")) == NULL) {
    fprintf(stderr, "SMHMM_write_lambda can't write to  %s.\n", filename);
    abort();
  }

/* write data to the file in the same order as read */
      
  fprintf(out_file, comments);  /* number of states */
  fprintf(out_file, "no_states:  ");
  fprintf(out_file,"%i\n",hmm->s_count);

  fprintf(out_file, comments);   /* state names */
  fprintf(out_file, "state_no:  ");
  for(i = 0; i < hmm->s_count; i++)
    fprintf(out_file,"%s  ", hmm->s_name[i]);
  fprintf(out_file, new_line);
  fprintf(out_file, comments);  /* initial distribution */
  fprintf(out_file, "init_dis:  ");
  for(i = 0; i < hmm->s_count; i++) {
    temp_double = hmm->pi[i] < MIN_NUMBER ? 0.0 : hmm->pi[i];
    fprintf(out_file,"%4.2f ", temp_double);
  }
  fprintf(out_file, new_line);

  fprintf(out_file, comments);  /* A matrix */
  for(i = 0; i < hmm->s_count; i++) {
    fprintf(out_file,"a[%i,j]:  ", i+1);
    for(j = 0; j < hmm->s_count; j++) {
      temp_double = hmm->a[i][j] < MIN_NUMBER ? 0.0 : hmm->a[i][j];      
      fprintf(out_file, "%4.2f ", temp_double);
    }
    fprintf(out_file, new_line);
  }

  fprintf(out_file, comments); /* observation symbol size */
  fprintf(out_file, "obs_symbol_size:  ");
  fprintf(out_file, "%i", hmm->o_count);
  fprintf(out_file, new_line);

  fprintf(out_file, comments); /* b vectors */
  for (i = 0; i < hmm->s_count; i++) {
    fprintf(out_file, "b[%i,j]:  ", i+1);
    for (j = 0; j < hmm->o_count; j++) {
      temp_double = hmm->b[i][j] < MIN_NUMBER ? 0.0 : hmm->b[i][j];
      fprintf(out_file, "%12.10e  ", temp_double);
    }
    fprintf(out_file, new_line);
  }

  fprintf(out_file, comments); /* duration type */
  fprintf(out_file, "duration_type: ");
  fprintf(out_file, "%s", dist_name[hmm->d[0].type]);
  fprintf(out_file, new_line);

  fprintf(out_file, comments); /* duration parameters */
  for (i = 0; i < hmm->s_count; i++) {
    fprintf(out_file, "d[%i,j]:  ", i+1);
    for (j = 0; j < hmm->d[i].p_count; j++) {
      fprintf(out_file, "%10.6f ", hmm->d[i].p[j]);
    }
    fprintf(out_file, new_line);
  }

  fprintf(out_file, comments);

  close(out_file);
  return(HMM_OK);
}

/* clean up them HMM */

extern int SMHMM_free(HMM *lambda)
{
  int i, j;
  SMHMM_p *hmm;

/* if it's already freed, skip the rest of the routines */

  if (lambda == NULL)
    return(HMM_OK);

  hmm = &(lambda->par.sm);

  for (i = hmm->s_count - 1; i >= 0; i--) free(hmm->b[i]);
  for (i = hmm->s_count - 1; i >= 0; i--) free(hmm->s_name[i]);
  for (i = hmm->s_count - 1; i >= 0; i--) {
    free(hmm->d[i].p);
  }

  free(hmm->d);
  free(hmm->s_name);
  free(hmm->b);
  free2d(hmm->a);
  free(hmm->pi);
  free(hmm);
  free(lambda);

  return(HMM_OK);
}

/*
**  Viterbi Calculations for Discrete HMM (DHMM)
**  
**  Viterbi calculations are broken into four parts:
**
**    Initialization:
**    delta(1, i) = pi(i) b(i, O(1)), phi(1,i) = NULL
**
**    Iteration (or Induction):
**    delta(t, j, d) = max_i(alpha(t-d, i) * a(i,j))
**    phi(t, j) = [argmax_d(epsilon, argmax_i(delta)]
**
**    Termination:
**    P = max(delta(T, i, D))
**    q(T) = argmax_i(delta(T, i, D))
**    d(T) = argmax_d(delta(T, i, D))
**
**    Path Backtracking
**    q(t) = phi(t+D, q(t+D))[1]
**    d(T) = phi(t+D, q(t+D))[2]
**
**  These steps were derived from Rabiner and Juang's book
*/

extern int SMHMM_viterbi(HMM *lambda, OSet *O, int **Q)
{
  int i, j, t, d, s;
  int prev_state;
  double **delta;
  double temp_1, temp_2, temp_3, temp_4;
  double b_prod;
  int *d_high;
  int d_high_bound, max_D;
  SMHMM_p *hmm;
  phi_struct **phi;


  if (lambda->type != SMHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.sm);

/* create the sequence matrix Q */

  if (*Q == NULL)
    *Q = (int *) safe_calloc(O->count, sizeof(int));

/* initialization  */

  delta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));
  phi = (phi_struct **)
    safe_alloc2d(O->count, hmm->s_count, sizeof(phi_struct));
  d_high = (int *) safe_calloc(hmm->s_count, sizeof(int));

  for(i = 0, max_D = 0; i < hmm->s_count; i++) {
    d_high[i] = hmm->d[i].p[0] + 5 * hmm->d[i].p[1];
    max_D = max_D > d_high[i] ? max_D : d_high[i];
  }

  for(i = 0; i < hmm->s_count; i++) {
    if (hmm->pi[i] > 0)
      delta[0][i] =
	hmm->pi[i] * gauss_dis(1, hmm->d[i].p[0], hmm->d[i].p[1]) *
	  hmm->b[i][(int) O->o[0]];
    else
      delta[0][i] = 0.0;
  }

/* Recursion / Iteration */

  for (t = 1; t < O->count; t++) {
    for (i = 0; i < hmm->s_count; i++) {

      d_high_bound = d_high[i];
      phi[t][i].state = 0;
      phi[t][i].duration = 0;
      temp_2 = 0.0;

      if (t < max_D) {
	if (hmm->pi[i] > 0.0) {
	  temp_2 = hmm->pi[i] * gauss_dis(t+1, hmm->d[i].p[0], hmm->d[i].p[1]);
	  for(s = 0; s <= t; s++) temp_2 *= hmm->b[i][(int) O->o[s]];
	  phi[t][i].state = i;
	  phi[t][i].duration = t;
	}
	d_high_bound = t;
      }

      b_prod = 1.0;
      for(d = 1; d <= d_high_bound; d++) {
	b_prod *= hmm->b[i][(int) O->o[t-d+1]];
	prev_state = 0;
	for(j = 0; j < hmm->s_count; j++) {
	  if (hmm->a[j][i] > 0.0) {
	    if ((temp_4 = hmm->a[j][i] * delta[t-d][j]) > temp_1) {
	      temp_1 = temp_4;
	      prev_state = j;
	    }
	  }
	}
	temp_1 = temp_1 * 
	  gauss_dis(d, hmm->d[i].p[0], hmm->d[i].p[1]) * b_prod;

	if (temp_1 > temp_2) {
	  temp_2 = temp_1;
	  phi[t][i].state = prev_state;
	  phi[t][i].duration = d;
	}
      }
      delta[t][i] = temp_2;
    }
  }

/* termination */

  temp_1 = 0.0;
  t = O->count - 1;
  (*Q)[O->count - 1] = 0;
  for(i = 0; i < hmm->s_count; i++) {
    if(delta[t][i] > temp_1)
      (*Q)[O->count - 1] = i;
  }

  prev_state = phi[O->count - 1][(*Q)[O->count - 1]].state;
  s = phi[O->count - 1][(*Q)[O->count - 1]].duration - 1;
  
/* Backtracking */

  for(t = O->count - 2; t >= 0; t--) {

    if (s == 0) {
      (*Q)[t] = prev_state;
      s = phi[t][prev_state].duration;
      prev_state = phi[t][prev_state].state;
    }
    else
      (*Q)[t] = (*Q)[t + 1];

    s--;
  }

/* free up the dynamic arrays */

  free2d(delta);
  free2d(phi);
  free(d_high);
  return(HMM_OK);
}

extern int SMHMM_alt_viterbi(HMM *lambda, OSet *O, int **Q)
{
  int i, j, t, d, s;
  int prev_state;
  double **delta;
  double temp_1, temp_2, temp_3, temp_4;
  int *d_high;
  int d_high_bound, max_D;
  SMHMM_p *hmm;
  phi_struct **phi;
  double **a;
  double **b;
  double *pi;
  double *sigma;
  double *mu;
  double b_prod;

  if (lambda->type != SMHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.sm);

/* create the sequence matrix Q */

  if (*Q == NULL)
    *Q = (int *) safe_calloc(O->count, sizeof(int));

/* create the log copy of the hmm model */

  a = (double **) safe_alloc2d(hmm->s_count, hmm->s_count, sizeof(double));
  b = (double **) safe_alloc2d(hmm->s_count, hmm->o_count, sizeof(double));
  pi = (double *) safe_calloc(hmm->s_count, sizeof(double));
  sigma = (double *) safe_calloc(hmm->s_count, sizeof(double));
  mu = (double *) safe_calloc(hmm->s_count, sizeof(double));

/* pre-initialization, create log(number) */

  for(i = 0; i < hmm->s_count; i++)
    for(j = 0; j < hmm->s_count; j++)
      a[i][j] = hmm->a[i][j] > 0 ?
	log(hmm->a[i][j]) : -MAX_NUMBER;

  for(i = 0; i < hmm->s_count; i++)
    for(j = 0; j < hmm->o_count; j++)
      b[i][j] = hmm->b[i][j] > 0 ?
	log(hmm->b[i][j]) : -MAX_NUMBER;

  for(i = 0; i < hmm->s_count; i++)
      pi[i] = hmm->pi[i] > 0 ?
	log(hmm->pi[i]) : -MAX_NUMBER;

  for(i = 0; i < hmm->s_count; i++)
    mu[i] = hmm->d[i].p[0];

  for(i = 0; i < hmm->s_count; i++)
    sigma[i] = hmm->d[i].p[1];


/* initialization  */

  delta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));
  phi = (phi_struct **)
    safe_alloc2d(O->count, hmm->s_count, sizeof(phi_struct));
  d_high = (int *) safe_calloc(hmm->s_count, sizeof(int));

  for(i = 0, max_D = 0; i < hmm->s_count; i++) {
    d_high[i] = mu[i] + 5 * sigma[i];
    max_D = max_D > d_high[i] ? max_D : d_high[i];
  }

  for(i = 0; i < hmm->s_count; i++) {
    if (hmm->pi[i] > 0)
      delta[0][i] =
	pi[i] + log_gauss_dis(1, mu[i], sigma[i]) + b[i][(int) O->o[0]];
    else
      delta[0][i] = -MAX_NUMBER;
  }

/* Recursion / Iteration */

  for (t = 1; t < O->count; t++) {
    for (i = 0; i < hmm->s_count; i++) {

      d_high_bound = d_high[i];
      phi[t][i].state = 0;
      phi[t][i].duration = 0;
      temp_2 = -MAX_NUMBER * 100;

      if (t < max_D) {
	if (hmm->pi[i] > 0.0) {
	  temp_2 = pi[i] + log_gauss_dis(t+1, mu[i], sigma[i]);
	  for(s = 0; s <= t; s++) temp_2 += b[i][(int) O->o[s]];
	  phi[t][i].state = i;
	  phi[t][i].duration = t;
	}
	d_high_bound = t;
      }
      
      b_prod = 0.0;
      for(d = 1; d <= d_high_bound; d++) {
	b_prod += b[i][(int) O->o[t-d+1]];
	temp_1 = -MAX_NUMBER * 100;
	prev_state = 0;
	for(j = 0; j < hmm->s_count; j++) {
	  if (hmm->a[j][i] > 0.0) {
	    if ((temp_4 = delta[t-d][j] + a[j][i]) > temp_1) {
	      temp_1 = temp_4;
	      prev_state = j;
	    }
	  }
	}
	temp_1 = temp_1 + log_gauss_dis(d, mu[i], sigma[i]) + b_prod;

	if (temp_1 > temp_2) {
	  temp_2 = temp_1;
	  phi[t][i].state = prev_state;
	  phi[t][i].duration = d;
	}
      }
      delta[t][i] = temp_2;

#ifdef DEBUG
      if (delta[t][i] > -400)
	fprintf(stdout, "|%2i|%3i|%7.2f", phi[t][i].state,
		phi[t][i].duration, -delta[t][i]);
      else
	fprintf(stdout, "|  |   |       ");
#endif

    }

#ifdef DEBUG
    fprintf(stdout, "|\n");
#endif

  }

/* termination */

  temp_1 = -MAX_NUMBER * 100;
  t = O->count - 1;
  (*Q)[O->count - 1] = 0;
  for(i = 0; i < hmm->s_count; i++) {
    if(delta[t][i] > temp_1)
      (*Q)[O->count - 1] = i;
  }

  prev_state = phi[O->count - 1][(*Q)[O->count - 1]].state;
  s = phi[O->count - 1][(*Q)[O->count - 1]].duration - 1;
  
/* Backtracking */

  for(t = O->count - 2; t >= 0; t--) {

    if (s == 0) {
      (*Q)[t] = prev_state;
      s = phi[t][prev_state].duration;
      prev_state = phi[t][prev_state].state;
    }
    else
      (*Q)[t] = (*Q)[t + 1];

    s--;
  }

/* free up the dynamic arrays */

  free2d(delta);
  free2d(phi);
  free(d_high);
  free2d(a);
  free2d(b);
  free(sigma);
  free(mu);
  return(HMM_OK);
}

/*
**  Baum Welch Calculations for Semi-Markov HMM (DHMM)
**  
**  Baum Welch Calculations for SMHMM requires the use of the following
**  4 auxillary functions:
**
**  alpha_1(t, i) = same as forward estimation
**              = P(o1...ot, qt = i | lambda)
**
**  alpha_2(t, j) = sum(i = 1..N, alpha(t, i) * a(i, j))
**                = P(o1...ot, qt+1 = j | lambda)
** 
**  beta_1(t, i) = sum(j = 1..N, a(i,j) * beta_2(t, j))
**             = P(ot+1..oT|qt = i, lambda)
**
**  beta_2(t, i) = sum(d = 1..D, beta(t+d, i) * p(i,d) *
**                 prod(s=t+1..t+d, b(i, o(s)))
**               = P(ot+1..oT | qt+1 = i, lambda)
**
**  these four functions can be combined to produce the estimation
**  formula for the parameters of lambda.
**
**  for pi(i), the estimation formula is:
**
**  new_pi(i) = pi(i) * beta_2(0, i) / P(O|Lambda)
**
**  for a(i, j), the estimation formula is:
**
**  new_a(i,j) = sum(t = 1..T, alpha(t,i) * a(i,j) * beta_2(t, j))/
**               sum(all possible i of above)
**             = E{q(t) = i, q(t+1) = j} / E{all possible sequences}
**
**  for b(i,j), the estimation formula is:
**
**  new_b(i,j) = sum(t = 1..T & o(t) = vk, sum(tau < t, alpha_2(tau, i) *
**               beta_2(tau, i)) - sum(tau < t, alpha(tau, i) * beta(tau, i)))
**               / sum( all possible vk)
**
**  duration parameters are estimated using the method described in Levinson.
**  
*/

/* find the four basic functions */

/* find_alpha_1
**
** alpha_1(t, i) = sum(d = 1..D, alpha_2(t-d)*p(i, d)*prod(s = t-d+1..t,
**                 b(i,o(s))))
** alpha_1(t, i) must also include the initial condition of no state
** transition, and initial probability of pi(i)
*/

extern int SMHMM_find_alpha_1(int t, int i, SMHMM_p *hmm,
			      double **alpha_1, double **alpha_2, OSet *O,
			      int *d_high, int max_D)
{
  int d, s;
  double temp_1, temp_2;
  int temp_3;
  int high_bound;
  double b_prod;

  alpha_1[t][i] = 0.0;

/* the no transition senario */

  if ((t < max_D) && (hmm->pi[i] > 0.0)) {
    alpha_1[t][i] =
      hmm->pi[i] * gauss_dis(t + 1, hmm->d[i].p[0], hmm->d[i].p[1]);
    for(s = 0; s <= t; s++) alpha_1[t][i] *= hmm->b[i][(int)O->o[s]];
  }

/* the with transition scenario */

  high_bound = t > d_high[i] ? d_high[i] : t;

  b_prod = 1.0;
  for(d = 1; d <= high_bound; d++) {
    b_prod *= hmm->b[i][(int) O->o[t-d+1]];
    if (alpha_2[t - d][i] > 0.0) {
      temp_1 = alpha_2[t - d][i] * 
	gauss_dis(d, hmm->d[i].p[0], hmm->d[i].p[1]) * b_prod;
    }
    else
      temp_1 = 0.0;
    alpha_1[t][i] += temp_1;
  }
  return(HMM_OK);
}
  

/* find_alpha_2
**
** alpha_2(t, i) = sum(i = 1..N, alpha_1(t, i) * alpha(i,j))
**
*/

extern int SMHMM_find_alpha_2(int t, int j, SMHMM_p *hmm,
			      double **alpha_1, double **alpha_2, OSet *O,
			      int *d_high, int max_D)
{
  int i;

  alpha_2[t][j] = 0.0;
  for(i = 0; i < hmm->s_count; i++) {
    if (hmm->a[i][j] > 0.0)
      alpha_2[t][j] += hmm->a[i][j] * alpha_1[t][i];
  }
  return(HMM_OK);
}

/*
** find_beta_1:
**
** beta_1(t, i) = sum(j = 1..N, a[i][j] * beta_2(t, j))
**
*/

extern int SMHMM_find_beta_1(int t, int i, SMHMM_p *hmm,
			     double **beta_1, double **beta_2, OSet *O,
			     int *d_high, int max_D)
{
  int j;

  beta_1[t][i] = 0.0;
  for(j = 0; j < hmm->s_count; j++)
    if (hmm->a[i][j] > 0.0) beta_1[t][i] += hmm->a[i][j] * beta_2[t][j];

  return(HMM_OK);
}

/*
** find_beta_2:
**
** beta_2(t, i) = sum(d = 1..D, beta_1(t+d) * p(i,d) *
**                    prod(s = t+1..t+d, b(i,o(s)))
*/

extern int SMHMM_find_beta_2(int t, int i, SMHMM_p *hmm,
			     double **beta_1, double **beta_2, OSet *O,
			     int *d_high, int max_D)
{
  int s, d;
  double temp_1;
  int high_bound;
  int temp_4;
  double b_prod;

  high_bound = d_high[i]  < (O->count - t) ? d_high[i] : O->count - t - 1;
  beta_2[t][i] = 0.0;
  b_prod = 1.0;
  for(d = 1; d <= high_bound; d++) {
    temp_4 = t + d;
    b_prod *= hmm->b[i][(int) O->o[temp_4]];
    temp_1 = beta_1[temp_4][i] *
      gauss_dis(d, hmm->d[i].p[0], hmm->d[i].p[1]) * b_prod;
    beta_2[t][i] += temp_1;
  }

  return(HMM_OK);
}

/* the iteration routines which will find the proper alpha's & beta's */

extern int SMHMM_find_alpha_beta(HMM *lambda, double ***alpha_1,
				 double ***alpha_2, double ***beta_1,
				 double ***beta_2, OSet *O)
{
  int i, j, t;
  SMHMM_p *hmm;
  int max_D;
  int *d_high;

  if (lambda->type != SMHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.sm);

/* create alpha_1, alpha_2, beta_1, beta_2, d_high */

  *alpha_1 = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));
  *alpha_2 = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));
  *beta_1 = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));
  *beta_2 = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));

  d_high = (int *) safe_calloc(hmm->s_count, sizeof(int));

/*
** define the maximum number for D as max(mean(i) + 3 * sigma(i))
** the max is hard coded based on gaussian dist.  in the future,
** a set of functions that provide this value will be stored in a
** table and initialized at run time.
*/

  for(i = 0, max_D = 0; i < hmm->s_count; i++) {
    d_high[i] = hmm->d[i].p[0] + 5 * hmm->d[i].p[1];
    max_D = max_D > d_high[i] ? max_D : d_high[i];
  }

/* do the forward initialization & iterations */

  for(t = 0; t < O->count - 1; t++) {
    for(i = 0; i < hmm->s_count; i++) {
      SMHMM_find_alpha_1(t, i, hmm, *alpha_1, *alpha_2, O, d_high, max_D);
    }
    for(j = 0; j < hmm->s_count; j++) {
      SMHMM_find_alpha_2(t, j, hmm, *alpha_1, *alpha_2, O, d_high, max_D);
    }
  }

/* forward termination */

  for(i = 0; i < hmm->s_count; i++) {
    SMHMM_find_alpha_1(t, i, hmm, *alpha_1, *alpha_2, O, d_high, max_D);
  }

/* do the backward initialization & iterations */

  for(i = 0; i < hmm->s_count; i++) {
    (*beta_1)[O->count - 1][i] = 1.0;
    (*beta_2)[O->count - 1][i] = 1.0;
  }
  
  for(t = O->count - 2; t >= 0; t--) {
    for(i = 0; i < hmm->s_count; i++) {
      SMHMM_find_beta_2(t, i, hmm, *beta_1, *beta_2, O, d_high, max_D);
    }

    for(i = 0; i < hmm->s_count; i++) {
      SMHMM_find_beta_1(t, i, hmm, *beta_1, *beta_2, O, d_high, max_D);
    }
  }

  free(d_high);

  return(HMM_OK);
}

/* estimation formula for estimating b(O)
**
** b(i,k)' = sum(sum(a2*b2, t < D) - sum(a1*b1, t < D), T) /
**           sum(sum(sum(a2*b2, t < D) - sum(a1*b1, t < D), T), M)
*/

int SMHMM_new_b(SMHMM_p *hmm, OSet *O, double **alpha_1, double **alpha_2,
		double **beta_1, double **beta_2, double **new_b)

{
  int i, j, k, t, t1, d;
  int o_len;
  double **temp1;
  double *temp2, *temp3;
  double temp4, temp5, temp6;
  int *d_high;
  double *b_prod;

  if (new_b == NULL)
    return(HMM_ERROR);

  o_len = O->count;
  temp1 = (double **) safe_alloc2d(hmm->s_count, hmm->o_count, sizeof(double));
  temp2 = (double *) safe_calloc(hmm->s_count, sizeof(double));
  temp3 = (double *) safe_calloc(hmm->s_count, sizeof(double));
  b_prod = (double *) safe_calloc(hmm->s_count, sizeof(double));
  d_high = (int *) safe_calloc(hmm->s_count, sizeof(int));

/*
** define the maximum number for D as max(mean(i) + 3 * sigma(i))
** the max is hard coded based on gaussian dist.  in the future,
** a set of functions that provide this value will be stored in a
** table and initialized at run time.
*/

  for(i = 0; i < hmm->s_count; i++) {
    d_high[i] = hmm->d[i].p[0] + 5.0 * hmm->d[i].p[1];
  }

  for(t = 0; t < o_len; t++) {
    k = (int) O->o[t];
    for(i = 0; i < hmm->s_count; i++) {
      temp2[i] += alpha_2[t][i] * beta_2[t][i];
      temp3[i] += alpha_1[t][i] * beta_1[t][i];

/* first, do the case where O starts with state i */

      if (hmm->b[i][k] > 0.0) {
	if (hmm->pi[i] > 0.0) {
	  if (t < d_high[i]) {
	    b_prod[i] = hmm->pi[i];
	    for(d = 1; d <= d_high[i]; d++) {
	      b_prod[i] *= hmm->b[i][(int) O->o[d - 1]];
	      temp1[i][k] += b_prod[i] * beta_1[d][i] *
		gauss_dis(d, hmm->d[i].p[0], hmm->d[i].p[1]);
	    }
	  }
	}

/* do the case where O doesn't start with state i */

	temp1[i][k] += (temp2[i] - temp3[i]);
      }
    }
  }

/* do the BW estimate updates with rate limitatioin */

  for(i = 0; i < hmm->s_count; i++) {
    for(k = 0, temp4 = 0.0; k < hmm->o_count; k++) temp4 += temp1[i][k];
    if (temp4 > 0.0) {
      for(k = 0; k < hmm->o_count; k++)	{
	if (temp1[i][k] > 0.0) {
	  temp5 = temp1[i][k]/temp4;
	  temp6 = (temp5 / hmm->b[i][k] - 1.0) > 0.0 ?
	    1.0 + MAX_BW_STEP : 1.0 - MAX_BW_STEP;
	  new_b[i][k] = fabs((temp5 / hmm->b[i][k]) - 1.0) < MAX_BW_STEP ?
	    temp5 : hmm->b[i][k] * temp6;
	}
	else
	  new_b[i][k] = hmm->b[i][k];
      }
    }
    else
      for(k = 0; k < hmm->o_count; k++)	new_b[i][k] = hmm->b[i][k];
  }

/* renormalize the resulting b distributions */

  for(i = 0; i < hmm->s_count; i++) {
    for(k = 0, temp4 = 0.0; k < hmm->o_count; k++) temp4 += new_b[i][k];
    if (temp4 > 0.0)
      for(k = 0; k < hmm->o_count; k++) new_b[i][k] /= temp4;
  }

  free2d(temp1);
  free(d_high);
  free(temp2);
  free(temp3);
  free(b_prod);
  return(HMM_OK);
}      

/* estimation formula for estimating d
**
** mu is the expected number of duration for state i
** sigma is the square root of the expected variance
**
*/

int SMHMM_new_d(SMHMM_p *hmm, OSet *O, double **alpha_1, double **alpha_2,
		double **beta_1, double **beta_2, struct DIST_param *new_d)

{
  int i, j, t, d, s;
  int o_len;
  double temp1, temp2, temp3, temp4, temp5;
  double b_prod;
  int *d_high;

  if (new_d == NULL)
    return(HMM_ERROR);

  o_len = O->count;
  d_high = (int *) safe_calloc(hmm->s_count, sizeof(int));

/*
** define the maximum number for D as max(mean(i) + 3 * sigma(i))
** the max is hard coded based on gaussian dist.  in the future,
** a set of functions that provide this value will be stored in a
** table and initialized at run time.
*/

  for(i = 0; i < hmm->s_count; i++) {
    d_high[i] = hmm->d[i].p[0] + 5 * hmm->d[i].p[1];
  }

/* estimate the number of durations for a given state */

  for(i = 0; i < hmm->s_count; i++) {
    temp4 = 0.0;
    temp2 = 0.0;
    temp3 = 0.0;

/* find the case of seq start at state i */

    if (hmm->pi[i] > 0.0) {
      b_prod = 1.0;
      for(d = 1; d < d_high[i]; d++) {
	b_prod *= hmm->b[i][(int) O->o[d - 1]];
	temp1 = hmm->pi[i] * b_prod * beta_1[d - 1][i];
	temp2 += d * temp1;
	temp4 += temp1;
	temp3 += sqr(d - hmm->d[i].p[0]) * temp1;
      }
    }

/* find the case where seq doesn't start at state i */

    for(t = 0; t < o_len; t++) {
      b_prod = 1.0;
      for(d = 1; t >= d; d++) {
	b_prod *= hmm->b[i][(int) O->o[t - d + 1]];
	temp1 = alpha_2[t - d][i] *
	  gauss_dis(d, hmm->d[i].p[0], hmm->d[i].p[1]) * b_prod * beta_1[t][i];
	temp2 += d * temp1;
	temp4 += temp1;
	temp3 += sqr(d - hmm->d[i].p[0]) * temp1;
      }
    }

/* update the new set of parameters, rate limited to MAX_BW_STEP */

    if (temp4 > MIN_NUMBER) {
      temp5 = (temp2/temp4) / hmm->d[i].p[0] - 1.0;
      temp1 = temp5 > 0 ? 1.0 + MAX_BW_STEP : 1.0 - MAX_BW_STEP;
      new_d[i].p[0] = fabs(temp5) < MAX_BW_STEP ?  (temp2/temp4) :
	hmm->d[i].p[0] * temp1;

      temp5 = sqrt(temp3/temp4) / hmm->d[i].p[1] - 1.0;
      temp1 = temp5 > 0.0 ? 1.0 + MAX_BW_STEP : 1.0 - MAX_BW_STEP;
      new_d[i].p[1] = fabs(temp5) < MAX_BW_STEP ?  sqrt(temp3/temp4) :
	hmm->d[i].p[1] * temp1;
    }
    else {
      new_d[i].p[0] = hmm->d[i].p[0];
      new_d[i].p[1] = hmm->d[i].p[1];
    }
  }
  free(d_high);
  return(HMM_OK);
}      

/*
**  Baum Welch Estimation for SMHMM
**
**  The Baum welch estimation is base on both Levinson's work as well
**  as Rabiner's work on SMHMM.  The Estimation method for a[i][j] and b
**  are based on Rabiner, while the parameter estimation method for the
**  durational parameter is based on Levinson.  The detailed formulae are
**  listed before each subroutine.
**
*/

extern int SMHMM_bw_estimate(HMM *lambda, OSet *O)
{
  double **alpha_1, **alpha_2;
  double **beta_1, **beta_2;
  SMHMM_p new_hmm;
  SMHMM_p *hmm;
  int i, j, k;

  if (lambda->type != SMHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.sm);

/* find alpha's and beta's */

  SMHMM_find_alpha_beta(lambda, &alpha_1, &alpha_2, &beta_1, &beta_2, O);

#ifdef PRINT_ALPHA_BETA

  printf("Alpha 1\n");
  for(i = 0; i < O->count; i++) {
    printf("|%3i", i);
    for(j = 0; j < hmm->s_count; j++) {
      if (alpha_1[i][j] > 1e-300)
	printf("|%12.4e", alpha_1[i][j]);
      else
	printf("|            ");
    }
    printf("|\n");
  }

  printf("Alpha 2\n");
  for(i = 0; i < O->count; i++) {
    printf("|%3i", i);
    for(j = 0; j < hmm->s_count; j++) {
      if (alpha_1[i][j] > 1e-300)
	printf("|%12.4e", alpha_2[i][j]);
      else
	printf("|            ");
    }
    printf("|\n");
  }

  printf("Beta 1\n");
  for(i = 0; i < O->count; i++) {
    printf("|%3i", i);
    for(j = 0; j < hmm->s_count; j++) {
      if (alpha_1[i][j] > 1e-300)
	printf("|%12.4e", beta_1[i][j]);
      else
	printf("|            ");
    }
    printf("|\n");
  }

  printf("Beta 2\n");
  for(i = 0; i < O->count; i++) {
    printf("|%3i", i);
    for(j = 0; j < hmm->s_count; j++) {
      if (alpha_1[i][j] > 1e-300)
	printf("|%12.4e", beta_2[i][j]);
      else
	printf("|            ");
    }
    printf("|\n");
  }

#endif

/* estimate new b */

  new_hmm.b =
    (double **) safe_alloc2d(hmm->s_count, hmm->o_count, sizeof(double));

  SMHMM_new_b(hmm, O, alpha_1, alpha_2, beta_1, beta_2, new_hmm.b);

#ifdef PRINT_ALPHA_BETA
  
  for(i = 0; i < hmm->s_count; i++) {
    printf("new-%2i", i+1);
    for(j = 0; j < hmm->o_count; j++)
      printf("%8.4f ", fabs(new_hmm.b[i][j]));
    printf("\n");
    printf("old-%2i", i+1);
    for(j = 0; j < hmm->o_count; j++)
      printf("%8.4f ", hmm->b[i][j]);
    printf("\n");
  }

#endif

/* estimate the durational parameters mu and sigma */

  new_hmm.d =
    (struct DIST_param *) safe_calloc(hmm->s_count,sizeof(struct DIST_param));

  for(i = 0; i < hmm->s_count; i++) {
    new_hmm.d[i].p_count = 2;
    new_hmm.d[i].type = GAUSS;
    new_hmm.d[i].p = (double *) safe_calloc(2, sizeof(double));
  }

  SMHMM_new_d(hmm, O, alpha_1, alpha_2, beta_1, beta_2, new_hmm.d);

#ifdef PRINT_ALPHA_BETA

  for(i = 0; i < hmm->s_count; i++) {
    printf("%2i %6.2f %6.2f %6.2f %6.2f\n", i+1,
	   new_hmm.d[i].p[0], hmm->d[i].p[0],
	   new_hmm.d[i].p[1], hmm->d[i].p[1]);
  }

#endif

/* copy the new parameters to the HMM model */

  for(i = 0; i < hmm->s_count; i++) {
    for(j = 0; j < hmm->o_count; j++)
      hmm->b[i][j] = new_hmm.b[i][j];
    hmm->d[i].p[0] = new_hmm.d[i].p[0];
    hmm->d[i].p[1] = new_hmm.d[i].p[1];
  }

/* clean up dynamic memory allocations */

  for(i = hmm->s_count - 1; i >= 0; i--)
    free(new_hmm.d[i].p);
  free(new_hmm.d);
  free2d(alpha_1);
  free2d(alpha_2);
  free2d(beta_1);
  free2d(beta_2);
  free2d(new_hmm.b);

  return(HMM_OK);
}
