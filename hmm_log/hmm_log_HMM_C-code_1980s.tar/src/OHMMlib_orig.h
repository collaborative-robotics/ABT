/*
**  OHMMlib.h
**
**  HMM function library Header
**
**  V 0.2
**  02/01/94
**
**  Darwei Kung
**
**  This code provides all the subroutines for performing HMM calculations.
**  Most of the code is based on the code written by Paul Lee for JPL.
**
**  The types defined in HMMtype.h is used to provide templates for different
**  HMM's.  The functions provided in this file include the viterbi and the
**  Baum_Welch programs.  The data i/o parts of the original HMM c programs
**  are taken out, to make the code easier to read.
**
*/

/* forward algorithm */

extern int OHMM_forward_term(HMM *lambda, double **alpha, OSet *O, double *P, double *w);
extern int OHMM_scaled_find_alpha(HMM *lambda, double ***alpha, OSet *O, double **w);

/* backward algorithm */

extern int OHMM_find_beta(HMM *lambda, double ***beta, OSet *O);

/* viterbi algorithm */

extern int OHMM_viterbi(HMM *lambda, OSet *O, int **Q);
extern int OHMM_init_trunc(HMM *lambda,
			  int window_size,
			  int detect_merge);

extern int OHMM_trunc_viterbi(HMM *lambda, OSet *O, int **Q);


/* baum-welch algorithm */

extern int OHMM_bw_estimate(HMM *lambda, double **alpha,
			    double **beta, OSet *O);

/* File IO routines */

extern int OHMM_read_lambda(HMM **lambda, char *filename);
extern int OHMM_write_lambda(HMM *lambda, char *filename);

/* Clean Up Routine */

extern int OHMM_free_lambda(HMM **lambda);

