/*log.h
 *
 *  Include file defining data structures for recommended binary
 *    data logging format.
 *
 *  Marcos Salganicoff, Blake Hannaford  
 *  Applied Robotics & Teleoperators Group
 *  Jet Propulsion Laboratory
 *  Pasadena, CA 91109
 *  (818)354-6379/051
 *
 */

#define MAXLINE 256 /* maximum number of characters in a string field */
#define MAXNO_OF_CHANNELS 128 /* Maximum number of channels in record */
#define CHAR  0 
#define SHORT 1
#define INT   2
#define LONG  3
#define FLOAT 4
#define DOUBLE 5

#include <sys/file.h>

struct channel_info{
   char name[64]; /* descriptive name */
   int spare1; /* miscellaneous codes */
   int spare2; /* miscellaneous codes */
};

/* binary data logging file header    */

struct log{
   char idline[16]; /* BHMS idtag field */
   char date_time[64]; /* date/time of run */
   char filename[32];  /* filename */
   char experimentor[64]; /* investigator */
   char subject[64]; /* subject's name */
   char progname[32]; /* data generating programs name */
   char progversion[16]; /* version of prog */
   char comments[MAXLINE]; /* conditions etc. */
   int  sample_rate; /* sampling frequency */
   int  number_vars; /* number of sampled parameters*/
   int  block_size; /* number of state vectors in a block */
   struct channel_info *channel_array[MAXNO_OF_CHANNELS]; /* array of ptrs to descriptive parameter info */
   int numberofsamples; /* total # of datums in file */
   int type; /* type (floating, int etc . ) */
   int checksum; /* checksum - not implemented */
   char padding[968];
};

/* run-time structure containing all binary-data-format file information   */

struct data_file_info{
 struct log header;	/* file's header structure  */
 int fdes;		/* file descriptor   */
 char rw;		/* read / write flag (either 'r' or 'w') */
 int total_bytes;	/* number of bytes so far */
 int state_bytes;	/*   "     "   "     "  state vector  */
 int block_bytes;	/*   "     "   "     "  block 
                            if == 0, then no block buffering (default) */
 char *array,*beg_array; /* ptrs. to allocated array if block buffering*/ 
 };

#define HFILE struct data_file_info

