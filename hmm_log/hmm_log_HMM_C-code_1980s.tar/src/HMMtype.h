/*  HMMtype.h
**
**  Type definition for HMM program
**
**  V 0.2
**  01/22/94
**
**  Darwei Kung
**  (based on Paul Lee's Original HMM code)
**
**  This code includes the headers for HMM type definitions.  There are
**  two major sections in this header file.  The probability distributions
**  are defined first; then the actul HMM types are declared.  The data
**  hightly utilizes the enum/union types.
**
*/

/*
**
**  Statistical Modeling type definitions
**
*/

enum DIST_type { 
  GAUSS,                        /* Gaussian Distribution */
  GAMMA,                        /* Gamma Distribution */
  UNIFORM,                      /* Uniform Distribtuion */
  DISCRETE,                     /* Discrete mass function */
  UNDEFINED                     /* Undefined */
};

struct GAUSS_param {            /* Gaussian Distribution Parameters */
  double mu;                    /* mu = mean */
  double sigma;                 /* sigma = standard deviation */
};

struct GAMMA_param {            /* Gamma Distribution Parameters */
  double alpha;                 /* mean = alpha / beta */
  double beta;                  /* std var = alpha / beta^2 */
};

struct UNIFORM_param {          /* Uniform Distribution Parameters */
  double lower;                 /* u(x - lower) * u(upper - x) */
  double upper;
};

struct DISCRETE_param {         /* Discrete Mass Functions */
  double *mass;                 /* array of discrete probabilities */
};

struct UNDEFINED_param {        /* Undefined Probability Distribution */
  int *data;                    /* pointer to the data */
  double (*access)();           /* a function that would access the data */
};

struct DIST_param {              /* general parameter reference */
  enum DIST_type type;
  int p_count;
  double *p;
};

/*
**
**  HMM type definitions
**
*/

enum HMM_type {                 /* different types of HMM */
  DHMM,                         /* Discrete observation HMM */
  IHMM,                         /* Inhomogeneous HMM */
  OHMM,                         /* Continous observation HMM */
  CHMM,                         /* Continous observation SMHMM */
  SMHMM                         /* Semi-Markov HMM */
};

typedef struct {                /* Discrete Observation HMM */
  double *pi;                   /* pi[i] initial observation probabilty */
  double **a;                   /* a[i][j] state i to state j */
  double **b;                   /* b[i][j] state i, obs symbol j */
  int s_count;                  /* number of states in this HMM */
  int o_count;                  /* number of obs. buckets */
  char **s_name;                /* names of the states */
} DHMM_p;

typedef struct {                /* Continous Observation HMM */
  double *pi;                   /* pi[i] initial probability distribution */
  double **a;                   /* a[i][j] transitional probability */
  struct DIST_param *b;         /* b[i].mu[j], b[i].sigma[j] Gauss param. */
  int s_count;                  /* number of states */
  int o_count;                  /* number of obs. buckets */
  int d_count;                  /* max number for duration */
  char **s_name;                /* names of the states */
} OHMM_p;

typedef struct {                /* Continous Observation HMM */
  double *pi;                   /* pi[i] initial probability distribution */
  double **a;                   /* a[i][j] transitional probability */
  struct DIST_param *b;         /* b[i].mu[j], b[i].sigma[j] Gauss param. */
  struct DIST_param *d;          /* d[k].mass[l] state k, duration l */
  int s_count;                  /* number of states */
  int o_count;                  /* number of obs. buckets */
  int d_count;                  /* max number for duration */
  char **s_name;                /* names of the states */
} CHMM_p;

typedef struct {                /* Semi-Markov HMM */
  double *pi;                   /* pi[i] initial observation probabilty */
  double **a;                   /* a[i][j] state i to state j */
  double **b;                   /* b[i][j] state i, obs. j */
  struct DIST_param *d;          /* d[k].mass[l] state k, duration l */
  int s_count;                  /* number of states in this HMM */
  int o_count;                  /* number of distinct Observations */
  int d_count;                  /* max number for duration */
  char **s_name;                /* names of the states */
} SMHMM_p;

typedef struct {                /* Inhomogeneous HMM */
  double *pi;                   /* pi[i] initial observation probabilty */
  double ***a;                  /* a[i][j][d] state i to state j duration d*/
  struct DIST_param **b;        /* b[i][d].mass[j] state i obs. j duration d */
  int s_count;                  /* number of states in this HMM */
  int o_count;                  /* number of distinct Observations */
  int d_count;                  /* number of periods for duration */
  char **s_name;                /* names of the states */
} IHMM_p;

typedef struct {                       /* the HMM storage structure */
  union {
    DHMM_p d;
    CHMM_p c;
    SMHMM_p sm;
    IHMM_p i;
    OHMM_p o;
  } par;
  enum HMM_type type;           /* the HMM type */
  double period;                /* the sampling period, in sec */
} HMM;

typedef struct {
  int size;                     /* size of observation array */
  int count;                    /* number of observations */
  double **o;                   /* o[t][i] observation element i at time t */
} OSet;

/*
**  B functions.  functions which determines the result of b(t, j)
**  at time t, state j.
**
**  The calling format will be bfunc(hmm, oset, time, state), and
**  the probablity will be a doulbe between 0 and 1.
**
*/

typedef double (*BFunc) (HMM *, OSet *, int, int);

/*
**  Status indicators 
**
*/

#define HMM_OK           0      /* no error */
#define HMM_ERROR        1      /* a problem has occured during */
#define HMM_OVERFLOW     2      /* overflow math error */
#define HMM_UNDERFLOW    4      /* underflow math error */
#define HMM_IO           8      /* input output error */
#define HMM_MEM          16     /* dynamic memory error problem */
#define HMM_MISMATCH     32     /* HMM type mismatch */
