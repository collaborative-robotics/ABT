/* this program tests the improvement of P(O | Lambda) from BW Estimation */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>
#include "HMMtype.h"
#include "OHMMlib.h"

#define MAX_LEN  2000

int find_p(char *orig_hmm_file, char *hmm_file)
{
  HMM *hmm = NULL;
  HMM *orig_hmm = NULL;
  int i, j;

  if (OHMM_read_lambda(&orig_hmm, orig_hmm_file) != HMM_OK)
    abort();

  if (OHMM_read_lambda(&hmm, hmm_file) != HMM_OK)
    abort();

fprintf(stderr, "hmm[1]=%e ",(*hmm));
  OHMM_free(hmm);
  OHMM_free(orig_hmm);
}


void main(int argc, char **argv)
{

  if (argc != 3) {
    fprintf(stderr, "wrong number of arguments, ");
    fprintf(stderr, "try calOHMM orig_hmm new_hmm\n");
    exit(1);
  }


  find_p(argv[1], argv[2]);
/*
  fprintf(stdout, "%le %8.6f\n", pr, er);
*/
  exit(0);
}
