/*  HMMconst.h
**
**  constant values definition for HMM program
**
**  V 0.3
**  07/20/94
**
**  Darwei Kung
**  (based on Paul Lee's Original HMM code)
**
**  This code includes the headers for HMM type definitions.  There are
**  two major sections in this header file.  The probability distributions
**  are defined first; then the actul HMM types are declared.  The data
**  hightly utilizes the enum/union types.
**
**  V 0.3 DK
**  Added NORM_CYCLE to account for the normalizatio period
**
**
*/

/* Baum Welch Estimation Constants */

#define MIN_NUMBER    1e-300      /* similar to min double */
#define MAX_NUMBER    1e+300      /* similar to max double */
#define MIN_BW_STATE  0.8         /* must have at least one state */
#define MAX_BW_STEP   0.1         /* change up to +/- 10% */
#define MIN_STD       0.29        /* the minimum variance is 1/10 of mean */
#define NORM_CYCLE    10          /* Alpha/Beta Normalization Cycle */
#define STD_INTERVAL  5           /* number of std dev buckets */
#define DEF_W_SIZE    10          /* default sliding window size */
#define DO_MERGE      1           /* merge point detection is default to on */

static char *dist_name[] = {"GAUSS", "GAMMA", "UNIFORM", "DISCRETE"};
static int dist_number[] = {GAUSS, GAMMA, UNIFORM, DISCRETE};
static int dist_p_count[] = {2, 2, 2, 10};
