/*
**  genseq.c
**
**  This program generates a specific training sequence.
**
**  V 0.1
**  09/15/94
**
**  Darwei Kung
**
**  This program takes two arguments.  The first one is a string, whose
**  elements are seperated by spaces.  This is a list of identifiers for
**  file names.  The second argument is a number whose value indicates
**  the number of repetition.  The number of identifiers is limited to
**  1000.
**
**  The output to the stdout is a sequence of identifiers.
**
**  an optional 3rd argument let the user specify the random number seed.
**
*/

#include <stdio.h>
#include <math.h>
#include <sys/time.h>
#include <string.h>
#include "statlib.h"

int err_msg(char *err)
{
  fprintf(stderr, "\nError - %s\n", err);
  fprintf(stderr, "try genseq list repetition <seed>\n");
  exit(1);
}

void main(int argc, char *argv[])
{
  int i, j, id1, id2;
  int seq[500];
  struct timeval tv;
  struct timezone tz;
  int seed, temp;
  double r_out;
  char *id[1000];
  int id_cnt = 0;
  int rep_cnt = 0;
  double id_range = 0.0;

/* set random seed */

  switch (argc) {
  case 4 :
    seed = atoi(argv[3]);
    break;
  case 3 :
    gettimeofday(&tv, &tz);
    seed = tv.tv_sec % 32767;
    break;
  default:
    err_msg("Wrong Number of arguments");
    break;
  }

/* parse the id list */

  id[id_cnt] = strtok(argv[1], " \n\t");
  while (id[id_cnt] != NULL)
    id[++id_cnt] = strtok(NULL, " \n\t");

/* find number of repetitions */

  rep_cnt = atoi(argv[2]);

/* generate a fixed list */

  for (i = 0; i < id_cnt; i++)
    for (j = 0; j < rep_cnt; j++)
      seq[j * id_cnt + i] = i;

/* generate a random sequence */

  srand(seed);
  seed_rand(rand());
  id_range = (double) (id_cnt * rep_cnt);

  for(i = 0; i < 50000; i++) {
    id1 = (int) floor(uniform_rand(0.0, (id_range)));
    id1 = (id1 < 0) ? 0 : id1;
    id1 = (id1 > (id_range - 1)) ? id_range - 1 : id1;
    id2 = (int) floor(uniform_rand(0.0, (id_range)));
    id2 = (id2 < 0) ? 0 : id2;
    id2 = (id2 > (id_range - 1)) ? id_range - 1 : id2;
    j = seq[id1];
    seq[id1] = seq[id2];
    seq[id2] = j;
  }

  for(i = 0; i < (id_cnt * rep_cnt); i++)
    printf("%s\n", id[seq[i]]);

  exit(0);
}
