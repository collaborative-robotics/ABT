/******************************************************************************
 *
 * NAME
 *    block.c
 *    J. R. Goldschneider 4/93
 *
 * MODIFICATIOMS
 *    11/93 modified to allow defaults to be listed. JRG
 *
 * SYNOPSIS
 *    block -i f1 -o f2 -r rows -l columns -h blockheight -w blockwidth
 *
 * DESCRIPTION
 *    For f1 in raw image form, block creates f2 (f1.TS the default 
 *    if f2 is null), which is a list of vectors where each
 *    vector is a block of f1, and f1 has the specified number 
 *    of rows and columns and the block has dimensions given by blockheight 
 *    and blockwidth.
 *
 * OPTIONS
 *    -i  filename1         DEF_INNAME     
 *    -o  filename2         DEF_OUTNAME     
 *    -r  rows              DEF_ROWS    
 *    -l  columns           DEF_COLS
 *    -h  blockheight       DEF_BLOCKHEIGHT
 *    -w  blockwidth        DEF_BLOCKWIDTH 
 *
 *    See vq.h for definitions of default values
 *
 * CALLS
 *
 *****************************************************************************/

#include <stdio.h>
#include <string.h>
#include "vq.h"

int main(argc, argv) 
     int  argc;
     char *argv[];

{
  FILE *inputfile;               /* pointer to input image */
  FILE *outputfile;              /* pointer to output image */
  char inputname[NAME_MAXIMUM];  /* name of input image */
  char outputname[NAME_MAXIMUM]; /* name of output image */
  int  rows = DEF_ROWS;          /* number of rows in image */
  int  cols = DEF_COLS;          /* number of columns in image */
  int  blockheight = DEF_BLOCKHEIGHT; /* height of block */
  int  blockwidth = DEF_BLOCKWIDTH;   /* width of block */
  char *programname = *argv;          /* name of program */
  char option;                   /* used for command line interpretation */

  DATA **blocked_image; /* 2-dimensional array for storing blocks */
  DATA *raster_image;   /* array for the whole input file */
  int  blocks_per_col;  /* number of blocks in each column of image */
  int  blocks_per_row;  /* number of blocks in each row of image */
  int  num_cols;        /* number of columns of image that will be used */
  int  num_rows;        /* number of rows of image that will be used */
  int  num_blocks;      /* number of blocks in image */
  int  num_pixels;      /* number of pixels in image */
  int  vector_length;   /* vector dimension */
  int  i,j,k;           /* counters and indices */

  /* assign default values */
  sprintf(inputname,DEF_INNAME);
  sprintf(outputname,DEF_OUTNAME);

  /* if no command options entered, list all of the defaults */
  if (argc == 1) {
    printf("%s %s %s\n",USAGE,programname,HOWTOUSE_BLOCK);
    printf("\nOPTIONS   DESCRIPTIONS             DEFAULTS\n");
    printf("-i        input file               %s\n",inputname);
    printf("-o        output file              %s\n",outputname);
    printf("-r        rows                     %d\n",rows);
    printf("-l        columns                  %d\n",cols);
    printf("-h        block height             %d\n",blockheight);
    printf("-w        block width              %d\n",blockwidth);
    printf("\n");
    fflush(stdout);
    exit(0);
  }

  /* read and interpret command line arguments */
  while (--argc && ++argv) {
    if (*argv[0]=='-' && strlen(*argv)==2) { /* each option has 1 letter */
      option = *++argv[0];
      if (--argc && ++argv) { /* examine the option */
	switch(option) { /* examine the option letter */
	case 'i':
	  strncpy(inputname,*argv,NAME_MAX);
	  break;
	case 'o':
	  strncpy(outputname,*argv,NAME_MAX);
	  break;
	case 'r':
	  sscanf(*argv,"%d",&rows);
	  break;
	case 'l':
	  sscanf(*argv,"%d",&cols);
	  break;
	case 'h':
	  sscanf(*argv,"%d",&blockheight);
	  break;
	case 'w':
	  sscanf(*argv,"%d",&blockwidth);
	  break;
	default:
	  fprintf(stderr,"%s: %c: %s\n",programname,option,NOTOPTION);
	  exit(1);
	  break;
	}
      }
      else {
	fprintf(stderr,"%s %s %s\n",USAGE,programname,HOWTOUSE_BLOCK);
	exit(2);
      }    
    }
  
    else if (*argv[0] == '-') { /* user entered unknown option */
      ++argv[0];
      fprintf(stderr,"%s: %s: %s\n",programname,*argv,NOTOPTION);
      exit(3);
    }
    else { /* user entered unknown string */
      fprintf(stderr,"%s: %s: %s\n",programname,*argv,NOTOPTION);
      exit(4);
    }
  }

  /* user did not enter an input file name */
  if (strlen(inputname) == 0 ) { 
    fprintf(stderr,"%s %s %s\n",USAGE,programname,HOWTOUSE_BLOCK);
    exit(5);
  }

  /* user entered illegal value of zero  */
  if (rows<=0 || cols<=0 || blockheight<=0 || blockwidth<=0){
    fprintf(stderr,"%s %s %s\n",USAGE,programname,HOWTOUSE_BLOCK);
    exit(6);
  }

  /* user entered an input name which is the same as the output name */
  if (strcmp(inputname,outputname) == 0) {
    fprintf(stderr,"%s: %s %s %s %s: %s\n",
	    programname,inputname,AND,outputname,ARESAME,ABORT_BLOCK);
    exit(7);
  }

  /* if an input name is given but not an output, assign output name here */
  if (strlen(outputname) == 0) {
    sprintf(outputname,"%s%s",inputname,DEF_APPEND_TS);
  }

  /* open the files */
  if((inputfile = fopen(inputname,"r")) == NULL){
    fprintf(stderr,"%s: %s: %s\n",programname,inputname,NOTFOUND);
    exit(8);
  }
  if((outputfile = fopen(outputname,"w")) == NULL){
    fprintf(stderr,"%s: %s: %s\n",programname,outputname,NOTFOUND);
    exit(9);
  }

  /* prepare the variables needed to implement algorithm.
     note that pixels at the right and lower boundaries may be neglected */

  blocks_per_col = rows/blockheight;
  blocks_per_row = cols/blockwidth;
  num_cols = blocks_per_row*blockwidth;
  num_rows = blocks_per_col*blockheight;
  num_blocks = blocks_per_col*blocks_per_row;
  num_pixels = rows*cols;
  vector_length = blockheight*blockwidth;

  /* allocate memory for the raw image and the block image  */
  if (!(raster_image = (DATA *) calloc(num_pixels, sizeof(DATA))) ||
      !(blocked_image = (DATA **) calloc(num_blocks, sizeof(DATA *)))) {
    fprintf(stderr,"%s: %s\n",programname,NOMEMORY);
    exit(10);
  }
  /* allocate memory for the block image elements */ 
  for(i=0; i<num_blocks; i++) {
    if (!(blocked_image[i] = (DATA *) calloc(vector_length,sizeof(DATA)))) {
      fprintf(stderr,"%s: %s\n",programname,NOMEMORY);
      exit(11);
    }
  }

  /* read contents of inputfile into raster_image array */
  clearerr(inputfile);
  if (fread(raster_image,sizeof(DATA),num_pixels,inputfile)!=num_pixels || 
      feof(inputfile) || ferror(inputfile) ) {
    fprintf(stderr,"%s: %s: %s\n",programname,inputname,NOREAD);
    exit(12);
  }

  /* create the block vectors and write them to the output file */
  for(i=0; i<num_blocks; i++) {
    for(j=0; j<vector_length; j++) {
      k = (i%blocks_per_row)*blockwidth + (j%blockwidth) + 
	( (i/blocks_per_row)*blockheight + (j/blockwidth) ) * cols;
      blocked_image[i][j] = raster_image[k];
    }
    if (fwrite(blocked_image[i], sizeof(DATA), vector_length, outputfile) 
	!= vector_length) {
      fprintf(stderr,"%s: %s: %s\n",programname,outputname,NOWRITE);
      exit(13);
    }
  }

  fclose(inputfile);
  fclose(outputfile);
  exit(0);
}
