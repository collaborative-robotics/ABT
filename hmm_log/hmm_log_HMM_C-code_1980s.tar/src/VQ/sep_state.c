/*
**  sep_state.c
**
**  generate a set of files based on state designation
**
**  V 0.1
**  11/01/94
**
**  Darwei Kung
**
**  this program generate a set of files, each one for an indivisual state
**  the results are written into a set of files like st_n.txt
**  the timing stamps are maintained.
**  
**  Options
**    -o  directory for output files
**    -d  directory for the original files
**    -i  input file names (accepts multiple file names)
**
*/

#include <stdio.h>

/* define program constants and defaults */

#define MAX_LEN            3000
#define MAX_STATE            20
#define MAX_INPUT_FILE      100

#define FILE_CLOSE            0
#define FILE_OPEN             1
#define FILE_ERROR           -1

#define DEFAULT_ORIG         "/homes/dkung/expr/TR/ascii_data/orig"

/* global variables */

static FILE *infile = NULL;
static FILE *infile_orig = NULL;
static FILE **outfile;
static char **input_file_name;
static char **output_file_name;
static char *orig_directory = NULL;
static char *out_directory = NULL;
static int  in_cnt = -1;
static int  out_status[MAX_STATE];


/* print error message */

int print_error_msg(char *error_msg)
{
  if (error_msg != NULL)
    fprintf(stderr, "%s\n", error_msg);
  fprintf(stderr, "Please use the following format:\n");
  fprintf(stderr,
	  "sep_state -i in files -o out directory -d original file directory");
  exit(1);
}

/* Print help for command line options */

int print_help_msg()
{
  fprintf(stderr, "Options\n");
  fprintf(stderr, "-i  input file names\n");
  fprintf(stderr, "-d  directory of the oringal file names.\n");
  fprintf(stderr, "-0  directory of the output files.\n");
  exit(0);
}

/* create the list of input file */

int create_input_file_name(char *new_name)
{

  FILE *temp;
  char error_msg[1000];

/* first time enter this routine, do a init */

  if (in_cnt < 0) {
    input_file_name = (char **) calloc(MAX_INPUT_FILE, sizeof(char *));
    in_cnt = 0;
  }

  if ((temp = fopen(new_name, "r")) != NULL) {
    fclose(temp);
    input_file_name[in_cnt++] = (char *) strdup(new_name);
  }
  else {
    sprintf(error_msg, "%s doesn't exist!", new_name);
    print_error_msg(error_msg);
  }
}

/* create output file names */

int create_output_file_name(char *out_dir)
{
  int i;
  char file_name[1000];

  outfile = (FILE **) calloc(MAX_STATE, sizeof(FILE *));
  output_file_name = (char **) calloc(MAX_STATE, sizeof(char *));

  for(i = 0; i < MAX_STATE; i++) {
    output_file_name[i] = (char *) calloc(1000, sizeof(char));
    sprintf(output_file_name[i], "%s/st_%i.txt",out_dir, i);
    out_status[i] = FILE_CLOSE;
  }
}

/* open a new output file */

int open_output_file(int state_no)
{
  char error_msg[1000];

  if (state_no > MAX_STATE) {
    sprintf(error_msg,"outfile: state number %i is more than the maximum %i",
	    state_no, MAX_STATE);
    print_error_msg(error_msg);
  }

  if (out_status[state_no] == FILE_OPEN)
    sprintf(error_msg,"outfile: tried to open the same state file twice.");
  else {
    if ((outfile[state_no] = fopen(output_file_name[state_no],"w")) == NULL) {
      sprintf(error_msg, "out_file: can't open outfile %s",
	      output_file_name[state_no]);
      print_error_msg(error_msg);
    }
    out_status[state_no] = FILE_OPEN;
  }
}

/* close all outstanding output files */

int close_output_file()
{
  int i;

  for(i = 0; i < MAX_STATE; i++) {
    if (out_status[i] == FILE_OPEN) {
      fclose(outfile[i]);
      out_status[i] = FILE_CLOSE;
    }
  }
}

/* process the input files */

int process_input_file()
{
  int i;
  char in_string[1000];
  char error_msg[1000];
  char orig_file[1000];
  char *temp_tok, *f_name;
  double temp1, temp2;
  int state_no;

  for(i = 0; i < in_cnt; i++) {

    fprintf(stderr,"Processing %s \n", input_file_name[i]);

    if ((infile = fopen(input_file_name[i], "r")) == NULL) {
      sprintf(error_msg, "input: can't read from %s", input_file_name[i]);
      print_error_msg(error_msg);
    }

    temp_tok = (char *) strtok(input_file_name[i], "/");
    while ((temp_tok = (char *) strtok(NULL,"/")) != NULL)
      f_name = temp_tok;

    sprintf(orig_file, "%s/%s", orig_directory, f_name);

    if ((infile_orig = fopen(orig_file, "r")) == NULL) {
      sprintf(error_msg, "orig: can't read from %s", orig_file);
      print_error_msg(error_msg);
    }

    while (!feof(infile)) {
      if (fgets(in_string, 1000, infile) != NULL) {

/* read the state index */

	sscanf(in_string,"%f %f %i", &temp1, &temp2, &state_no);

/* read the original data and check for time stamp */

	fgets(in_string, 1000, infile_orig);

	sscanf(in_string, "%f", &temp2);
	if (temp1 != temp2) {
	  sprintf(error_msg,
		  "time stamp %f and %f in file %s and %s don't match",
		  temp1, temp2, input_file_name[i], orig_file);
	  print_error_msg(error_msg);
	}
	if (out_status[state_no] == FILE_CLOSE) open_output_file(state_no);
	fprintf(outfile[state_no],"%s",in_string);
      }
    }
    fclose(infile);
    fclose(infile_orig);
  }
}

/* main routine.  Parse the inputs and call the initialization routines */

void main(int argc, char *argv[])
{

  int i;
  FILE *temp;

  if (argc == 1) {
    print_help_msg();
    exit(1);
  }

/* command line process */

  for (i = 1; i < argc; i++) {
    if (argv[i][0] != '-')
      print_error_msg("Please check your command line format");

    switch (argv[i][1]) {
    case 'i' :
      if (++i == argc) print_error_msg("No input file specified");
      while ((i != argc) && argv[i][0] != '-') {
	create_input_file_name(argv[i++]);
      }
      i--;
      break;

    case 'o' :
      if (out_directory != NULL)
	print_error_msg("Output directory specified twice.");
      if (++i == argc) print_error_msg("No output directory specified");
      if ((temp = fopen(argv[i], "r")) == NULL)
	print_error_msg("Can't read from directory file");
      else {
	fclose(temp);
	out_directory = (char *) strdup(argv[i]);
      }
      break;

    case 'd' :
      if (orig_directory != NULL)
	print_error_msg("Original Data  directory specified twice.");
      if (++i == argc) print_error_msg("No original directory specified");
      if ((temp = fopen(argv[i], "r")) == NULL)
	print_error_msg("Can't read from directory file");
      else {
	fclose(temp);
	orig_directory = (char *) strdup(argv[i]);
      }
      break;

    default:
      print_error_msg("option not valid.");
      break;
    }
  }

/* initialization */

  if (orig_directory == NULL)
    orig_directory = (char *) strdup(DEFAULT_ORIG);
  create_output_file_name(out_directory);

/* processing */

  process_input_file();

/* termination */

  close_output_file();
  exit(0);
}
