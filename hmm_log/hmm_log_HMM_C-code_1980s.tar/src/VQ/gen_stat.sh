#!/bin/csh -f
#
#  build.sh
#
#  build a set of ascii files from a list
#
#  V 0.1
#  09/17/94
#
#  Darwei Kung
#

#
#  define where the data file sources and destinations
#

set eod_host	= tiffany
set eod_dir	= /dkung-tmp/telerobotics
set data_dir	= ~/expr/TR/ascii_data
set prog_dir	= ~/expr/src
set path	= ($path $prog_dir)
set bin_data	= /tmp/data.D.x
set sample_rate = 10
set ascii_data	= ~/varhmm/stdvq/obs.txt


#
#  This script can only be executed on eod host
#

if (`hostname` != $eod_host) then
  rsh $eod_host "cd varhmm/stdvq; gen_stat.sh"
  exit(0)
endif

#
# Make binas
#

echo making binas
setenv CC gcc
set path = ($path /share/bin /usr/ccs/bin)

if `arch` == "iris4d" then
  set path = ($path /usr/sbin)
  echo "Changing default C compiler to cc"
  setenv CC cc
else if ((`arch` == "sun4") && (`uname -r | awk -F"." '{print $1}'` == 5)) then
  set path = ($path /usr/ccs/bin)
endif

cd ${prog_dir}
make clean
make binas

if -e ${ascii_data} then
  rm ${ascii_data}
endif

start_process:

#
#  read in the line from data input
#

set in_str = $<
set in_len = `echo $in_str | awk '{print length}'`
if ($in_len < 3) then
  exit 0
endif

echo convert ${in_str}
set file_num    = `echo $in_str | awk '{print $1}'`
set file_date   = `echo $in_str | awk '{print $2}'`
set file_type   = `echo $in_str | awk '{print $3}'`

#
#  copy the data file from the eod host to local /tmp
#

cp ${eod_dir}/tape*/${file_date}/${file_num}.D.x ${bin_data}

#
#  convert the data file into ascii format
#

binas ${bin_data} ${sample_rate} >> ${ascii_data}

goto start_process

#

