% Function to add status for test files
% In file: *.vqin.testvq
% Out file: ascii file with status, *.vqtest.testvq
%
% Usage: type "addstatus_for_testvq"
%
function[] = addstatus_for_testvq();
% file id for different trials
file_id(1,:) = '16';
file_id(2,:) = '31';
file_id(3,:) = '32';
% status transition table
% for trial16
start_point(1,1) = 1;
start_point(1,2) = 16;
start_point(1,3) = 50;
start_point(1,4) = 63;
start_point(1,5) = 100;
start_point(1,6) = 103;
start_point(1,7) = 134;
start_point(1,8) = 147;
start_point(1,9) = 182;
start_point(1,10) = 217;
% for trial31
start_point(2,1) = 1;
start_point(2,2) = 17;
start_point(2,3) = 41;
start_point(2,4) = 60;
start_point(2,5) = 79;
start_point(2,6) = 96;
start_point(2,7) = 109;
start_point(2,8) = 126;
start_point(2,9) = 143;
start_point(2,10) = 169;
% for trial32
start_point(3,1) = 1;
start_point(3,2) = 12;
start_point(3,3) = 26;
start_point(3,4) = 48;
start_point(3,5) = 66;
start_point(3,6) = 83;
start_point(3,7) = 94;
start_point(3,8) = 111;
start_point(3,9) = 128;
start_point(3,10) = 169;
%
% Repeat for # of files (for ald files)
%
n=3;
for i=1:n,
clear status;
clear temp_cnvout;
load_file = ['ald' file_id(i,:) '.vqin.testvq']
out_file  = ['ald' file_id(i,:) '.vqtest.testvq']
load (load_file);
int_dataname = ['ald' file_id(i,:);];
int_dataname = eval(int_dataname);
% Create status
for k=0:8,
for j=start_point(i,k+1):start_point(i,k+2)-1,
status(j) = k;
end;
end;
% Make output data
in_size = size(int_dataname);
in_size = in_size(2)-2;
temp_cnvout = int_dataname(:,1);
for j=2:in_size+1,
temp_cnvout = [temp_cnvout int_dataname(:,j)];
end;
cnvout = [temp_cnvout status']; 
% File write 
write_data_size = size(cnvout)
fid = fopen(out_file, 'w');
for k = 1:start_point(i,10)-1,
fprintf(fid, '%6.2f %6.0f %6.0f\n', cnvout(k,:));
end; 
end; 
%
end;
%
% Repeat for # of files (for alv files)
%
n=3;
for i=1:n,
clear status;
clear temp_cnvout;
load_file = ['alv' file_id(i,:) '.vqin.testvq']
out_file  = ['alv' file_id(i,:) '.vqtest.testvq']
load (load_file);
int_dataname = ['alv' file_id(i,:);];
int_dataname = eval(int_dataname);
% Create status
for k=0:8,
for j=start_point(i,k+1):start_point(i,k+2)-1,
status(j) = k;
end;
end;
% Make output data
in_size = size(int_dataname);
in_size = in_size(2)-2;
temp_cnvout = int_dataname(:,1);
for j=2:in_size+1,
temp_cnvout = [temp_cnvout int_dataname(:,j)];
end;
cnvout = [temp_cnvout status'];
% File write
write_data_size = size(cnvout)
fid = fopen(out_file, 'w');
for k = 1:start_point(i,10)-1,
fprintf(fid, '%6.2f %6.0f %6.0f\n', cnvout(k,:));
end;
end;
%
end;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Special treatment for 3 digit file_id
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% file id for different trials
file_id3(1,:) = '111';
% status transition table
% for trial111
start_point3(1,1) = 1;
start_point3(1,2) = 3;
start_point3(1,3) = 7;
start_point3(1,4) = 9;
start_point3(1,5) = 13;
start_point3(1,6) = 14;
start_point3(1,7) = 17;
start_point3(1,8) = 19;
start_point3(1,9) = 22;
start_point3(1,10) = 27;
%
% Repeat for # of files (for ald files)
%
%n=1;
%for i=1:n,
%clear status;
%clear temp_cnvout;
%load_file = ['ald' file_id3(i,:) '.testfftvq']
%out_file  = ['ald' file_id3(i,:) '.fvqtest']
%load (load_file);
%int_dataname = ['ald' file_id3(i,:);];
%int_dataname = eval(int_dataname);
% Create status
%for k=0:8,
%for j=start_point3(i,k+1):start_point3(i,k+2)-1,
%status(j) = k;
%end;
%end;
% Make output data
%in_size = size(int_dataname);
%in_size = in_size(2)-2;
%temp_cnvout = int_dataname(:,1);
%for j=2:in_size+1,
%temp_cnvout = [temp_cnvout int_dataname(:,j)];
%end;
%cnvout = [temp_cnvout status'];
% File write
%write_data_size = size(cnvout)
%fid = fopen(out_file, 'w');
%for k = 1:start_point3(i,10)-1,
%if in_size == 8,
%fprintf(fid, '%6.2f %14.6f %14.6f %14.6f %14.6f %14.6f %14.6f %14.6f %14.6f %6.0f\n', cnvout(k,:)); 
%elseif in_size == 4,
%fprintf(fid, '%6.2f %14.6f %14.6f %14.6f %14.6f %6.0f\n', cnvout(k,:));
%end;
%end;
%
%end;
%
% Repeat for # of files (for alv files)
%
%n=1;
%for i=1:n,
%clear status;
%clear temp_cnvout;
%load_file = ['alv' file_id3(i,:) '.testfftvq']
%out_file  = ['alv' file_id3(i,:) '.fvqtest']
%load (load_file);
%int_dataname = ['alv' file_id3(i,:);];
%int_dataname = eval(int_dataname);
% Create status
%for k=0:8,
%for j=start_point3(i,k+1):start_point3(i,k+2)-1,
%status(j) = k;
%end;
%end;
% Make output data
%in_size = size(int_dataname);
%in_size = in_size(2)-2;
%temp_cnvout = int_dataname(:,1);
%for j=2:in_size+1,
%temp_cnvout = [temp_cnvout int_dataname(:,j)];
%end;
%cnvout = [temp_cnvout status'];
% File write
%write_data_size = size(cnvout)
%fid = fopen(out_file, 'w');
%for k = 1:start_point3(i,10)-1,
%if in_size == 8,
%fprintf(fid, '%6.2f %14.6f %14.6f %14.6f %14.6f %14.6f %14.6f %14.6f %14.6f %6.0f\n', cnvout(k,:)); 
%elseif in_size == 4,
%fprintf(fid, '%6.2f %14.6f %14.6f %14.6f %14.6f %6.0f\n', cnvout(k,:));
%end;
%end;
%
%end;

