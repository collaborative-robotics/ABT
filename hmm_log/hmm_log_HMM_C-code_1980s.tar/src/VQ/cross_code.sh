#!/bin/csh -fx
#  encode.sh
#
#  cross code the VQ data with different code books
#
#  V 1.0
#  10/30/94
#
#  Darwei Kung
#
#  Usage:
#
#  cross_code.sh <make>
#
#  task name is something like pnh_0.05 or pnh_0.1
#  Method is either 0, 1, or 2
#  Make is YES or NO for remaking everything.#  
#
#  Example:
#
#  cross_code.sh YES
#

#
#  define where the data file sources and destinations
#

set prog_dir	= ~/expr/src
set VQ_dir	= ~/expr/src/VQ
set temp_dir	= /tmp/dkung
set data_dir	= ~/expr/TR/ascii_data
set bench_dir	= ~/expr/TR/ascii_data/task
set vq_dir	= ~/expr/src/VQ/pnh_0
set path	= ($path $prog_dir $VQ_dir)
set curr_dir	= `pwd`

if ($1 == "") then
  set MAKE_PROG	= "YES"
else
  set MAKE_PROG = ${4}
endif

#
#  Build the VQ programs
#

if (${MAKE_PROG} == "YES") then
  cd ${VQ_dir}
  echo making VQ programs
  setenv CC gcc
  make clean
  set path = ($path /share/bin /usr/ccs/bin)

  if `arch` == "iris4d" then
    set path = ($path /usr/sbin)
    echo "Changing default C compiler to cc"
    setenv CC cc
  else if ((`arch` == "sun4")&&(`uname -r | awk -F"." '{print $1}'` == 5)) then
    set path = ($path /usr/ccs/bin)
  endif

  if ((`arch` == "sun4") && (`uname -r | awk -F"." '{print $1}'` == 4)) then
    make sunos
  endif

  if (`uname` == "Linux") then
    make sunos
  endif

  make all
endif

#
#  create a temp directory
#

if !(-d ${temp_dir}) then
  rm -rf ${temp_dir}
  mkdir ${temp_dir}
endif

#
#  create the binary files
#

foreach task (move extract insert tap)
  set text_file	= ${bench_dir}/${task}.txt
  set bin_file	= ${temp_dir}/${task}.bin
  set vq_file	= ${vq_dir}/${task}.vq
  atob -i ${text_file} -o ${bin_file} -u 1 2 3 4 5 6 -d 1
end

#
#  cross code the data samples with the VQ code books.
#

foreach base_task (move extract insert tap)
  set vq_file	= ${vq_dir}/${base_task}.vq
  foreach cross_task (move extract insert tap)
    set bin_file	= ${temp_dir}/${cross_task}.bin
    set out_file	= ${vq_dir}/${cross_task}_${base_task}.txt
    stdvqe3 -c ${vq_file} -i ${bin_file} -o ${out_file}    
  end
end

#