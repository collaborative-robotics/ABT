#!/bin/csh -f
#
#  vq_vel.sh
#
#  originally modified frome gnobs_VQ.sh
#
#  training the VQ with a set of ascii data
#
#  26/09/95
#
#  Hisato Takenaka
#
#  Usage:
#
#  vq_vel.sh 1_1_s <make> <code book name>
#
#  1 = duration
#  1 = 1 (only for 9 data of position data) 
#  s = code book size
#  <code book name> = file name for the code book, default is
#                     /tmp/dkung/codebook.vq
#  <make> = YES remake everything, NO don't remake (default is YES)
#

set sample_dir	= ~/peak5/thein_data/vqdata
set bench_dir	= ~/peak5/thein_data/vqdata
set prog_dir	= ~/darwei/expr/src
set VQ_dir	= ~/darwei/expr/src/VQ
set temp_dir	= /tmp/hisato
set path	= ($path $prog_dir $VQ_dir)
set temp_file	= ${temp_dir}/vq.tmp
set base_file	= ${temp_dir}/vq.bin
set VQ_default	= ${temp_dir}/codebook.vq
set VQ_default_size = 8
set curr_dir	= `pwd`

if ($1 == "") then
  exit(1)
endif

if ($2 == "") then
  set MAKE_PROG	= "YES"
else
  set MAKE_PROG = ${2}
endif

if ($3 == "") then
  set code_book = ${VQ_default}
else
  set code_book = ${3}
endif


#
#  Parse the VQ method
#

set VQ_u_type	= `echo ${1} | awk -F"_" '{print $1}'`
set VQ_d	= `echo ${1} | awk -F"_" '{print $2}'`
set VQ_size	= `echo ${1} | awk -F"_" '{print $3}'`
set VQ_len	= ${VQ_d}

#
#  translate the type into -u and -d options for atob
#

if (${VQ_u_type} == "1") then
  set VQ_u	= "1 2 3 4 5 6 7 8 9"
  @ VQ_len *= 9
# else if (${VQ_u_type} == "123") then
# set VQ_u	= "1 2 3"
#  @ VQ_len *= 3
# else if (${VQ_u_type} == "123456") then
# set VQ_u	= "1 2 3 4 5 6"
# @ VQ_len *= 6
else
  echo "VQ format parameter is incorrect"
  exit(1)
endif

#
#  trainslate into the -f option for stdvq
#

if (${VQ_size} == "") then
  set VQ_size	= ${VQ_default_size}
endif

#
#  Build the VQ programs
#

if (${MAKE_PROG} == "YES") then
  cd ${VQ_dir}
  echo making VQ programs
  setenv CC gcc
  make clean
  set path = ($path /share/bin /usr/ccs/bin)

  if `arch` == "iris4d" then
    set path = ($path /usr/sbin)
    echo "Changing default C compiler to cc"
    setenv CC cc
  else if ((`arch` == "sun4")&&(`uname -r | awk -F"." '{print $1}'` == 5)) then
    set path = ($path /usr/ccs/bin)
  endif

  if ((`arch` == "sun4") && (`uname -r | awk -F"." '{print $1}'` == 4)) then
    make sunos
  endif

  make all

endif

#
#  create the training list
#

if !(-d ${temp_dir}) then
  rm -rf ${temp_dir}
  mkdir ${temp_dir}
endif
touch ${base_file}

cd ${sample_dir}
set data_set	= (alv1*.vqtest alv3*.vqtest)

#
#  create the VQ training base
#

foreach data_file (${data_set})
  atobin -i ${data_file} -o ${temp_file} -u ${VQ_u} -d ${VQ_d}
  cat ${temp_file} >> ${base_file}
  mv ${temp_file} ${temp_dir}/${data_file}.bin
  echo atobing
end

stdvq -t ${base_file} -c ${code_book} -d ${VQ_len} -f ${VQ_size}
 echo finish stdvq
#
#  once the code book is generated, go back and recreate the data set
#  with the VQ
#

cd ${bench_dir}
set data_set	= (alv1*.vqtest alv3*.vqtest)
foreach data_file (${data_set})
  stdvqe2 -c ${code_book} -i ${temp_dir}/${data_file}.bin -o ${temp_file}
  echo stdvqe2 end
  combine_file -f -i ${data_file} ${temp_file} | \
	 awk '{print $1"\t"$12"\t"$11}' > ${bench_dir}/${data_file}.vqout
  echo combine end
end
#
