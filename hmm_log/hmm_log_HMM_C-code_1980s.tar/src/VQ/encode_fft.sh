#!/bin/csh -f
#  encode_fft.sh
#
#  encode the ascii data file into a VQ file
#
#  08/03/95
#
#  Hisato Takenaka
#
#  Usage:
#
#  encode.sh Task_Name VQ_Method <data file name> <make>
#
#  task name is something like pnh_0.05 or pnh_0.1
#  VQ_Method is 1_4_16 as described in genobs_***VQ.sh
#  Make is YES or NO for remaking everything.#  
#  data file name   = data file to use NO PATH!
#  <make> = YES remake everything, NO don't remake (default is YES)
#
#  Example:
#
#  encode.sh pnh_0.1 1_3_16 ~dkung/expr/TR/ascii_data/orig/test.dat
#
#  means using data fields 1 ~ 9, and use time duration of 3.
#  and encode the file test.dat.
#

#
#  define where the data file sources and destinations
#

set prog_dir	= ~/darwei/expr/src
set VQ_dir	= ~/darwei/expr/src/VQ
set temp_dir	= /tmp/hisato
set data_dir	= ~/peak5/thein_data
set bench_dir	= ~/peak5/thein_data
set hmm_dir	= ~/darwei/expr/TR/hmm
set path	= ($path $prog_dir $VQ_dir)
set temp_file	= ${temp_dir}/vq.tmp
set base_file	= ${temp_dir}/vq.bin
set VQ_default_size = 8
set VQ_codebook	= ${hmm_dir}/DHMM.${1}.${2}.vq
set curr_dir	= `pwd`

if ($1 == "") then
  exit(1)
endif

if ($2 == "") then
  exit(1)
endif

if ($3 == "") then
  exit(1)
endif

if ($4 == "") then
  set MAKE_PROG	= "YES"
else
  set MAKE_PROG = ${4}
endif

#
#  Parse the VQ method
#

set VQ_u_type	= `echo ${2} | awk -F"_" '{print $1}'`
set VQ_d	= `echo ${2} | awk -F"_" '{print $2}'`
set VQ_size	= `echo ${2} | awk -F"_" '{print $3}'`
set VQ_len	= ${VQ_d}

#
#  translate the type into -u and -d options for atob
#
#
if (${VQ_u_type} == "1") then
  set VQ_u      = "1 2 3 4 5 6 7 8"
  @ VQ_len *= 8
# else if (${VQ_u_type} == "123") then
# set VQ_u      = "1 2 3"
#  @ VQ_len *= 3
# else if (${VQ_u_type} == "123456") then
# set VQ_u      = "1 2 3 4 5 6"
# @ VQ_len *= 6
else
  echo "VQ format parameter is incorrect"
  exit(1)
endif

#  trainslate into the -f option for stdvq
#

if (${VQ_size} == "") then
  set VQ_size	= ${VQ_default_size}
endif

#
#  Build the VQ programs
#

if (${MAKE_PROG} == "YES") then
  cd ${VQ_dir}
  echo making VQ programs
  setenv CC gcc
  make clean
  set path = ($path /share/bin /usr/ccs/bin)

  if `arch` == "iris4d" then
    set path = ($path /usr/sbin)
    echo "Changing default C compiler to cc"
    setenv CC cc
  else if ((`arch` == "sun4")&&(`uname -r | awk -F"." '{print $1}'` == 5)) then
    set path = ($path /usr/ccs/bin)
  endif

  if ((`arch` == "sun4") && (`uname -r | awk -F"." '{print $1}'` == 4)) then
    make sunos
  endif

  if (`uname` == "Linux") then
    make sunos
  endif

  make all
endif

#
#  decode the sample data and store it in the temp dir
#

if !(-d ${temp_dir}) then
  rm -rf ${temp_dir}
  mkdir ${temp_dir}
endif

#
#  once the code book is generated, go back and recreate the data set
#  with the VQ
#

atobfft -i ${bench_dir}/${3} -o ${temp_file}.bin -u ${VQ_u} -d ${VQ_d}
stdvqe2 -c ${VQ_codebook} -i ${temp_file}.bin -o ${temp_file}
combine_file -i ${data_dir}/${3} ${temp_file} | \
  awk '{print $1"\t"$11"\t"$10}' > ${temp_dir}/${3}.vq

#
