#!/bin/csh -f
#  gen_codebook.sh
#
#  generating code books for each task
#
#  V 1.0
#  11/14/94
#
#  Darwei Kung
#
#  Usage:
#
#  gen_codebooks.sh task_name compile
#
#  Example:
#
#  gen_codebook.sh pnh_0.1 yes
#

#
#  define where the data file sources and destinations
#

set data_dir	= ~/expr/TR/ascii_data/task
set temp_dir	= /tmp/dkung
set prog_dir	= ~/expr/src
set VQ_dir	= ~/expr/src/VQ
set path	= ($path $prog_dir $VQ_dir)
set temp_ext	= tmp
set bin_ext	= bin
set VQ_ext	= vq
set out_ext	= out
set use_col	= "1 2 3 4 5 6"
set duration	= 1
set vec_dim	= 6
set curr_dir	= `pwd`
if ($1 == "") then
  exit(1)
endif

if ($2 == "") then
  set search_method = 0
else if ($2 == "0") then
  set search_method = 0
else if ($2 == "1") then
  set search_method = 1
else if ($2 == "2") then
  set search_method = 2
else
  echo $2 is not a valid search type
  exit(2)
endif

if ($3 == "NO") then
  set MAKE_PROG	= "NO"
else
  set MAKE_PROG = "YES"
endif

#
#  Build the VQ programs
#

if (${MAKE_PROG} == "YES") then
  cd ${VQ_dir}
  echo making VQ programs
  setenv CC gcc
  make clean
  set path = ($path /share/bin /usr/ccs/bin)

  if `arch` == "iris4d" then
    set path = ($path /usr/sbin)
    echo "Changing default C compiler to cc"
    setenv CC cc
  else if ((`arch` == "sun4")&&(`uname -r | awk -F"." '{print $1}'` == 5)) then
    set path = ($path /usr/ccs/bin)
  endif

  if ((`arch` == "sun4") && (`uname -r | awk -F"." '{print $1}'` == 4)) then
    make sunos
  endif

  make all

endif

#
#  make the results directory
#

set result_dir	= ${VQ_dir}/${1}_${search_method}
if(!(-d ${result_dir})) then
  if (-e ${result_dir}) then
    rm -f ${result_dir}
  endif

  mkdir ${result_dir}
endif

#
#  create the training list
#

if (!(-d ${temp_dir})) then
  rm -rf ${temp_dir}
  mkdir ${temp_dir}
endif

rm -f ${temp_dir}/*

cd ${data_dir}
set data_set	= (*.txt)

#
#  create the VQ code books
#

foreach data_file (${data_set})
  set samp_cnt	= `wc -l ${data_file}`
  @ samp_cnt /= 8
  if (${samp_cnt} > 256) then
    set samp_cnt = 256
  endif
  set file_name = `echo ${data_file} | awk -F"." '{print $1}'`
  set temp_file	= ${temp_dir}/${file_name}.${temp_ext}
  set bin_file	= ${temp_dir}/${file_name}.${bin_ext}
  set VQ_file	= ${temp_dir}/${file_name}.${VQ_ext}
  cp ${data_file} ${temp_file}
  atob -i ${temp_file} -o ${bin_file} -u ${use_col} -d ${duration}
  stdvq -t ${bin_file} -c ${VQ_file} -d ${vec_dim} -f ${samp_cnt} -s ${search_method}
end

#
#  once the code book is generated, go back and recreate the data set
#  with the VQ
#

foreach data_file (${data_set})
  set file_name = `echo ${data_file} | awk -F"." '{print $1}'`
  set VQ_file	= ${temp_dir}/${file_name}.${VQ_ext}
  set out_file	= ${temp_dir}/${file_name}.${out_ext}
  if (-e ${out_file}) then
    rm -f ${out_file}
  endif
  touch ${out_file}
  foreach trial_file (${temp_dir}/*.${bin_ext})
    stdvqe -c ${VQ_file} -i ${trial_file} -s ${search_method} >> ${out_file}
  end

  mv ${out_file} ${result_dir}
end

mv ${temp_dir}/*.${VQ_ext} ${result_dir}
#