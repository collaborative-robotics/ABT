/*
**  combine_file.c
**
**  combines 2 columner files into one.
**
**  V 0.1
**  10/09/94
**
**  Darwei Kung
**
**  This program combines multiple columner data files into one file.
**  If the length of each files doesn't match, error will return.  However,
**  this can be overwritten on the command line.
**  
**  Options
**    -f  forced, if the length of different files don't match, fill
**    -c  column seperator, default is tab
**    -o  output file.  If none is specified, than stdout is used instead.
**    -i  input file names.
**    -t  forced truncation
*/

#include <stdio.h>

/* define program constants and defaults */

#define MAX_LEN 1024

static FILE *infile1 = NULL;
static FILE *infile2 = NULL;
static FILE *outfile;
static FILE *tempout;
static int  force_out = 0;
static char empty_1[] = "";
static char empty_2[] = "";
static char sep[10] = "\t";

/* print error message */

int print_error_msg(char *error_msg)
{
  if (error_msg != NULL)
    fprintf(stderr, "%s\n", error_msg);
  fprintf(stderr, "Please use the following format:\n");
  fprintf(stderr, "combine -c sep -o out_file -u [list] -f -i [list]\n -t");
  exit(1);
}

/* Print help for command line options */

int print_help_msg()
{
  fprintf(stderr, "Options\n");
  fprintf(stderr, "-o  output file name.  if none is given, stdout is used\n");
  fprintf(stderr, "-i  output file name.  if none is given, stdout is used\n");
  fprintf(stderr, "-c  seperatione string \n");
  fprintf(stderr, "-f  forced output.\n");
  fprintf(stderr, "-t  forced trunction.\n");
  exit(0);
}

/* generate combined output to a temp file */

int combine_file()
{
  char string1[MAX_LEN];
  char string2[MAX_LEN];
  int flen1 = 0;
  int flen2 = 0;
  char *tempfile;
  int eof_1 = 0;
  int eof_2 = 0;
  char in_char[MAX_LEN];
  int char_cnt;

/* open temporary files */

  tempfile = tmpnam(NULL);
  tempout = fopen(tempfile, "w");

/* do this until both files are read to the end */

  for(;;) {

/* read the string from file one */

    if (fgets(string1, MAX_LEN, infile1) == NULL) {
      strcpy(string1, empty_1);
      eof_1 = 1;
    }
    else {
      flen1++;
      string1[strlen(string1) - 1] = 0;
    }
   
    if (fgets(string2, MAX_LEN, infile2) == NULL) {
      strcpy(string2, empty_2);
      eof_2 = 1;
    }
    else {
      flen2++;
      string2[strlen(string2) - 1] = 0;
    }
/* if forced trunction, then one of them done is enough */

    if ((force_out < 0) && (eof_1 || eof_2)) {
      eof_1 = 1;
      eof_2 = 1;
    }

/* done, copy file to output stream */

    if (eof_1 && eof_2) {
      fclose(tempout);
      fclose(infile1);
      fclose(infile2);
      tempout = fopen(tempfile, "r");
      while(!feof(tempout)) {
	char_cnt = fread(&in_char, sizeof(char), MAX_LEN, tempout);
	char_cnt = fwrite(&in_char, sizeof(char), char_cnt, outfile);
      }
      fclose(outfile);
      exit(0);
    }

/* otherwise, without forced out, there is a problem */

    if ((eof_1 || eof_2) && (!force_out)) {
      fclose(tempout);
      fprintf(stderr,"file 1 - %i, file 2 %i\n", flen1, flen2);
      print_error_msg("File lengths don't match!");
    }

/* print string 1, then print string 2 */

    fprintf(tempout, "%s%s%s\n", string1, sep, string2);
  }
}

void main(int argc, char *argv[])
{
  int i;

  outfile = stdout;

  if (argc == 1) {
    print_help_msg();
    exit(1);
  }

/* command line process */

  for (i = 1; i < argc; i++) {
    if (argv[i][0] != '-')
      print_error_msg("Please check your command line format");

    switch (argv[i][1]) {
    case 'i' :
      if ((infile1 != NULL) || (infile2 != NULL))
	print_error_msg("duplicate input file names.");

      if (++i == argc) print_error_msg("No 1st input file specified");
      if ((infile1 = fopen(argv[i], "r")) == NULL)
	print_error_msg("Can't open input file. 1");

      if (++i == argc) print_error_msg("No 2nd input file specified");
      if ((infile2 = fopen(argv[i], "r")) == NULL)
	print_error_msg("Can't open input file 2.");

      break;

    case 'o' :
      if (outfile != stdout)
	print_error_msg("duplicate output file names.");
      if (++i == argc) print_error_msg("No output file specified");
      if ((outfile = fopen(argv[i], "w")) == NULL)
	print_error_msg("Can't open output file.");
      break;

    case 'f' :
      force_out = 1;
      break;

    case 't' :
      force_out = -1;
      break;
	    
    case 'c' :
      if ((++i == argc) || argv[i][0] == '-')
	print_error_msg("c option needs a string!");
      strcpy(sep, argv[i]);
      break;

    default:
      print_error_msg("option not valid.");
      break;
    }
  }

  combine_file();
  exit(0);
}
