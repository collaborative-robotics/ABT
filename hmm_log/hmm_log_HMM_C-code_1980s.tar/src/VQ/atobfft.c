/*
**  atobfft.c
**
**  Conversion program to convert the ascii data into a stream of binary data
**
**  27/07/95
**
**  Hisato Takenaka
**
**  This program converts the ascii data into binary data from the 
**  violin bowing experiment into a steam of binary data in double format.
**  The data from "peak5" should be modified so that ","s are removed.
**  The double format file is only temporary.  It will be used by Vector
**  Quantization trainer and decoder.  The resulting file will be machine
**  dependant.
**
**  Options
**    -i         input file name.  if none is given, stdin is used
**    -o         output file name.  if none is given, stdout is used
**    -u [list]  use fields in the list.
**    -x [list]  exclude the fields from the list.
**    -d         temporal duration
**
*/

#include <stdio.h>

/* define program constants and defaults */

#define vector_length 10
#define MAX_DURATION  30

static int p_field[vector_length] = {0,0,0,0,0,0,0,0,0,0};
static FILE *infile;
static FILE *outfile;
static int duration = 1;

/* print error message */

int print_error_msg(char *error_msg)
{
  if (error_msg != NULL)
    fprintf(stderr, "%s\n", error_msg);
  fprintf(stderr, "Please use the following format:\n");
  fprintf(stderr, "atobin -i in_file -o out_file -u [list]\n");
  exit(1);
}

/* Print help for command line options */

int print_help_msg()
{
  fprintf(stderr, "Options\n");
  fprintf(stderr, "-i  input file name.  if none is given, stdin is used\n");
  fprintf(stderr, "-o  output file name.  if none is given, stdout is used\n");
  fprintf(stderr, "-u  [list]  use fields in the list.\n");
  fprintf(stderr, "-x  [list]  exclude the fields from the list.\n");
  fprintf(stderr, "-d  Temporal duration\n");
}


/* generate binary output */

int gen_bin()
{
  double num[vector_length][MAX_DURATION];
  int i,j;

  for(i = 0; i < vector_length; i++)
    for(j = 0; j < MAX_DURATION; j++)
      num[i][j] = 0;

  fprintf(stderr, "Adding Entries: ");
  for (i = 0; i < vector_length; i++)
    if (p_field[i]) fprintf(stderr, "%i ", i);
  fprintf(stderr, "\n");
  fprintf(stderr, "Temporal Duration: %i\n", duration);

  while (!feof(infile)) {
    for (i = 0; i < vector_length; i++) {
      if (fscanf(infile, "%lf", &(num[i][0])) == EOF)
	exit(0);
    }

    for (j = duration - 1; j >= 0; j--) {
      for (i = 0; i < vector_length; i++) {
	if (p_field[i])
	  fwrite(&(num[i][j]), sizeof(double), 1, outfile);
/*	  fprintf(outfile, " %lf ", num[i][j]);		*/
      }
    }

    for(j = duration - 1; j > 0; j--)
      for(i = 0; i < vector_length; i++)
	num[i][j] = num[i][j - 1];
    
  }
}
    
  
void main(int argc, char *argv[])
{
  int i, j, d;
  int u_ok;

  infile = stdin;
  outfile = stdout;

  if (argc == 1) {
    print_help_msg();
    exit(1);
  }

/* command line process */

  for (i = 1; i < argc; i++) {
    u_ok = 1;
    if (argv[i][0] != '-')
      print_error_msg("Please check your command line format");

    switch (argv[i][1]) {
    case 'i' :
      if (infile != stdin)
	print_error_msg("duplicate input file names.");
      if (++i == argc) print_error_msg("No input file specified");
      if ((infile = fopen(argv[i], "r")) == NULL)
	print_error_msg("Can't open input file.");
      break;

    case 'o' :
      if (outfile != stdout)
	print_error_msg("duplicate output file names.");
      if (++i == argc) print_error_msg("No output file specified");
      if ((outfile = fopen(argv[i], "w")) == NULL)
	print_error_msg("Can't open output file.");
      break;

    case 'u' :
      while (u_ok) {
	if (++i == argc)
	  u_ok = 0;
	else {
	  if (argv[i][0] != '-') {
	    j = atoi(argv[i]);
	    if ((j > (vector_length - 1)) || (j < 0))
	      print_error_msg("field number out of range");
	    p_field[j] = 1;
	  }
	  else {
	    --i;
	    u_ok = 0;
	  }
	}
      }
      break;
	    
    case 'x' :
      while (u_ok) {
	if (++i == argc)
	  u_ok = 0;
	else {
	  if (argv[i][0] != '-') {
	    j = atoi(argv[i]);
	    if ((j > (vector_length - 1)) || (j < 0))
	      print_error_msg("field number out of range");
	    p_field[j] = 0;
	  }
	  else {
	    --i;
	    u_ok = 0;
	  }
	}
      }
      break;

    case 'd':
      d = atoi(argv[++i]);
      duration = ((d > 0) && (d < MAX_DURATION)) ? d : duration;
      break;

    default:
      print_error_msg("option not valid.");
      break;
    }
  }

  gen_bin();
  fclose(infile);
  fclose(outfile);

}
