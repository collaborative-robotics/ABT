#!/bin/csh -f
#  genobs_VQ.sh
#
#  training the VQ with a set of ascii data
#
#  V 1.0
#  10/30/94
#
#  Darwei Kung
#
#  Usage:
#
#  genobs_VQ.sh u_d_s <code book name> <make>
#
#  d = duration
#  u = 1 123 123456
#  s = code book size
#  <code book name> = file name for the code book, default is
#                     /tmp/dkung/codebook.vq
#  <make> = YES remake everything, NO don't remake (default is YES)
#
#  Example:
#
#  train_VQ.sh 123_3_16
#
#  means using data fields 1, 2, and 3, and use time duration of 3.
#

#
#  define where the data file sources and destinations
#

set data_dir	= ~/expr/TR/bw_data
set sample_dir	= ~/expr/TR/ascii_data/orig
set bench_dir	= ~/expr/TR/ascii_data
set prog_dir	= ~/expr/src
set VQ_dir	= ~/expr/src/VQ
set temp_dir	= /tmp/dkung
set path	= ($path $prog_dir $VQ_dir)
set temp_file	= ${temp_dir}/vq.tmp
set base_file	= ${temp_dir}/vq.bin
set VQ_default	= ${temp_dir}/codebook.vq
set VQ_default_size = 8
set curr_dir	= `pwd`

if ($1 == "") then
  exit(1)
endif

if ($2 == "") then
  set code_book = ${VQ_default}
else
  set code_book = ${2}
endif

if ($3 == "") then
  set MAKE_PROG	= "YES"
else
  set MAKE_PROG = ${3}
endif

#
#  Parse the VQ method
#

set VQ_u_type	= `echo ${1} | awk -F"_" '{print $1}'`
set VQ_d	= `echo ${1} | awk -F"_" '{print $2}'`
set VQ_size	= `echo ${1} | awk -F"_" '{print $3}'`
set VQ_len	= ${VQ_d}

#
#  translate the type into -u and -d options for atob
#

if (${VQ_u_type} == "1") then
  set VQ_u	= "1"
  @ VQ_len *= 1
else if (${VQ_u_type} == "123") then
  set VQ_u	= "1 2 3"
  @ VQ_len *= 3
else if (${VQ_u_type} == "123456") then
  set VQ_u	= "1 2 3 4 5 6"
  @ VQ_len *= 6
else
  echo "VQ format parameter is incorrect"
  exit(1)
endif

#
#  trainslate into the -f option for stdvq
#

if (${VQ_size} == "") then
  set VQ_size	= ${VQ_default_size}
endif

#
#  Build the VQ programs
#

if (${MAKE_PROG} == "YES") then
  cd ${VQ_dir}
  echo making VQ programs
  setenv CC gcc
  make clean
  set path = ($path /share/bin /usr/ccs/bin)

  if `arch` == "iris4d" then
    set path = ($path /usr/sbin)
    echo "Changing default C compiler to cc"
    setenv CC cc
  else if ((`arch` == "sun4")&&(`uname -r | awk -F"." '{print $1}'` == 5)) then
    set path = ($path /usr/ccs/bin)
  endif

  if ((`arch` == "sun4") && (`uname -r | awk -F"." '{print $1}'` == 4)) then
    make sunos
  endif

  make all

endif

#
#  create the training list
#

if !(-d ${temp_dir}) then
  rm -rf ${temp_dir}
  mkdir ${temp_dir}
endif
touch ${base_file}

cd ${sample_dir}
set data_set	= (train_*.txt)

#
#  create the VQ training base
#

foreach data_file (${data_set})
  atob -i ${data_file} -o ${temp_file} -u ${VQ_u} -d ${VQ_d}
  cat ${temp_file} >> ${base_file}
  mv ${temp_file} ${temp_dir}/${data_file}.bin
end

stdvq -t ${base_file} -c ${code_book} -d ${VQ_len} -f ${VQ_size}

#
#  once the code book is generated, go back and recreate the data set
#  with the VQ
#

cd ${bench_dir}
set data_set	= (train_*.txt)
foreach data_file (${data_set})
  stdvqe2 -c ${code_book} -i ${temp_dir}/${data_file}.bin -o ${temp_file}
  combine_file -i ${data_file} ${temp_file} | \
	 awk '{print $1"\t"$4"\t"$3}' > ${temp_dir}/${data_file}.vq
end
#