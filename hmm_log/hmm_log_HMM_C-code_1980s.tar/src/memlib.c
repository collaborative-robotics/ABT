/*  memlib.c
**
**  Memory Management Functions
**
**  V 0.1
**  12/01/93
**
**  Darwei Kung
**
**
**  This code includes the memory management functions
**
*/

#include <stdlib.h>             /* malloc, calloc, abort */
#include <memory.h>             /* memset */
#include <stdio.h>              /* fprintf */
#include <malloc.h>

/*
**
**  safe memory allocation.  Will not allow NULL returned request
**
*/

void *safe_malloc(size_t size)
{
  char *new_ptr;

  if ((new_ptr = (char *) malloc(size)) == NULL) {
    fprintf(stderr,
	    "malloc Pointer Allocation failed.  Requested Size was %i.\n",
	    size);
    abort();
  }
  else {
    memset(new_ptr, 0, size);
  }

  return(new_ptr);
}

/*
**
**  Safte calloc, will not allow NULL return
**
*/

void *safe_calloc(size_t number, size_t size)
{
  char *new_ptr;

  if ((new_ptr = safe_malloc(number * size)) == NULL) {
    fprintf(stderr,
	    "calloc Pointer Allocation failed.  Requested Number was %i,\n",
	    number);
    fprintf(stderr,
	    "and the size of each object is %i\n",
	    size);
    abort();
  }

  memset(new_ptr, 0, number * size);
  return(new_ptr);
}

/*
** NAME
**	alloc2d -- dynamically allocate a 2-d array
**      writen by Steve Venema
**
** SYNOPSIS
**	(char **)alloc2d(nrows, ncols, elsize)
**	
** DESCRIPTION
**	Dynamically allocates (using malloc(2)) a 2-d array.  This
**	really involves the allocation of two arrays, an array to
**	contain the actual data and a array to contain pointers to
**	the rows.
**
** ARGUMENTS
**	unsigned	nrows		number of rows in matrix  
**	unsigned	ncols		number of columns in matrix
**	unsigned	elsize		number of bytes per element
**
** RETURN VALUE
**	Pointer to new array or NULL for failure
**
** RESTRICTIONS
**
** FUTURE DIRECTIONS
**
** BUGS
*/

void **safe_alloc2d(size_t nrows, size_t ncols, size_t elsize)
	
/* nrows : number of rows in matrix	*/
/* ncols : number of columns in matrix	*/
/* elsize : number of bytes per element	*/

{
  void  **matrix;	/* ptr. ret. to calling routine	*/
  char  *array_ptr;	/* pointer to allocated matrix	*/
  int   a;		/* temp variable		*/
  long  size		/* premultiplication for speed	*/
    = ncols * elsize;

/* allocate a vector for all the elements */

  array_ptr = (char *) safe_malloc(nrows * ncols * elsize);
  memset(array_ptr, 0, nrows * ncols * elsize);

/* allocate a vector of row pointers */

  matrix = (void **) safe_malloc(nrows * sizeof(void *));


/* fill in row pointer array */

  for (a = 0; a < nrows; a++, matrix++) {
      *matrix = (void *) array_ptr; /* matrix[a] = -> row (a)	*/
      array_ptr += size;	/* increment -> next line	*/
    }
  matrix -= nrows;		/* back to beginning of vextor	*/

#ifdef DEBUG
	fprintf(stderr, "alloc2d:\n");
	for (a = 0; a < nrows; a++) {
	  fprintf(stderr, "matrix[%d] (&=%lx) = %lx\n",
		  a, &matrix[a], matrix[a]);
	}
#endif

  return(matrix);			/* returns -> to beg. of matrix	*/
}

/* free the two d matrix */

extern void free2d(void **matrix)
{
  free(matrix[0]);
  free(matrix);
}


/*
** NAME
**	alloc3d -- dynamically allocate a 2-d array
**      writen by Steve Venema
**
** SYNOPSIS
**	(char **)alloc2d(nrows, ncols, elsize)
**	
** DESCRIPTION
**	Dynamically allocates (using malloc(2)) a 2-d array.  This
**	really involves the allocation of two arrays, an array to
**	contain the actual data and a array to contain pointers to
**	the rows.
**
** ARGUMENTS
**	unsigned	nrows		number of rows in matrix  
**	unsigned	ncols		number of columns in matrix
**	unsigned	elsize		number of bytes per element
**
** RETURN VALUE
**	Pointer to new array or NULL for failure
**
** RESTRICTIONS
**
** FUTURE DIRECTIONS
**
** BUGS
*/

void ***safe_alloc3d(size_t ndepth, size_t nrows, size_t ncols, size_t elsize)
	
/* nrows : number of rows in matrix	*/
/* ncols : number of columns in matrix	*/
/* ndepth : number of depth in matrix   */
/* elsize : number of bytes per element	*/

{
  void ***matrix;          /* ptr. ret. to calling routine	*/
  void **matrix2d;         /* pointer to each two dimensional array */
  char *array_ptr;         /* pointer to allocated matrix	*/
  int i,j;                 /* temp variable		*/
  long size                /* premultiplication for speed	*/
    = ncols * elsize;
  long size_2 = nrows * size;

/* allocate a vector for all the elements */

  array_ptr = (char *) safe_malloc(ndepth * size_2);

/* allocate a vector of matrix pointers */

  matrix = (void ***) safe_alloc2d(ndepth,  nrows, sizeof(void *));

/* fill in row pointer array */

  for(i = 0; i < ndepth; i++)
    for(j = 0; j < nrows; j++) {
      matrix[i][j] = (void *) array_ptr;
      array_ptr += size;
    }

  
#ifdef DEBUG
	fprintf(stderr, "alloc3d:\n");
	for (i = 0; i < ndepth; i++) {
	  for (j = 0; j < nrows; j++) {
	    fprintf(stderr, "matrix[%d][%d] (&=%lx) = %lx\n",
		    i, j, &matrix[i][j], matrix[i][j]);
	  }
	  fprintf(stderr, "\n");
	}
#endif

  return(matrix);			/* returns -> to beg. of matrix	*/
}

/* free the 3d stuff */

extern void free3d(void ***matrix)
{
  free2d(matrix[0]);
  free(matrix);
}
