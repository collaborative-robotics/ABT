#include <stdio.h>
#include <ctype.h>
#include "statlib.h"
#include "memlib.h"

int main(int argc, char **argv)
{
  int fail_save, i, j, k;
  int seed;
  float *test_ptr;
  double **test_array_ptr;
  double rv;

/* testing statlib */

  printf("square x = 5, y = %f\n", sqr(5.0));
  printf("Gaussian Distribution:\n");
  printf("x = 5, mu = 2, sigma = 2.5, y = %f\n", gauss_dis(5.0, 2.0, 2.5));
  printf("Gamma Distribution:\n");
  printf("x = 5, alpha  = 2, beta = 2.5 y = %f\n", gamma_dis(5.0, 2.0, 2.5));
  printf("Uniform Distribution:\n");
  printf("x = 5, a = 2, b = 2.5, y = %f\n", uniform_dis(5, 2, 2.5));

  for (k = 0; k < 3; k++) {
    seed_rand(rand());
    printf("uniform random variables between -1 and 1 (20 of them)\n");
    for (i = 0; i < 4; i++) {
      for (j = 0; j < 5; j++) {
	rv = uniform_rand(-1, 1);
	printf("%7.4f  ", rv);
      }
    printf("\n");
    }

    printf("gaussian random variables of mean 0 and dev 1 (20 of them)\n");
    for (i = 0; i < 4; i++) {
      for (j = 0; j < 5; j++) {
	rv = gauss_rand(0, 1);
	printf("%7.4f  ", rv);
      }
      printf("\n");
    }

    printf("poisson random variables of mean 5 (20 of them)\n");
    for (i = 0; i < 4; i++) {
      for (j = 0; j < 5; j++) {
	rv = poisson_rand(5);
	printf("%7.4f  ", rv);
      }
      printf("\n");
    }
  }

/* testing memlib */

  if (argc > 1) {
    fail_save = toupper(argv[1][0]);
    switch(fail_save) {
    case 'C' :
      printf("Overloading calloc.\n");
      safe_calloc(1000000, 1000000);
      break;
    case 'M' :
      printf("Overloading malloc.\n");
      safe_malloc((size_t) 10000*100000);
      break;
    default:
      test_ptr = (float *) safe_calloc(100,100);
      printf("saft calloc, address is %p\n", test_ptr);
      free(test_ptr);
      test_ptr = (float *) safe_malloc(100);
      printf("safe malloc, address is %p\n", test_ptr);
      free(test_ptr);
      test_array_ptr = (double **) safe_alloc2d(10, 10, sizeof(double));
      printf("safe alloc2d, address is %p\n", test_ptr);
      free2d((void **) test_array_ptr);
      test_array_ptr = (double **) safe_alloc3d(10, 10, 10, sizeof(double));
      printf("safe alloc3d, address is %p\n", test_ptr);
      free3d((void ***) test_array_ptr);
    }
  }
  else {
    test_ptr = (float *) safe_calloc(100,100);
    printf("saft calloc, address is %p\n", test_ptr);
    free(test_ptr);
    test_ptr = (float *) safe_malloc(100);
    printf("safe malloc, address is %p\n", test_ptr);
    free(test_ptr);
    test_array_ptr = (double **) safe_alloc2d(10, 10, sizeof(double));
    printf("safe alloc2d, address is %p\n", test_ptr);
    free2d((void **) test_array_ptr);
    test_array_ptr = (double **) safe_alloc3d(10, 10, 10, sizeof(double));
    printf("safe alloc3d, address is %p\n", test_ptr);
    free3d((void ***) test_array_ptr);
  }
  return(0);
}
