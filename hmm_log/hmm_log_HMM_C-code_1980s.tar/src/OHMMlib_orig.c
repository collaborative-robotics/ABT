/*
**  OHMMlib.c
**
**  HMM function library for Discrete HMM (OHMM)
**
**  V 0.2
**  02/01/94
**
**  Darwei Kung
**
**  This code provides all the subroutines for performing HMM calculations.
**  Most of the code is based on the code written by Paul Lee for JPL.
**
**  The types defined in HMMtype.h is used to provide templates for different
**  HMM's.  The functions provided in this file include the viterbi and the
**  Baum_Welch programs.  The data i/o parts of the original HMM c programs
**  are taken out, to make the code easier to read.
**
**  The discrete model assumes the following observation set:
** 
**  OSet O is a set of observations
**  O.o[i] should always be type cased into an integer
**  b is a 2-d array with dimentions T X M
**
*/

#include <math.h>              /* all the math functions */
#include <stdio.h>             /* definition for NULL */
#include <stdlib.h>            /* file open, close, rename */
#include <string.h>            /* strcat, strdup, strcpy */
#include <malloc.h>            /* free() */
#include "HMMtype.h"           /* type templates */
#include "HMMconst.h"          /* constant declartions */
#include "statlib.h"           /* gauss_dis(), gamma_dis() */
#include "memlib.h"            /* safe_malloc(), safe_calloc() */
#define copysign(x, y)  (y > 0.0 ? fabs(x) : -fabs(-x))

/* internal variables, only visible to OHMMlib.c routines */

static int OHMM_window_size  = DEF_W_SIZE;
static int OHMM_merge_detect = DO_MERGE;
static int OHMM_cursor       = 0;
static int OHMM_merge_depth  = 0;

/*
** the b(O) and log(b(O)) functions
** find the probability of observation at time t and state j.
*/

double OHMM_b(OHMM_p *hmm, OSet *O, int t, int j)
{
  double b_mean, b_std;

  b_mean = hmm->b[j].p[0];
  b_std  = hmm->b[j].p[1];
  return(gauss_dis(O->o[0][t], b_mean, b_std));
}

#define b(j,t) OHMM_b(hmm, O, t, j)

double OHMM_log_b(OHMM_p *hmm, OSet *O, int t, int j)
{
  double b_mean, b_std;

  b_mean = hmm->b[j].p[0];
  b_std  = hmm->b[j].p[1];
  return(log_gauss_dis(O->o[0][t], b_mean, b_std));
}

#define logb(j, t) OHMM_log_b(hmm, O, t, j)

/*
**  Forward Calculations for Discrete HMM (OHMM)
**  
**  Forward calculations are broken into three parts:
**
**    Initialization:
**    alpha(1,i) = pi(i) * b(i, o(1))
**
**    Iteration (or Induction):
**    alpha(t+1, j) = sum(i = 1 to N, alpha(t, i) * a(i, j)) * b(j, o(t+1))
**
**    Termination:
**    P(O | Lambda) = sum(i = 1 to N, alpha(T, i))
**
**  These steps are taken directly from the original viterbi.c program file,
**  with modifications for dynamic data types.
**
*/

/* scaled find alpha - scale at each step to prevent underflow */

extern int OHMM_scaled_find_alpha(HMM *lambda, double ***alpha, OSet *O, double **w)
{
  int i, j, t;
  double temp;
  OHMM_p *hmm = NULL;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

/* create the alpha matrix */

/*  printf("Alphas...\n"); */

  if (*alpha == NULL)
    *alpha = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));

  if (*w == NULL)
    *w = (double *) safe_calloc(O->count, sizeof(double));

/* initialize the array elements for time 0 */

  for (i = 0; i < hmm->s_count; i++)
    (*alpha)[0][i] = hmm->pi[i] * b(0,i);
  (*w)[0] = 1.0;

/* forward iteration to compute alpha[t][i] */

  for (t = 0; t < O->count - 1; t++) {
    for (j = 0, temp = 0.0; j < hmm->s_count; j++) {
      for (i = 0; i < hmm->s_count; i++)
	temp += (*alpha)[t][i]*hmm->a[i][j];
      (*alpha)[t+1][j] = temp * b(j,t+1);
    }

/* scale the the alpha's */

    for (i = 0, (*w)[t+1] = 0.0; i < hmm->s_count; i++)
      (*w)[t+1] += (*alpha)[t+1][i];
    
    if ((*w)[t+1] > 0.0) {
      for (i = 0; i < hmm->s_count; i++) {
	(*alpha)[t+1][i] /= (*w)[t+1];
/*	printf("%7.5e ", (*alpha)[t+1][i]); */
      }
/*      printf("%7.5e \n", (*w)[t+1]); */
    }
    else
      (*w)[t+1] = 1.0;
  }
  return(HMM_OK);
}

/* termination, to find P(O|Lamda) */

extern int OHMM_forward_term(HMM *lambda, double **alpha, OSet *O, double *P, double *w)
{
  int i;
  OHMM_p *hmm = NULL;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

/* terminate by summing all of P(O|Lamba, q(T) = i) */

  for (i = 0, *P = 0.0; i < O->count; i++) {
    (*P) += log(w[i]);
  }

  return(HMM_OK);
}

/*
**  Backward Calculations for Discrete HMM (OHMM)
**  
**  Backward calculations are broken into three parts:
**
**    Initialization:
**    beta(T, i) = 1
**
**    Iteration (or Induction):
**    beta(t, i) = sum(i = j to N, a(i, j) * b(j, o(t+1)) * beta(t+1, j))
**
*/

extern int OHMM_find_beta(HMM *lambda, double ***beta, OSet *O)
{
  int i, j, t;
  OHMM_p *hmm = NULL;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

/* create Beta array */

  if (*beta == NULL)
    *beta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));

/* initialize the array elements */

  for (i = 0; i < hmm->s_count; i++)
    (*beta)[O->count - 1][i] = 1.0;

/* iterate through the steps */

  for (t = O->count - 2; t >= 0; t--) {
    for (i = 0; i < hmm->s_count; i++) {
      (*beta)[t][i] = 0.0;
      for (j = 0; j < hmm->s_count; j++)
	(*beta)[t][i] += hmm->a[i][j] * b(j,t+1);
	  (*beta)[t+1][j];
    }
  }
  return(HMM_OK);
}

/* scaled find beta - the betas are normalized at each step */

extern int OHMM_scaled_find_beta(HMM *lambda, double ***beta, OSet *O)
{
  int i, j, t;
  OHMM_p *hmm = NULL;
  double temp;

/*  printf("betas\n");*/
  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

/* create Beta array */

  if (*beta == NULL)
    *beta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));

/* initialize the array elements */

  for (i = 0; i < hmm->s_count; i++)
    (*beta)[O->count - 1][i] = 1.0;

/* iterate through the steps */

  for (t = O->count - 2; t >= 0; t--) {
    for (i = 0; i < hmm->s_count; i++) {
      (*beta)[t][i] = 0;
      for (j = 0; j < hmm->s_count; j++)
	(*beta)[t][i] += hmm->a[i][j] * b(j,t+1) * (*beta)[t+1][j];
    }

/* scale the betas */

    for (i = 0, temp = 0.0; i < hmm->s_count; i++)
      temp += (*beta)[t][i];

    if (temp > 0.0) {
      for (i = 0; i < hmm->s_count; i++) {
	(*beta)[t][i] /= temp;
/*	printf("%7.5e ", (*beta)[t][i]);*/
      }
/*      printf("\n");*/
    }
  }
  return(HMM_OK);
}

/*
**  Viterbi Calculations for Discrete HMM (OHMM)
**  
**  Viterbi calculations are broken into four parts:
**
**    Initialization:
**    delta(1, i) = pi(i) b(i, O(1)), phi(1,i) = NULL
**
**    Iteration (or Induction):
**    delta(t, j) = max(delta(t-1)*a(i,j))*b(j,o(t))
**    phi(t, j) = arg max(delta(t-1)*a(i,j))
**
**    Termination:
**    P = max(delta(T, i))
**    q(T) = argmax(delta(T,i))
**
**    Path Backtracking
**    q(t) = phi(t+1, q(t+1))
**
**  These steps are taken directly from the original viterbi.c program file,
**  with modifications for dynamic data types.
**
*/

extern int OHMM_viterbi(HMM *lambda, OSet *O, int **Q)
{
  int i, j, t;
  double **delta = NULL;
  double temp;
  int **phi = NULL;
  OHMM_p *hmm = NULL;
  double **a;
  double *pi;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

/* create the sequence matrix Q */

  if (*Q == NULL)
    *Q = (int *) safe_calloc(O->count, sizeof(int));

/* initialization  */

  a = (double **) safe_alloc2d(hmm->s_count, hmm->s_count, sizeof(double));
  pi = (double *) safe_calloc(hmm->s_count, sizeof(double));
  delta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));
  phi = (int **) safe_alloc2d(O->count, hmm->s_count, sizeof(int));

/* create log numbers */

  for(i = 0; i < hmm->s_count; i++)
    for(j = 0; j < hmm->s_count; j++)
      a[i][j] = hmm->a[i][j] > 0 ?
	log(hmm->a[i][j]) : -MAX_NUMBER;

  for(i = 0; i < hmm->s_count; i++)
      pi[i] = hmm->pi[i] > 0 ?
	log(hmm->pi[i]) : -MAX_NUMBER;

/* inititializing phi */

  for(i = 0; i < hmm->s_count; i++) {
    delta[0][i] = pi[i];
    phi[0][i] = i;
  }

/* Recursion / Iteration */

  for(t = 1; t < O->count; t++) {
    for(j = 0; j < hmm->s_count; j++) {
      delta[t][j] = -MAX_NUMBER;
      phi[t][j] = -1;
      for(i = 0; i < hmm->s_count; i++) {
	if (a[i][j] > -MAX_NUMBER) {
	  temp = delta[t-1][i] + a[i][j];
	  if (temp > delta[t][j]) {
	    delta[t][j] = temp;
	    phi[t][j] = i;
	  }
	}
      }
      delta[t][j] += logb(j,t);

#ifdef DEBUG
      if ((phi[t][j] > -1) && (delta[t][j] > -MAX_NUMBER))
	fprintf(stdout, "|%2i|%8.2f", phi[t][j], delta[t][j]);
      else
	fprintf(stdout, "|  |        ");
#endif
    }

#ifdef DEBUG
    fprintf(stdout, "|\n");
#endif

  }

/* Termination */
  
  for(i = 0, temp = -MAX_NUMBER,(*Q)[O->count-1] = -1 ; i < hmm->s_count; i++){
    if (delta[O->count-1][i] > temp) {
      temp = delta[O->count-1][i];
      (*Q)[O->count-1] = i;
    }
  }

/* Backtracking */

  for(t = O->count - 2; t >= 0; t--)
    (*Q)[t] = phi[t+1][(*Q)[t+1]];

/* free up the dynamic arrays */

  free2d(a);
  free(pi);
  free2d(phi);
  free2d(delta);

  return(HMM_OK);
}

/*
**  Truncated Viterbi Implementation
**  
**  The truncated Viterbi implemenation only maintains a window of size M.
**  When the window size M is reached, a decoding is forced.  Also, decoding
**  takes place when a merge point is detected.  A merge point is a common
**  state from where the sub sequent state is derived.  So for example, if
**  at time t, the previous state for all current state sequence variable
**  phi(t, i) points to the same previous state, then, it is safe to decode
**  the previous state.
**
**    Initialization:
**    delta(1, i) = pi(i) b(i, O(1)), phi(1,i) = NULL
**
** |   Iteration (or Induction):
** |   delta(t, j) = max(delta(t-1)*a(i,j))*b(j,o(t))
** |   phi(t, j) = arg max(delta(t-1)*a(i,j))
** |
** |   Termination:
** |   P = max(delta(T, i))
** |   q(T) = argmax(delta(T,i))
** |
** |   Path Backtracking
** |   q(t) = phi(t+1, q(t+1))
** |
**
**  the parts marked by change bars are repeated in every window.
**
*/

/* initialize the state variables */

extern int OHMM_init_trunc(HMM *lambda,
			  int window_size,
			  int detect_merge)
{
  OHMM_p *hmm = NULL;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

  OHMM_merge_detect = detect_merge;
  OHMM_cursor       = 0;
  OHMM_window_size  = window_size;
  OHMM_merge_depth  = hmm->s_count + 1;
}

/* find the argmax of an 1-d array of double's */

int OHMM_argmax(double *array, int size)
{
  int i, arg;
  double temp;

  for (i = 1, arg = 0, temp = array[0]; i < size; i++)
    if (array[i] > temp) {
      temp = array[i];
      arg = i;
    }

  return(arg);
}

/* truncation window processing */

int OHMM_trunc_window(HMM    *lambda,
		      double **a,
		      double *pi,
		      double ***delta,
		      int    ***phi,
		      OSet   *O,
		      int    **Q,
		      int    t)
{
  int i, j, tau, temp_state;
  double temp;
  double merge_depth;
  int cursor;
  int common_state = -1;
  OHMM_p *hmm = NULL;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

/* end of sequence backtracking */

  if (t == (O->count)) {
    tau = t - 1;
    (*Q)[tau] = OHMM_argmax((*delta)[tau],hmm->s_count);
    for (tau--; tau >= OHMM_cursor; tau--)
      (*Q)[tau] = (*phi)[tau+1][(*Q)[tau+1]];
  }
  else {

/* forward iteration */

    for(j = 0; j < hmm->s_count; j++) {
      (*delta)[t][j] = -MAX_NUMBER;
      (*phi)[t][j] = -1;
      for(i = 0; i < hmm->s_count; i++) {
	if (a[i][j] > -MAX_NUMBER) {
	  temp = (*delta)[t-1][i] + a[i][j];
	  if (temp > (*delta)[t][j]) {
	    (*delta)[t][j] = temp;
	    (*phi)[t][j] = i;
	  }
	}
      }
      (*delta)[t][j] += logb(j,t);
    }

/* merge point search */

    if ((OHMM_merge_detect) && ((t - OHMM_cursor) > OHMM_merge_depth)) {
      for (i = 0; i < hmm->s_count; i++) {
	cursor = i;

	for (j = 0; (j <= OHMM_merge_depth) && (cursor > -1); j++)
	  cursor = (*phi)[t - j][cursor];

	if (cursor > -1) {
	  temp_state = cursor;
	  if (common_state < 0)
	    common_state = cursor + 1;
	  else
	    common_state &= (cursor + 1);
	}
      }

/* common_state is set to -1 if no merge point is found, otherwise, */
/* it is set to the merged state                                    */

      common_state = (common_state == (temp_state + 1)) ? temp_state : -1;

/* backtracking starting from the merge point.  */

      if (common_state > -1) {
	tau = t - OHMM_merge_depth;

	for (i = 0; i < hmm->s_count; i++) {
	  if (a[common_state][i] > -MAX_NUMBER) {
	    (*phi)[tau][i] = common_state;
	    (*delta)[tau][i] =
	      (*delta)[tau-1][common_state] + logb(i,tau) + a[common_state][i];
	  }
	  else {
	    (*phi)[tau][i] = -1;
	    (*delta)[tau][i] = -MAX_NUMBER;
	  }
	}

	(*Q)[--tau] = common_state;
	for (tau--; tau >= OHMM_cursor; tau--)
	  (*Q)[tau] = (*phi)[tau+1][(*Q)[tau+1]];

	OHMM_cursor = t - OHMM_merge_depth;
      }
    }

/* if the window size is reached, force the sub-optimal decoding */

    if ((t - OHMM_cursor) == OHMM_window_size) {
      cursor = OHMM_argmax((*delta)[t],hmm->s_count);
      for (tau = t; tau > OHMM_cursor; tau--)
	cursor = (*phi)[tau][cursor];
      (*Q)[OHMM_cursor++] = cursor;

      for (i = 0; i < hmm->s_count; i++) {
	if (a[cursor][i] > -MAX_NUMBER) {
	  (*phi)[OHMM_cursor][i] = cursor;
	  (*delta)[OHMM_cursor][i] =
	    (*delta)[OHMM_cursor-1][cursor] + logb(i,OHMM_cursor)
	      + a[cursor][i];
	}
	else {
	  (*phi)[OHMM_cursor][i] = -1;
	  (*delta)[OHMM_cursor][i] = -MAX_NUMBER;
	}
      }
    }

/* prune the impossible paths */

    for (tau = OHMM_cursor + 1; tau <= t; tau++) {
      for(j = 0; j < hmm->s_count; j++) {
	if ((*phi)[tau-1][(*phi)[tau][j]] == -1) {
	  (*phi)[tau][j] = -1;
	  (*delta)[tau][j] = -MAX_NUMBER;
	}
      }
    }

  }
}

extern int OHMM_trunc_viterbi(HMM *lambda, OSet *O, int **Q)
{
  int i, j, t;
  double **delta = NULL;
  double temp;
  int **phi = NULL;
  OHMM_p *hmm = NULL;
  double **a;
  double *pi;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

/* create the sequence matrix Q */

  if (*Q == NULL)
    *Q = (int *) safe_calloc(O->count, sizeof(int));

/* initialization  */

  a = (double **) safe_alloc2d(hmm->s_count, hmm->s_count, sizeof(double));
  pi = (double *) safe_calloc(hmm->s_count, sizeof(double));
  delta = (double **) safe_alloc2d(O->count, hmm->s_count, sizeof(double));
  phi = (int **) safe_alloc2d(O->count, hmm->s_count, sizeof(int));

/* create log numbers */

  for(i = 0; i < hmm->s_count; i++)
    for(j = 0; j < hmm->s_count; j++)
      a[i][j] = hmm->a[i][j] > 0 ?
	log(hmm->a[i][j]) : -MAX_NUMBER;

  for(i = 0; i < hmm->s_count; i++)
      pi[i] = hmm->pi[i] > 0 ?
	log(hmm->pi[i]) : -MAX_NUMBER;

/* inititializing phi */

  for(i = 0; i < hmm->s_count; i++) {
    if ((delta[0][i] = pi[i]) > -MAX_NUMBER)
      phi[0][i] = i;
    else
      phi[0][i] = -1;
  }

/* send all the observations to the sliding window decoder */

  for(t = 1; t <= O->count; t++)
    OHMM_trunc_window(lambda, a, pi, &delta, &phi, O, Q, t);

#ifdef DEBUG

  for(t = 0; t < O->count; t++) {
    fprintf(stderr,"%3i|",t);

    for (i = 0; i < hmm->s_count; i++) {
      if (delta[t][i] > -MAX_NUMBER)
	fprintf(stderr,"%12.2f|%3i|", delta[t][i], phi[t][i]);
      else
	fprintf(stderr,"            |   |", delta[t][i], phi[t][i]);
    }
    fprintf(stderr,"%3i\n", OHMM_cursor);
  }

#endif

/* free up the dynamic arrays */

  free2d(a);
  free(pi);
  free2d(phi);
  free2d(delta);

  return(HMM_OK);
}

/*
**  Baum Welch Calculations for Discrete HMM (OHMM)
**  
**  Baum Welch calculations are recursive in nature.  The parameters
**  are estimated with the following auxillary functions:
**
**  xi(t, i, j) =
**     alpha(t, i) * a(i,j) * b(j, t+1) * beta(t+1, j)
**    -------------------------------------------------
**                 sum all possible above
**
**  gamma(t, i) =
**    sum(xi(t, i, j), all j)
**
**  Each iteration steps are:
**
**  pi(i) = gamma(1, i)
**
**  a(i,j) = sum(xi(t,i,j), t=1..T-1) / sum(gamma(t,i), t=1..T-1)
**
**  b(j,k) = sum(gamma(t,j), t=1..T, o(t) = v(k)) /
**           sum(gamma(t,j), t=1..T-1)
**
**  This will be applied to the entire data set, then the tuned lambda is
**  used as the benchmark for evaluating the other sets.
**
*/

/*
**  Compute the set of auxilliary functions.  Assuming that alpha and beta
**  are precomputed already.  xi is a 3-d array of the form
**    xi(t, i, j) = P(q(t) = i, q(t+1) = j | O, lambda)
**    gamma(t, i) = sum(xi(t,i,j), j=1..N) 
**
*/

int OHMM_bw_xi_gamma(HMM *lambda, double **alpha,
			    double **beta, OSet *O,
			    double ****XI, double ***GAMMA)
{
  int i, j, t;
  OHMM_p *hmm = NULL;
  double temp;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

/* allocate an array for XI[t][i][j], GAMMA[t][i] */

  if (*XI == NULL)
    *XI = (double ***)
      safe_alloc3d(O->count-1, hmm->s_count, hmm->s_count, sizeof(double));

  if (*GAMMA == NULL)
    *GAMMA = (double **)
      safe_alloc2d(O->count - 1, hmm->s_count, sizeof(double));

/* find all possible alpha*a*b*beta */

  for(t = 0; t < O->count-1; t++) {

/* find the products of forward & backward procedures */
    
    temp = 0.0;

    for(i = 0; i < hmm->s_count; i++) {
      for(j = 0; j < hmm->s_count; j++) {
	(*XI)[t][i][j] = 
	  alpha[t][i]*hmm->a[i][j]*b(j,t+1)*beta[t+1][j];
	temp += (*XI)[t][i][j];
      }
    }

/* adjust the size to evaluate XI */

    if (temp > 0.0) {
      for(i = 0; i < hmm->s_count; i++) {
	for(j = 0; j < hmm->s_count; j++) {
	  (*XI)[t][i][j] /= temp;
	}
      }
    }

/* Evaluate GAMMA */

    for(i = 0; i < hmm->s_count; i++) {
      (*GAMMA)[t][i] = 0.0;
      for (j = 0; j < hmm->s_count; j++) (*GAMMA)[t][i] += (*XI)[t][i][j];
    }
  }
  return(HMM_OK);
}

/*
**  Compute the tuned lambda based on the input set.  Each time the parameter
**  changes, the alpha and beta will need to be recalculated.
**
**  lambda, alpha, beta will be the final values.
**
*/

extern int OHMM_bw_estimate(HMM *lambda, double **alpha,
			    double **beta, OSet *O)
{
  int t, i, j, k;
  OHMM_p *hmm = NULL;
  double ***bw_xi = NULL;
  double **bw_gamma = NULL;
  double *w = NULL;
  double temp1, temp2, temp3, temp4;
  double residual, res_multiplier, subtotal;

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);
  hmm = &(lambda->par.o);

  bw_xi = NULL;
  bw_gamma = NULL;

/* find alpha and beta */

  if (OHMM_scaled_find_alpha(lambda, &alpha, O, &w) != HMM_OK) {
    fprintf(stderr, "forward computation error in OHMM_bw_estimate.\n");
    abort();
  }

  if (OHMM_scaled_find_beta(lambda, &beta, O) != HMM_OK) {
    fprintf(stderr, "Backward computation error in OHMM_bw_estimate.\n");
    abort();
  }

/* find parameters xi and gamma */

  if (OHMM_bw_xi_gamma(lambda,alpha,beta,O,&bw_xi,&bw_gamma) != HMM_OK) {
    fprintf(stderr, "xi & gamma computation error in OHMM_bw_estimate.\n");
    abort();
  }

/* reestimate pi, pi(i) = gamma[0][i] */

  for(i = 0; i < hmm->s_count; i++) hmm->pi[i] = bw_gamma[0][i];

/* reestimate a, a[i][j] = sum(xi) / sum(gamma) */

  temp3 = 0.0;
  for(i = 0; i < hmm->s_count; i++) {
    for(t = 0, temp2 = 0.0; t < O->count-1; t++) temp2 += bw_gamma[t][i];
    temp3 += temp2;

/* only reestimate the state if Pr(state i) is significant */
/* rate limit the estimate change rate to prevent sudden swings in values */

    if (temp2 > MIN_BW_STATE) {
      for(j = 0; j < hmm->s_count; j++) {
	for(t = 0, temp1 = 0.0; t < O->count-1; t++) temp1 += bw_xi[t][i][j];
	temp4 = (temp1/temp2)/hmm->a[i][j] - 1.0;
	hmm->a[i][j] = (fabs(temp4) < MAX_BW_STEP) ? temp1/temp2 :
	  hmm->a[i][j] * (1 + copysign(MAX_BW_STEP, temp4));
      }

/* now, normalize the a[i][j] stuff */

      for (j = 0, temp4 = 0.0; j < hmm->s_count; j++) temp4 += hmm->a[i][j];
      for (j = 0; j < hmm->s_count; j++) hmm->a[i][j] /= temp4;
    }
  }
    
/* restimating b */
/* mu = sum(gamma * O) / sum (gamma) */
/* sigma = sum(gamma * (O-mu)^2 / sum (gamma)) */

  for(j = 0; j < hmm->s_count; j++) {
    for(t = 0, temp2 = 0.0; t < O->count-1; t++)
      temp2 += bw_gamma[t][j];
    for(t = 0, temp3 = 0.0; t < O->count-1; t++)
      temp3 += O->o[0][t] * bw_gamma[t][j];
    for(t = 0, temp4 = 0.0; t < O->count-1; t++)
      temp4 += sqr(O->o[0][t] - hmm->b[j].p[0]) * bw_gamma[t][j];

/* rate limit this */

    temp1 = temp3/temp2 - hmm->b[j].p[0];
    hmm->b[j].p[0] = hmm->b[j].p[0] + MAX_BW_STEP * temp1;

    temp1 = sqrt(temp4/temp2) - hmm->b[j].p[1];
    hmm->b[j].p[1] = hmm->b[j].p[1] + MAX_BW_STEP * temp1;
  }

/* clean up the memory allocation */

  free2d(bw_gamma);
  free3d(bw_xi);
  free(w);

  return(HMM_OK);
}

/*
**  OHMM_read_lambda
**
**
*/

extern int OHMM_read_lambda(HMM **lambda, char *filename)
{
  int i, j, k, l;
  OHMM_p *hmm;
  FILE *in_file;
  char in_string[256], c;
  double temp_double;
  int p_count, b_type, b_count;

  *lambda = (HMM *) safe_malloc(sizeof(HMM));
  (*lambda)->type = OHMM;

  hmm = &((*lambda)->par.o);

/* open data file */

  if ((in_file = fopen(filename, "r")) == NULL) {
    fprintf(stderr, "OHMM_read_lambda can't read %s\n", filename);
    abort();
  }

/* read data from input file */
      
  k = 0;

  while (fscanf(in_file, "%s", in_string) > 0) {

/* take out all the comments beginning with # */
    
    if (in_string[0] == '#') {
      while ((c = fgetc(in_file)) != EOF && c != '\n');
      continue;
    }
    else {
      switch (k++) {
      case  0:                  /* number of states */
	fscanf(in_file,"%d",&(hmm->s_count));
	hmm->pi = (double *) safe_calloc(hmm->s_count, sizeof(double));
	hmm->a = (double **) safe_alloc2d(hmm->s_count, hmm->s_count,
					  sizeof(double));
	hmm->s_name = (char **) safe_calloc(hmm->s_count, sizeof(char *));
	break;

      case  1:                  /* name of states */
	for(i = 0; i < hmm->s_count; i++) {
	  fscanf(in_file,"%s", (char *) &in_string);
	  hmm->s_name[i] = (char *) strdup(in_string);
	}
	break;

      case 2:                   /* initial distribution */
	for(i = 0; i < hmm->s_count; i++)
	  fscanf(in_file,"%le", &(hmm->pi[i]));
	break;

      case 3:                   /* read in the a matrix */
	for(i = 0; i < hmm->s_count; i++) {
	  for(j = 0; j < hmm->s_count; j++)
       	    fscanf(in_file, "%le", &(hmm->a[i][j]));
	  if (i < hmm->s_count - 1)
	    fscanf(in_file,"%s",in_string);
	}
	break;

      case 4:                   /* read in the b distribution */
	fscanf(in_file, "%s", in_string);
	for (i = 0, b_type = UNDEFINED, b_count = 5; i < 4; i++) {
	  if (strcasecmp(in_string, dist_name[i]) == 0) {
	    b_type = dist_number[i];
	    b_count = dist_p_count[i];
	  }
	}
	break;

      case 5:                   /* read in the parameters for b */
	hmm->b = (struct DIST_param *)
	  safe_calloc(hmm->s_count, sizeof(struct DIST_param));
	for (i = 0; i < hmm->s_count; i++) {
	  hmm->b[i].type = b_type;
	  hmm->b[i].p_count = b_count;
	  hmm->b[i].p = (double *) safe_calloc(b_count, sizeof(double));
	  for (j = 0; j < b_count; j++) {
	    fscanf(in_file, "%le", &(hmm->b[i].p[j]));
	  }
	  if (i < hmm->s_count - 1)
	    fscanf(in_file,"%s",in_string);
	}
	break;

      default:                  /* ignore everything after the B vec. */
	break;
      }
    }
  }

  fclose(in_file);
  return(HMM_OK);
}

/*
**
**  write OHMM into a file.
**
*/

extern int OHMM_write_lambda(HMM *lambda, char *filename)
{
  int i, j;
  OHMM_p *hmm;
  FILE *out_file;
  char out_string[256];
  double temp_double;
  char comments[] = "#\n#\n#\n";
  char new_line[] = "\n";

  if (lambda == NULL)
    return(HMM_ERROR);

  if (lambda->type != OHMM)
    return(HMM_MISMATCH);

  hmm = &(lambda->par.o);

  if (filename == NULL)
    out_file = stdout;
  else {
    if ((out_file = fopen(filename, "w")) == NULL) {
      fprintf(stderr, "OHMM_write_lambda can't write to  %s.\n", filename);
      abort();
    }
  }

/* write data to the file in the same order as read */
      
  fprintf(out_file, comments);  /* number of states */
  fprintf(out_file, "no_states:  ");
  fprintf(out_file,"%i\n",hmm->s_count);

  fprintf(out_file, comments);   /* state names */
  fprintf(out_file, "state_no:  ");
  for(i = 0; i < hmm->s_count; i++)
    fprintf(out_file,"%s  ", hmm->s_name[i]);
  fprintf(out_file, new_line);
  fprintf(out_file, comments);  /* initial distribution */
  fprintf(out_file, "init_dis:  ");
  for(i = 0; i < hmm->s_count; i++) {
    temp_double = hmm->pi[i] < MIN_NUMBER ? 0.0 : hmm->pi[i];
    fprintf(out_file,"%4.2f ", temp_double);
  }
  fprintf(out_file, new_line);

  fprintf(out_file, comments);  /* A matrix */
  for(i = 0; i < hmm->s_count; i++) {
    fprintf(out_file,"a[%i,j]:  ", i+1);
    for(j = 0; j < hmm->s_count; j++) {
      temp_double = hmm->a[i][j] < MIN_NUMBER ? 0.0 : hmm->a[i][j];      
      fprintf(out_file, "%12.8f ", temp_double);
    }
    fprintf(out_file, new_line);
  }

  fprintf(out_file, comments); /* b vectors */
  fprintf(out_file, "obs_type: ");
  fprintf(out_file, "%s", dist_name[hmm->b[0].type]);
  fprintf(out_file, new_line);

  fprintf(out_file, comments); /* duration parameters */
  for (i = 0; i < hmm->s_count; i++) {
    fprintf(out_file, "b[%i,j]:  ", i+1);
    for (j = 0; j < hmm->b[i].p_count; j++) {
      fprintf(out_file, "%10.6f ", hmm->b[i].p[j]);
    }
    fprintf(out_file, new_line);
  }

  fprintf(out_file, comments);

  close(out_file);
  return(HMM_OK);
}


/* Free Up the space taken by the HMM */

extern int OHMM_free(HMM *lambda)
{
  int i, j;
  OHMM_p *hmm;

/* if it's already freed, skip the rest of the routines */

  if (lambda == NULL)
    return(HMM_OK);

  hmm = &(lambda->par.o);

  for (i = hmm->s_count - 1; i >= 0; i--) free(hmm->b);
  for (i = hmm->s_count - 1; i >= 0; i--) free(hmm->s_name[i]);

  free(hmm->s_name);
  free(hmm->b);
  free2d(hmm->a);
  free(hmm->pi);
  free(hmm);
  free(lambda);

  return(HMM_OK);
}
